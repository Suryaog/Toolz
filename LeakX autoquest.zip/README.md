# ⚡ LEAKX HUB — Quest Manager

> A lightweight Discord.js quest-management bot with slash commands and automated task handling.

---

## 🧩 COMMANDS

| Command      | Function                           |
| :----------- | :--------------------------------- |
| `/link`      | Connect an account to the bot      |
| `/quest`     | Process an individual quest        |
| `/questall`  | Process all available quests       |
| `/autoquest` | Run quest processing automatically |

---

## 🔧 SETUP

### 1. Install dependencies

```bash
npm install
```

### 2. Configure the bot

Create `.env` beside `index.js`:

```env
DISCORD_TOKEN=your_bot_token
DISCORD_CLIENT_ID=your_client_id
BOT_PREFIX=,,
```

### 3. Launch

```bash
node index.js
```

---

## 🔐 ENVIRONMENT

| Name                | Required | Purpose                  |
| ------------------- | :------: | ------------------------ |
| `DISCORD_TOKEN`     |     ✅    | Bot authentication token |
| `DISCORD_CLIENT_ID` |     ✅    | Discord application ID   |
| `BOT_PREFIX`        |     ✅    | Prefix for text commands |

---

## 📌 IMPORTANT

* Make sure the necessary Discord Gateway Intents are enabled.
* Slash commands registered globally may not appear immediately.
* Keep your `.env` file private and never commit your bot token.

---

## 🌐 LEAKX HUB

**Community:** `.gg/leakx`

**Project:** Free Quest source by Elix.

---

### `LEAKX HUB` · Discord Tools · .gg/leakx
