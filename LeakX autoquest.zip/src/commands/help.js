// ============================================================
//                    LEAKX HUB — QUEST SOLVER
// ============================================================
// Free Quest Solver
// Open Source • Free to Use • Free to Modify
//
// Community: .gg/leakX
// ============================================================
import {
    SlashCommandBuilder,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    SectionBuilder,
    ThumbnailBuilder,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    MessageFlags,
} from 'discord.js';
import { PREFIX } from '../utils/config.js';


const SUPPORT_URL = 'https://discord.gg/LeakX';
const BANNER_URL  = 'https://media.discordapp.net/attachments/1550162052293726271/1550398817826898000/Picsart_26-09-18_12-21-09-459.jpg?ex=6ab76b6b&is=6ab619eb&hm=e64f03e7f48946b275e9e97b184c083e7e8d07c1fa17dccb36c5b3852fdc68b9&=&format=webp&width=1536&height=134';
const OWNER       = 'Developed with care by Elix';
const OWNER_TAG   = 'forsty.fr & zyro_57';


function sep(divider = false) {
    return new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(divider);
}
function sepLg(divider = false) {
    return new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(divider);
}
function txt(content) {
    return new TextDisplayBuilder().setContent(content);
}

// ── Pages definition ───────────────────────────────────────────────────────

const PAGES = [
    { value: 'home',      label: '🏠 Home',            desc: 'Overview & getting started'            },
    { value: 'quest',     label: '👑 Quest Commands',   desc: 'Quest, questall, questlist & more'     },
    { value: 'points',    label: '🪙 Points & Shop',    desc: 'Earn & spend points'                   },
    { value: 'feedback',  label: '📝 Feedback',         desc: 'Feedback system & block rules'         },
    { value: 'giveaway',  label: '🎉 Giveaway',         desc: 'How to run giveaways'                  },
    { value: 'utility',   label: '🛠️ Utility',          desc: 'Reminders, server & user info'         },
    { value: 'admin',     label: '🛡️ Admin',            desc: 'Admin-only commands'                   },
];

// ── Select menu ────────────────────────────────────────────────────────────

function buildSelectMenu(currentPage) {
    const menu = new StringSelectMenuBuilder()
        .setCustomId('help_page_select')
        .setPlaceholder('Navigate to a section…');

    for (const page of PAGES) {
        const opt = new StringSelectMenuOptionBuilder()
            .setLabel(page.label)
            .setValue(page.value)
            .setDescription(page.desc)
            .setDefault(page.value === currentPage);
        menu.addOptions(opt);
    }

    return new ActionRowBuilder().addComponents(menu);
}

// ── Page content builders ──────────────────────────────────────────────────
function pageHome(c, botAvatar) {
    const hero = new SectionBuilder().addTextDisplayComponents(txt(
        `# ✦ Leak X Hub\n` +
        `### Next-Gen Discord Quest Hub\n` +
        `-# Fast, clean, and built for power users`
    ));

    if (botAvatar) {
        hero.setThumbnailAccessory(
            new ThumbnailBuilder().setURL(botAvatar)
        );
    }

    c.addSectionComponents(hero);

    c.addSeparatorComponents(sepLg(true));

    c.addTextDisplayComponents(txt(
        `### ⚡ Quick Start\n` +
        `**①** \`${PREFIX}link\` — paste your user token\n` +
        `**②** \`${PREFIX}quest\` — open the quest selector\n` +
        `**③** Pick a quest → hit **Start** → watch live logs\n` +
        `**④** \`${PREFIX}feedback <msg>\` — submit when done & earn pts`
    ));

    c.addSeparatorComponents(sepLg(true));

    c.addTextDisplayComponents(txt(`### 🗂️ At a Glance`));
    c.addSeparatorComponents(sep());

    c.addTextDisplayComponents(txt(
        `🔗 \`${PREFIX}link\` · \`${PREFIX}unlink\` · \`${PREFIX}status\` · \`${PREFIX}ping\`\n` +
        `👑 \`${PREFIX}quest\` · \`${PREFIX}questall\` · \`${PREFIX}questlist\`\n` +
        `⚡ \`${PREFIX}autoquest\` · 🎁 \`${PREFIX}claimall\` · 📝 \`${PREFIX}feedback\`\n` +
        `💡 \`${PREFIX}suggest\` · 🎫 \`${PREFIX}ticket\`\n` +
        `🛒 \`${PREFIX}shop\` · \`${PREFIX}buy\` · 🪪 \`${PREFIX}profile\`\n` +
        `🏆 \`${PREFIX}leaderboard\` · ⏰ \`${PREFIX}remind\` · 🔍 \`${PREFIX}userinfo\`\n` +
        `🎉 \`${PREFIX}giveaway\` · 🛡️ Admin commands`
    ));
}
function pageQuest(c) {
    c.addTextDisplayComponents(txt(`# 👑 Quest Commands`));
    c.addSeparatorComponents(sepLg(true));

    const cmds = [
        { emoji: '👑', cmd: `${PREFIX}quest`,     title: 'Quest Selector',    desc: 'Opens the premium quest picker with a live control panel' },
        { emoji: '💎', cmd: `${PREFIX}questall`,  title: 'Run All Quests',    desc: 'Completes every active quest automatically in one session' },
        { emoji: '📋', cmd: `${PREFIX}questlist`, title: 'Quest List',        desc: 'View all quests — active, completed, and expired'          },
        { emoji: '⚡', cmd: `${PREFIX}autoquest`, title: 'Auto Quest',        desc: 'Toggle auto-run: new quests are completed as they appear'   },
        { emoji: '📊', cmd: `${PREFIX}status`,    title: 'Session Status',    desc: 'Check progress of your current active quest session'        },
        { emoji: '🎁', cmd: `${PREFIX}claimall`,  title: 'Claim All',         desc: 'Instantly claim rewards for every completed quest'            },
    ];

    for (let i = 0; i < cmds.length; i++) {
        const cmd = cmds[i];
        c.addTextDisplayComponents(txt(
            `${cmd.emoji} **${cmd.title}** · \`${cmd.cmd}\`\n` +
            `-# ${cmd.desc}`,
        ));
        if (i < cmds.length - 1) c.addSeparatorComponents(sep());
    }
}

function pagePoints(c) {
    c.addTextDisplayComponents(txt(`# 🪙 Points & Shop`));
    c.addSeparatorComponents(sepLg(true));

    c.addTextDisplayComponents(txt(`### 💰 Earning Points`));
    c.addSeparatorComponents(sep());
    c.addTextDisplayComponents(txt(
        `📨 **Invite a member** → **+1 pt** *(you'll get a DM)*\n` +
        `📝 **Submit feedback** after a quest → **+2 pts gift**`,
    ));

    c.addSeparatorComponents(sepLg(true));

    c.addTextDisplayComponents(txt(`### 🛒 Spending Points`));
    c.addSeparatorComponents(sep());
    c.addTextDisplayComponents(txt(
        `🛒 \`${PREFIX}shop\` — Browse the full item catalogue & see your balance\n` +
        `-# Shows what you can afford highlighted\n\n` +
        `💳 \`${PREFIX}buy <item>\` — Purchase by item ID\n` +
        `-# \`${PREFIX}buy quest\` · \`${PREFIX}buy questall\`\n\n` +
        `🪪 \`${PREFIX}profile\` — Your balance, premium status & account info\n\n` +
        `🏆 \`${PREFIX}leaderboard\` — See the top points earners`,
    ));
}

function pageFeedback(c) {
    c.addTextDisplayComponents(txt(`# 📝 Feedback System`));
    c.addSeparatorComponents(sepLg(true));

    c.addTextDisplayComponents(txt(
        `After every quest finishes, you must submit feedback.\n` +
        `Run this command within **30 minutes:**`,
    ));
    c.addSeparatorComponents(sep());
    c.addTextDisplayComponents(txt(
        `### \`${PREFIX}feedback <your message>\`\n` +
        `-# Be honest — good or bad, all feedback helps us improve`,
    ));

    c.addSeparatorComponents(sepLg(true));

    c.addTextDisplayComponents(txt(`### ⚠️ If You Skip`));
    c.addSeparatorComponents(sep());
    c.addTextDisplayComponents(txt(
        `You'll be **blocked from quest commands for 24 hours:**\n` +
        `-# quest · questall · questlist · autoquest · status\n\n` +
        `### ✅ Remove the Block Anytime\n` +
        `Just run \`${PREFIX}feedback <message>\` — submitting instantly:\n` +
        `-# ✦ Clears the block immediately\n` +
        `-# ✦ Rewards you with **+2 pts**`,
    ));

    c.addSeparatorComponents(sepLg(true));

    c.addTextDisplayComponents(txt(`### 💡 Suggestions`));
    c.addSeparatorComponents(sep());
    c.addTextDisplayComponents(txt(
        `Have an idea? Use \`${PREFIX}suggest idea\` to pitch it!\n` +
        `-# Community members can vote up/down on suggestions`,
    ));
}

function pageGiveaway(c) {
    c.addTextDisplayComponents(txt(`# 🎉 Giveaway`));
    c.addSeparatorComponents(sepLg(true));

    c.addTextDisplayComponents(txt(`### \`${PREFIX}gstart <time> <winners> <host> <prize>\`\n-# Starts a reaction-based giveaway in the current channel`));
    c.addSeparatorComponents(sep());
    c.addTextDisplayComponents(txt(
        `\`${PREFIX}gstart 1h 1 @Admin Steam Gift Card\`\n` +
        `\`${PREFIX}gstart 30m 2 @Elix Discord Nitro\`\n` +
        `\`${PREFIX}gstart 2h30m 3 @Host 1000 Robux\`\n\n` +
        `**⏱️ Time:** \`10s\` · \`5m\` · \`2h\` · \`1d\` · combos like \`1h30m\`\n` +
        `**🏆 Winners:** 1 – 20`,
    ));

    c.addSeparatorComponents(sepLg(true));

    c.addTextDisplayComponents(txt(`### Manage Giveaways`));
    c.addSeparatorComponents(sep());
    c.addTextDisplayComponents(txt(
        `🔚 \`${PREFIX}gend <message ID>\` — End a giveaway early & pick winners\n` +
        `-# Copy the giveaway message ID and paste it here\n\n` +
        `🎲 \`${PREFIX}greroll <message ID>\` — Reroll & pick new winners\n` +
        `-# Edits the ended card and announces the new winner(s)`,
    ));

    c.addSeparatorComponents(sepLg(true));
    c.addTextDisplayComponents(txt(
        `-# Bot auto-reacts 🎉 · members react to enter\n` +
        `-# Winners are randomly drawn when time ends or \`gend\` is used`,
    ));
}

function pageUtility(c) {
    c.addTextDisplayComponents(txt(`# 🛠️ Utility Commands`));
    c.addSeparatorComponents(sepLg(true));

    const cmds = [
        {
            emoji: '⏰', cmd: `${PREFIX}remind <time> <message>`,
            title: 'Remind',
            desc: 'Set a timed reminder — bot will ping you after the duration\nExample: `,,remind 30m Take a break!`',
        },
        {
            emoji: '🏆', cmd: `${PREFIX}leaderboard`,
            title: 'Leaderboard',
            desc: 'View the top 10 points earners on the server',
        },
        {
            emoji: '🔍', cmd: `${PREFIX}userinfo [@user]`,
            title: 'User Info',
            desc: 'View detailed info about yourself or another member',
        },
        {
            emoji: '🌐', cmd: `${PREFIX}serverinfo`,
            title: 'Server Info',
            desc: 'View stats and info about this server',
        },
        {
            emoji: '🏓', cmd: `${PREFIX}ping`,
            title: 'Ping',
            desc: 'Check the bot\'s WebSocket and REST latency',
        },
    ];

    for (let i = 0; i < cmds.length; i++) {
        const cmd = cmds[i];
        c.addTextDisplayComponents(txt(
            `${cmd.emoji} **${cmd.title}** · \`${cmd.cmd}\`\n` +
            `-# ${cmd.desc}`,
        ));
        if (i < cmds.length - 1) c.addSeparatorComponents(sep());
    }
}

function pageAdmin(c) {
    c.addTextDisplayComponents(txt(
        `# 🛡️ Admin Commands\n` +
        `-# Requires the **Administrator** server permission`,
    ));
    c.addSeparatorComponents(sepLg(true));

    const cmds = [
        { emoji: '💫', cmd: `${PREFIX}givepremium @user`,        title: 'Give Premium',   desc: 'Grant premium quest access to a user'                   },
        { emoji: '🚫', cmd: `${PREFIX}removepremium @user`,      title: 'Remove Premium', desc: 'Remove premium — errors if the user doesn\'t have it'   },
        { emoji: '🪙', cmd: `${PREFIX}givepoints @user <amt>`,   title: 'Give Points',    desc: 'Add points to a user\'s balance (positive whole number)' },
        { emoji: '🎫', cmd: `${PREFIX}ticket setup`,             title: 'Ticket Setup',   desc: 'Post the support ticket panel in the current channel'   },
        { emoji: '👋', cmd: `${PREFIX}welcomer`,                 title: 'Welcomer',       desc: 'Configure the welcome message for new members'          },
        { emoji: '💡', cmd: `${PREFIX}suggest setup #channel`,   title: 'Suggest Setup',  desc: 'Set the channel where suggestions are posted'           },
    ];

    for (let i = 0; i < cmds.length; i++) {
        const cmd = cmds[i];
        c.addTextDisplayComponents(txt(
            `${cmd.emoji} **${cmd.title}**\n` +
            `\`${cmd.cmd}\`\n` +
            `-# ${cmd.desc}`,
        ));
        if (i < cmds.length - 1) c.addSeparatorComponents(sep());
    }
}

// ── Full card builder ──────────────────────────────────────────────────────

export function buildHelp(pageKey = 'home', client = null) {
    const botAvatar = client?.user?.displayAvatarURL({ size: 128, extension: 'png' }) ?? null;
    const c = new ContainerBuilder();

    switch (pageKey) {
        case 'home':     pageHome(c, botAvatar); break;
        case 'quest':    pageQuest(c);           break;
        case 'points':   pagePoints(c);          break;
        case 'feedback': pageFeedback(c);        break;
        case 'giveaway': pageGiveaway(c);        break;
        case 'utility':  pageUtility(c);         break;
        case 'admin':    pageAdmin(c);           break;
        default:
            c.addTextDisplayComponents(txt(`### ❓ Unknown Section\n-# Use the menu below`));
    }

    c.addSeparatorComponents(sepLg(true));
    c.addTextDisplayComponents(txt(
        `-# 👤 Owner: **${OWNER}** (${OWNER_TAG})  ·  [Support Server](${SUPPORT_URL})`,
    ));

    if (pageKey === 'home') {
        c.addMediaGalleryComponents(
            new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(BANNER_URL)),
        );
    }

    c.addSeparatorComponents(sep());
    c.addActionRowComponents(buildSelectMenu(pageKey));

    return { components: [c], flags: MessageFlags.IsComponentsV2 };
}

// ── Interaction handler ────────────────────────────────────────────────────

export async function handleHelpPageSelect(interaction) {
    const page = interaction.values[0];
    await interaction.update(buildHelp(page, interaction.client));
}

// ── Command ────────────────────────────────────────────────────────────────

export default {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('See all available commands'),
    prefix: 'help',

    async execute(interaction) {
        await interaction.reply(buildHelp('home', interaction.client));
    },

    async prefixExecute(message, _args, client) {
        await message.reply(buildHelp('home', client));
    },
};
// ============================================================
//                    LEAKX HUB — QUEST SOLVER
// ============================================================
// Free Quest Solver
// Open Source • Free to Use • Free to Modify
//
// Community: .gg/leakX
// ============================================================
