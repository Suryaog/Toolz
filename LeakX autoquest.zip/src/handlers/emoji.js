// ============================================================
//                    LEAKX HUB — QUEST SOLVER
// ============================================================
// Free Quest Solver
// Open Source • Free to Use • Free to Modify
//
// Community: .gg/leakX
// ============================================================

import { readFileSync, writeFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const EMOJI_PATH = join(__dirname, '../../data/emoji.json');

// ── Named emoji constants ──────────────────────────────────────────────────
export const EMOJI = {
    orbs:  'put the fucking emojie here ngas',
    tick:  'put the fucking emojie here ngas',
    cross: 'put the fucking emojie here ngas',
};

export function getEmoji(name) {
  try {
    const data = JSON.parse(readFileSync(EMOJI_PATH, 'utf8'));
    return data[name] ?? EMOJI[name] ?? '';
  } catch {
    return EMOJI[name] ?? '';
  }
}

export function getAllEmojis() {
  try {
    return { ...EMOJI, ...JSON.parse(readFileSync(EMOJI_PATH, 'utf8')) };
  } catch {
    return { ...EMOJI };
  }
}

export function setEmoji(name, emoji) {
  try {
    const data = JSON.parse(readFileSync(EMOJI_PATH, 'utf8'));
    data[name] = emoji;
    writeFileSync(EMOJI_PATH, JSON.stringify(data, null, 2));
    return true;
  } catch {
    return false;
  }
}

// ============================================================
//                    LEAKX HUB — QUEST SOLVER
// ============================================================
// Free Quest Solver
// Open Source • Free to Use • Free to Modify
//
// Community: .gg/leakX
// ============================================================