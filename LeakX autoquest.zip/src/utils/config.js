// ============================================================
//                    LEAKX HUB — QUEST SOLVER
// ============================================================
// Free Quest Solver
// Open Source • Free to Use • Free to Modify
//
// Community: .gg/leakX
// ============================================================

export const PREFIX              = process.env.BOT_PREFIX       || ',,';
export const QUEST_ROLE_ID       = process.env.QUEST_ROLE_ID      || null;
export const QUEST_LOG_CHANNEL_ID = process.env.QUEST_LOG_CHANNEL_ID || null;

// ============================================================
//                    LEAKX HUB — QUEST SOLVER
// ============================================================
// Free Quest Solver
// Open Source • Free to Use • Free to Modify
//
// Community: .gg/leakX
// ============================================================
