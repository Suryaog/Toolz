#!/usr/bin/env python3
"""Discord Unlocker — shared utilities for main.py."""

from __future__ import annotations

import asyncio
import base64
import imaplib
import json
import os
import random
import re
import sys
import threading
import time

if sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

import email
import requests
import tls_client

LOCK = threading.Lock()

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple, List


# ── Country info ──────────────────────────────────────────────────────────────

_COUNTRY_INFO: dict = {
    0: ("7", "Russia", ["Россия"]),
    16: ("44", "United Kingdom", ["Великобритания", "UK"]),
    43: ("49", "Germany", ["Германия", "Deutschland"]),
    49: ("49", "Germany", ["Германия", "Deutschland"]),
    78: ("33", "France", ["Франция"]),
    83: ("359", "Bulgaria", ["Болгария"]),
    187: ("1", "United States", ["США", "US"]),
}


def _strip_dial_prefix(phone_number: str, country_code: int) -> str:
    """Strip the country dial prefix from a full international phone number.

    HeroSMS / sms-activate return numbers with the dial code already prepended
    (e.g. '441234567890' for a UK number).  Discord's browser UI needs ONLY the
    local part ('1234567890') because it prepends the dial code itself based on
    the selected country dropdown.

    Args:
        phone_number: Raw number from the provider (with or without leading '+')
        country_code: sms-activate country code (e.g. 16 = UK)

    Returns:
        Local number string without country prefix or leading zeros.
    """
    phone = phone_number.lstrip("+").replace(" ", "").replace("-", "")
    info = _COUNTRY_INFO.get(
        int(country_code) if str(country_code).isdigit() else country_code
    )
    if info:
        dial = info[0]  # e.g. '44' for UK
        if phone.startswith(dial):
            phone = phone[len(dial) :]
    # Strip leading zero (some providers include national trunk prefix)
    phone = phone.lstrip("0") if phone else phone
    return phone


# ── IMAP helper ───────────────────────────────────────────────────────────────


class CustomMailServer:
    _DOMAIN_MAP = {
        "silentev.online": ("mail.silentev.online", 993),
        "firstmail.ltd": ("imap.firstmail.ltd", 993),
        "mail.ru": ("imap.mail.ru", 993),
        "gmail.com": ("imap.gmail.com", 993),
        "outlook.com": ("imap.outlook.com", 993),
        "hotmail.com": ("imap.outlook.com", 993),
        "yandex.com": ("imap.yandex.com", 993),
        "yandex.ru": ("imap.yandex.com", 993),
    }
    _FALLBACK_SERVERS = [("imap.gmail.com", 993), ("imap.mail.ru", 993)]

    def __init__(self):
        self.connection = None

    def connect(self, email_addr: str, password: str) -> bool:
        domain = email_addr.split("@")[-1].lower()
        servers = self._DOMAIN_MAP.get(domain, [self._FALLBACK_SERVERS[0]])
        if isinstance(servers, tuple):
            servers = [servers]
        for host, port in servers:
            try:
                conn = imaplib.IMAP4_SSL(host, port)
                conn.login(email_addr, password)
                conn.select("INBOX")
                self.connection = conn
                log.info(f"[IMAP] Connected to {host}")
                return True
            except Exception as e:
                log.warning(f"[IMAP] {host} failed: {e}")
                continue
        return False

    async def wait_for_discord_verification(self, timeout: int = 120) -> str | None:
        """Poll inbox for Discord verification email, return verification URL."""
        if not self.connection:
            return None
        start = time.time()
        seen = set()
        while time.time() - start < timeout:
            try:
                self.connection.noop()
                status, messages = self.connection.search(None, "UNSEEN")
                if status == "OK":
                    for num in messages[0].split():
                        if num in seen:
                            continue
                        seen.add(num)
                        status, data = self.connection.fetch(num, "(RFC822)")
                        if status != "OK":
                            continue
                        msg = email.message_from_bytes(data[0][1])
                        if (
                            "discord" in msg.get("From", "").lower()
                            and "verify" in msg.get("Subject", "").lower()
                        ):
                            url = self._extract_verify_url(msg)
                            if url:
                                self.connection.store(num, "+FLAGS", "\\Seen")
                                return url
                await asyncio.sleep(3)
            except Exception:
                await asyncio.sleep(3)
        return None

    def _extract_verify_url(self, msg) -> str | None:
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/html":
                    body = part.get_payload(decode=True).decode(errors="ignore")
                    return self._find_url_in_html(body)
        else:
            body = msg.get_payload(decode=True).decode(errors="ignore")
            return self._find_url_in_html(body)
        return None

    def _find_url_in_html(self, html: str) -> str | None:
        match = re.search(r"https://discord\.com/verify\?token=[a-zA-Z0-9_-]+", html)
        if match:
            return match.group(0)
        track_links = set(
            re.findall(r'https://click\.discord\.com/ls/click\?[^"\'>\s]+', html)
        )
        for url in track_links:
            try:
                resp = requests.get(url, allow_redirects=True, timeout=10)
                if "discord.com/verify" in resp.url:
                    return resp.url
            except Exception:
                pass
        return None

    def logout(self):
        if self.connection:
            try:
                self.connection.close()
                self.connection.logout()
            except Exception:
                pass


# ── TLS profiles ──────────────────────────────────────────────────────────────

_TLS_PROFILES = [
    {
        "tls_id": "chrome_133",
        "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
        "ver": "133",
        "sec_ch_ua": '"Chromium";v="133", "Not:A-Brand";v="24", "Google Chrome";v="133"',
    },
    {
        "tls_id": "chrome_134",
        "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "ver": "134",
        "sec_ch_ua": '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
    },
]


# ── Discord build / super-properties ─────────────────────────────────────────

DISCORD_BUILD_NUMBER = None


def fetch_discord_build() -> int:
    try:
        resp = requests.get("https://discord.com/app", timeout=10)
        js_files = re.findall(r"assets/([a-f0-9]+\.js)", resp.text)
        for js in js_files[:5]:
            js_resp = requests.get(f"https://discord.com/assets/{js}", timeout=10)
            match = re.search(r'buildNumber:"?(\d{4,7})"?', js_resp.text)
            if match:
                return int(match.group(1))
    except Exception:
        pass
    return 384887  # fallback


def build_super_properties(
    build: int, ua: str = None, locale: str = "en-US", tls_profile: dict = None
) -> str:
    if not ua and tls_profile:
        ua = tls_profile.get("ua")
    if not ua:
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
    props = {
        "os": "Windows",
        "browser": "Chrome",
        "device": "",
        "system_locale": locale,
        "browser_user_agent": ua,
        "browser_version": "134.0.0.0",
        "os_version": "10",
        "client_build_number": build,
    }
    return base64.b64encode(json.dumps(props, separators=(",", ":")).encode()).decode()


# ── Token checks ──────────────────────────────────────────────────────────────


@dataclass
class TokenReport:
    token: str
    status: str = "UNKNOWN"
    username: str = ""
    user_id: str = ""
    email_addr: str = ""
    verified: bool = False
    mfa: bool = False
    phone: bool = False
    nitro: bool = False
    flags: int = 0
    guild_count: int = -1
    flag_labels: list = field(default_factory=list)

    _FLAG_MAP = {
        1 << 0: "STAFF",
        1 << 1: "PARTNER",
        1 << 2: "HYPESQUAD_EVENTS",
        1 << 6: "HYPESQUAD_BRAVERY",
        1 << 7: "HYPESQUAD_BRILLIANCE",
        1 << 8: "HYPESQUAD_BALANCE",
        1 << 9: "EARLY_SUPPORTER",
        1 << 14: "BUG_HUNTER_LVL2",
        1 << 16: "VERIFIED_BOT",
        1 << 17: "EARLY_VERIFIED_BOT_DEV",
        1 << 22: "ACTIVE_DEVELOPER",
    }

    def resolve_flags(self):
        self.flag_labels = [
            lbl for bit, lbl in self._FLAG_MAP.items() if self.flags & bit
        ]


def deep_check_token(
    token: str, tls_profile: dict = None, locale: str = "en-US"
) -> TokenReport:
    p = tls_profile or random.choice(_TLS_PROFILES)
    report = TokenReport(token=token)
    session = tls_client.Session(
        client_identifier=p["tls_id"], random_tls_extension_order=True
    )
    sp = build_super_properties(DISCORD_BUILD_NUMBER, locale=locale, tls_profile=p)
    hdrs = {
        "Authorization": token,
        "x-super-properties": sp,
        "Accept-Language": f"{locale},en;q=0.9",
        "User-Agent": p["ua"],
        "sec-ch-ua": p["sec_ch_ua"],
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
    }
    # ── Identity check ────────────────────────────────────────────────────────
    try:
        r = session.get(
            "https://discord.com/api/v9/users/@me", headers=hdrs, timeout_seconds=15
        )
        if r.status_code == 200:
            d = r.json()
            report.username = d.get("username", "")
            report.user_id = d.get("id", "")
            report.email_addr = d.get("email", "")
            report.verified = d.get("verified", False)
            report.mfa = d.get("mfa_enabled", False)
            report.phone = bool(d.get("phone"))
            report.nitro = d.get("premium_type", 0) > 0
            report.flags = d.get("public_flags", 0)
            report.resolve_flags()
        elif r.status_code == 401:
            report.status = "INVALID"
            return report
        elif r.status_code == 403:
            report.status = "LOCKED"
            return report
        elif r.status_code == 429:
            wait = r.json().get("retry_after", 10.0)
            log.warning(f"Token check rate-limited — waiting {wait:.1f}s")
            time.sleep(wait)
    except Exception:
        report.status = "ERROR"
        return report

    time.sleep(random.uniform(0.8, 2.0))

    # ── Library check ─────────────────────────────────────────────────────────
    try:
        r2 = session.get(
            "https://discord.com/api/v9/users/@me/library",
            headers=hdrs,
            timeout_seconds=15,
        )
        if r2.status_code == 200:
            report.status = "VALID"
        elif r2.status_code == 403:
            report.status = "LOCKED"
            return report
        elif r2.status_code == 401:
            report.status = "INVALID"
            return report
        elif r2.status_code == 429:
            wait = r2.json().get("retry_after", 10.0)
            time.sleep(wait)
            report.status = "ERROR"
        else:
            report.status = "ERROR"
    except Exception:
        report.status = "ERROR"
        return report

    time.sleep(random.uniform(0.5, 1.5))

    # ── Guild count ───────────────────────────────────────────────────────────
    try:
        r3 = session.get(
            "https://discord.com/api/v9/users/@me/guilds",
            headers=hdrs,
            timeout_seconds=15,
        )
        if r3.status_code == 200:
            report.guild_count = len(r3.json())
    except Exception:
        pass

    return report


async def is_email_verified(token: str) -> bool:
    """Check via Discord API if the email is verified."""
    session = tls_client.Session(client_identifier="chrome_134")
    headers = {"Authorization": token, "Content-Type": "application/json"}
    try:
        resp = session.get(
            "https://discord.com/api/v9/users/@me", headers=headers, timeout_seconds=15
        )
        if resp.status_code == 200:
            return resp.json().get("verified", False)
    except Exception:
        pass
    return False


# ── File saving ───────────────────────────────────────────────────────────────


def _save_account_secure(
    email_addr: str,
    password: str,
    token: str,
    status: str,
    report: "TokenReport" = None,
):
    try:
        if status == "VALID":
            outf = Path("output") / "full_verified.txt"
        elif status == "LOCKED":
            outf = Path("output") / "locked.txt"
        else:
            outf = Path("output") / "invalid.txt"

        line = f"{email_addr}:{password}:{token}"
        tmp = outf.with_suffix(".tmp")
        with LOCK:
            existing = []
            if outf.exists():
                with open(outf, "r", encoding="utf-8") as f:
                    existing = f.readlines()
            existing.append(line + "\n")
            with open(tmp, "w", encoding="utf-8") as f:
                f.writelines(existing)
            os.replace(tmp, outf)

        log.success(f"Saved [{status}] → {outf.name}")
    except Exception as e:
        log.error(f"_save_account_secure error: {e}")


# ── UI helpers ────────────────────────────────────────────────────────────────


def _gradient_text(text: str, c1: tuple, c2: tuple) -> str:
    length = max(1, len(text) - 1)
    result = []
    for i, ch in enumerate(text):
        r = int(c1[0] + (c2[0] - c1[0]) * i / length)
        g = int(c1[1] + (c2[1] - c1[1]) * i / length)
        b = int(c1[2] + (c2[2] - c1[2]) * i / length)
        result.append(f"\033[38;2;{r};{g};{b}m{ch}")
    result.append("\033[0m")
    return "".join(result)


def _apply_gradient_block(lines: list, c1=(255, 42, 42), c2=(90, 184, 255)) -> list:
    total = len(lines)
    out = []
    for i, line in enumerate(lines):
        llen = max(1, len(line) - 1)
        row = []
        for j, ch in enumerate(line):
            t = ((i / max(1, total - 1)) + (j / llen)) / 2
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            row.append(f"\033[38;2;{r};{g};{b}m{ch}")
        row.append("\033[0m")
        out.append("".join(row))
    return out


def show_interface():
    # MAX MAYFIELD / Sadie Sink theme — Vecna red -> Hawkins blue
    logo = [
        "                                                         ",
        "     ███╗   ███╗ █████╗ ██╗  ██╗                         ",
        "     ████╗ ████║██╔══██╗╚██╗██╔╝                         ",
        "     ██╔████╔██║███████║ ╚███╔╝                          ",
        "     ██║╚██╔╝██║██╔══██║ ██╔██╗                          ",
        "     ██║ ╚═╝ ██║██║  ██║██╔╝ ██╗                         ",
        "     ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝                         ",
        "                                                                 ",
        "        ██████╗ ██████╗ ██████╗ ███████╗  v3.0-MAX             ",
        "       ██╔════╝██╔═══██╗██╔══██╗██╔════╝                        ",
        "       ██║     ██║   ██║██║  ██║█████╗                          ",
        "       ██║     ██║   ██║██║  ██║██╔══╝                          ",
        "       ╚██████╗╚██████╔╝██████╔╝███████╗                        ",
        "        ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝                        ",
        "                                                         ",
    ]
    print("\n\n")
    try:
        tw = os.get_terminal_size().columns
    except OSError:
        tw = 90
    max_len = max(len(l) for l in logo)
    centered = [" " * max(0, (tw - max_len) // 2) + l for l in logo]
    for line in _apply_gradient_block(centered, (255, 42, 42), (90, 184, 255)):
        print(line)
        time.sleep(0.035)

    tag = "★  MAX MAYFIELD EDITION — by /hackers v3.0  ★"
    print(
        " " * max(0, (tw - len(tag)) // 2)
        + _gradient_text(tag, (255, 42, 42), (255, 200, 80))
    )
    tribute = "Sadie Sink tribute  •  Hawkins 1986  •  Running Up That Hill"
    print(
        " " * max(0, (tw - len(tribute)) // 2)
        + _gradient_text(tribute, (255, 120, 120), (90, 184, 255))
    )
    sub = "In-Browser Token  •  Canvas Noise  •  CDP Wipe  •  Bezier Mouse  •  Email Verified"
    print(
        " " * max(0, (tw - len(sub)) // 2)
        + _gradient_text(sub, (140, 60, 70), (80, 140, 200))
    )
    print("\n\n")


# ── Logging ───────────────────────────────────────────────────────────────────


def log_event(level: str, message: str):
    ts = datetime.now().strftime("%H:%M:%S")
    _palette = {
        "SUCCESS": ((120, 220, 255), (90, 184, 255)),
        "ERROR": ((255, 60, 60), (200, 20, 20)),
        "INFO": ((255, 90, 90), (90, 184, 255)),
        "WARNING": ((255, 210, 80), (255, 140, 40)),
        "CAPTCHA": ((255, 180, 50), (255, 100, 0)),
        "DEBUG": ((120, 120, 120), (80, 80, 80)),
    }
    c1, c2 = _palette.get(level.upper(), _palette["INFO"])
    label = _gradient_text(f"[{level.upper()}]", c1, c2)
    if ":" in message:
        k, v = message.split(":", 1)
        msg = (
            f"{_gradient_text(k.strip(), c1, c2)}"
            f"{_gradient_text(':', (200, 180, 190), (150, 120, 130))} "
            f"{_gradient_text(v.strip(), (200, 180, 190), (150, 120, 130))}"
        )
    else:
        msg = _gradient_text(message, c1, c2)
    ts_col = _gradient_text(f"[{ts}]", (140, 80, 110), (180, 120, 140))
    print(f" {ts_col} {label} {msg}\033[0m")


class Logger:
    def info(self, m):
        log_event("INFO", m)

    def success(self, m):
        log_event("SUCCESS", m)

    def done(self, m):
        log_event("SUCCESS", m)

    def warning(self, m):
        log_event("WARNING", m)

    def error(self, m):
        log_event("ERROR", m)

    def exec_(self, m):
        log_event("INFO", m)

    def passed(self, m):
        log_event("SUCCESS", m)

    def debug(self, m):
        pass

    def divider(self, char="=", width=72):
        print(f"\033[38;2;180;50;100m{'=' * width}\033[0m")

    def block(self, level: str, title: str, fields: list):
        log_event("SUCCESS", title)
        for label, value in fields:
            log_event("INFO", f"{label}: {value}")

    def progress(self, current: int, total: int, message: str):
        log_event("INFO", f"[{current}/{total}] {message}")

    def account_header(self, idx: int, total: int, email: str):
        """Print a prominent per-account section header."""
        try:
            tw = os.get_terminal_size().columns
        except OSError:
            tw = 80
        bar = "─" * min(tw - 2, 72)
        idx_s = _gradient_text(f"[{idx}/{total}]", (255, 180, 50), (255, 100, 0))
        email_s = _gradient_text(email, (255, 42, 42), (90, 184, 255))
        print(f"\033[38;2;100;40;60m{bar}\033[0m")
        print(f"  {idx_s}  {email_s}")


log = Logger()


# ── Progress Tracker ──────────────────────────────────────────────────────────


class ProgressTracker:
    """Thread-safe live stats bar displayed below all log output.

    Call `render()` after each state change to reprint the stats line.
    The bar is printed to stderr so it doesn't pollute redirected stdout.
    """

    def __init__(self, total: int):
        self.total = total
        self.unlocked = 0
        self.failed = 0
        self.skipped = 0
        self.active = 0
        self._lock = threading.Lock()
        self._start = time.time()

    # ── Mutators (all thread-safe) ────────────────────────────────────────

    def inc_unlocked(self):
        with self._lock:
            self.unlocked += 1

    def inc_failed(self):
        with self._lock:
            self.failed += 1

    def inc_skipped(self):
        with self._lock:
            self.skipped += 1

    def set_active(self, n: int):
        with self._lock:
            self.active = n

    def done_count(self) -> int:
        with self._lock:
            return self.unlocked + self.failed + self.skipped

    # ── Rendering ─────────────────────────────────────────────────────────

    def render(self):
        """Print one-line stats bar (overwrites previous line via ANSI)."""
        with self._lock:
            done = self.unlocked + self.failed + self.skipped
            elapsed = time.time() - self._start
            rate = done / elapsed if elapsed > 0 else 0
            remaining = self.total - done
            eta_sec = int(remaining / rate) if rate > 0 else 0
            eta_str = f"{eta_sec // 60}m{eta_sec % 60:02d}s" if rate > 0 else "--:--"
            elapsed_str = f"{int(elapsed) // 60}m{int(elapsed) % 60:02d}s"

            # Build colour segments
            G = "\033[38;2;60;220;100m"  # green
            R = "\033[38;2;255;80;80m"  # red
            Y = "\033[38;2;255;200;60m"  # yellow
            B = "\033[38;2;80;160;255m"  # blue
            DIM = "\033[38;2;120;80;100m"  # dim
            RST = "\033[0m"

            bar = (
                f"\r  {DIM}[STATS]{RST} "
                f"{G}✅ {self.unlocked} unlocked{RST}  "
                f"{R}❌ {self.failed} failed{RST}  "
                f"{Y}⏭  {self.skipped} skipped{RST}  "
                f"{B}⚡ {self.active} active{RST}  "
                f"{DIM}│ {done}/{self.total} done  "
                f"⏱ {elapsed_str}  ETA {eta_str}{RST}   "
            )
            # Use sys.stderr so it never mixes with file-redirected stdout
            sys.stderr.write(bar)
            sys.stderr.flush()

    def finish(self):
        """Print final summary line and newline."""
        sys.stderr.write("\n")
        sys.stderr.flush()
        self.render()
        sys.stderr.write("\n")
        sys.stderr.flush()


# ── Proxy checker ─────────────────────────────────────────────────────────────


class ProxyChecker:
    """Quick liveness + latency check for an HTTP proxy."""

    TEST_URL = "https://discord.com/api/v9/experiments"
    TIMEOUT_SECS = 12

    @staticmethod
    def check(proxy: str) -> tuple[bool, float]:
        """Returns (alive, latency_ms).  latency_ms is -1 on failure."""
        proxies = {"http": proxy, "https": proxy}
        t0 = time.time()
        try:
            r = requests.get(
                ProxyChecker.TEST_URL,
                proxies=proxies,
                timeout=ProxyChecker.TIMEOUT_SECS,
                allow_redirects=False,
            )
            latency = (time.time() - t0) * 1000
            # Discord experiments returns 200 or 401/403; all mean proxy works
            return r.status_code in (200, 401, 403), latency
        except Exception:
            return False, -1.0

    @staticmethod
    async def check_async(proxy: str) -> tuple[bool, float]:
        return await asyncio.to_thread(ProxyChecker.check, proxy)


# ── Rate-limit guard ──────────────────────────────────────────────────────────


async def rate_limit_guard(token: str, ctx) -> tuple[bool, float]:
    """Pre-flight check — returns (ok, retry_after_secs).

    Hits /users/@me/library (a cheap read endpoint Discord uses for spam
    detection) and checks for 429.  If rate-limited, returns the retry_after
    so the caller can skip or wait.
    """
    try:
        headers = ctx.get_headers(
            endpoint_type="api", include_auth=token, include_fingerprint=False
        )
        r = await asyncio.to_thread(
            ctx.session.get,
            "https://discord.com/api/v9/users/@me/library",
            headers=headers,
            timeout=10,
        )
        if r.status_code == 429:
            retry_after = r.json().get("retry_after", 60.0)
            return False, retry_after
        return True, 0.0
    except Exception:
        return True, 0.0  # network error ≠ rate-limit; proceed anyway


# ── Live build-number fetcher ──────────────────────────────────────────────────

_BUILD_CACHE: dict = {"number": None, "fetched_at": 0.0}
_BUILD_TTL = 30 * 60  # refresh every 30 min


async def get_live_build_number(fallback: int = 503231) -> int:
    """Fetch Discord's current build number asynchronously (cached)."""
    now = time.time()
    if _BUILD_CACHE["number"] and now - _BUILD_CACHE["fetched_at"] < _BUILD_TTL:
        return _BUILD_CACHE["number"]
    try:
        build = await asyncio.to_thread(fetch_discord_build)
        if build:
            _BUILD_CACHE["number"] = build
            _BUILD_CACHE["fetched_at"] = now
            log.success(f"Live Discord build: {build}")
            return build
    except Exception:
        pass
    return fallback
