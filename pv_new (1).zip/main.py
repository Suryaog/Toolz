#!/usr/bin/env python3

from __future__ import annotations

import asyncio
import os
import sys
import random
import re
import tls_client
import time
from pathlib import Path
from typing import Optional, Tuple, List
from dataclasses import dataclass
from datetime import datetime
import uuid
import json
import base64
import email as _email_module
import email.utils as _email_utils

sys.path.append(os.path.abspath(os.path.dirname(__file__)))

import requests as sync_requests
from curl_cffi import requests as curl_requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from sms_activate import SMSActivateClient
from five_sim import FiveSimClient
from utils import (
    log,
    log_event,
    _gradient_text,
    show_interface,
    CustomMailServer,
    _COUNTRY_INFO,
    build_super_properties,
    fetch_discord_build,
    deep_check_token,
    _save_account_secure,
    is_email_verified,
    ProgressTracker,
    ProxyChecker,
    rate_limit_guard,
    get_live_build_number,
)

# ============================================================================
# CONFIGURATION
# ============================================================================

LOCKED_ACCOUNTS_FILE = Path("locked_accounts.txt")
VALID_ACCOUNTS_FILE = Path(
    "valid_accounts.txt"
)  # Optional: valid tokens that need a phone
UNLOCKED_OUTPUT_FILE = Path("output/unlocked.txt")
FAILED_OUTPUT_FILE = Path("output/unlock_failed.txt")
PHONE_ADDED_FILE = Path("output/phone_added.txt")  # Valid tokens that got a phone added

ONYX_API_KEY = "onyx_0f8a06235d194e7daf157bd58799e56a"
REZO_API_KEY = "sk-solv-Tlq4wptG4mSNxONk7Wydq88ATCuPcXz4khS6ueQRksmBdERr"  # Set via user input at startup  (huzaif.online)
HACKERS_API_KEY = ""  # /hackers key
HACKERS_BASE_URL = "https://discord.gg/hackers"  # Permanent — never changes
# Back-compat aliases (old Manthan names)
MANTHAN_API_KEY = HACKERS_API_KEY
MANTHAN_BASE_URL = HACKERS_BASE_URL
LOCAL_SOLVER_URL = "http://localhost:5001"  # Local Browser_solver/solver.py (port 5002)
CAPTCHA_SOLVER = "onyx"  # "onyx" | "rezo" | "hackers" | "local" — chosen at startup

PHONE_COUNTRY_CODE = 16  # UK — best Discord success rate on sms-activate
PHONE_REUSE_WINDOW = 20 * 60
PHONE_CANCEL_TIMEOUT = 2 * 60

# Countries that only provide virtual numbers — Discord REJECTS these
# Source: sms-activate dashboard "Only virtual" label
VIRTUAL_ONLY_COUNTRIES = {
    90,
    91,
    7,
}  # Turkey, India, Russia (common virtual-only for Discord)

# Reliable countries for sms-activate (low price, high stock, non-virtual)
RELIABLE_SMS_ACTIVATE_COUNTRIES = [
    16,
    68,
    89,
    2,
    9,
    31,
]  # UK, Colombia, Vietnam, Kazakhstan, China, Nigeria

PROXY_SESSION: Optional[str] = None

IMPERSONATE = "chrome136"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"
SEC_CH_UA = '"Not(A:Brand";v="8", "Chromium";v="136", "Google Chrome";v="136"'
BROWSER_VERSION = "136.0.0.0"
FALLBACK_BUILD = 503231


def generate_client_launch_id():
    return str(uuid.uuid4())


def generate_launch_signature():
    return str(uuid.uuid4())


# ============================================================================
# SESSION CONTEXT
# ============================================================================


class SessionContext:
    def __init__(self, proxy=None):
        self.session = curl_requests.Session(impersonate=IMPERSONATE)
        if proxy and proxy.strip():
            p = proxy if proxy.startswith("http") else f"http://{proxy}"
            self.session.proxies = {"http": p, "https": p}
        self.build_number = FALLBACK_BUILD
        self._proxy = proxy
        self.fingerprint = None
        self.super_properties = self._encode_super_props()

    def _encode_super_props(self) -> str:
        props = {
            "os": "Windows",
            "browser": "Chrome",
            "device": "",
            "system_locale": "en-US",
            "has_client_mods": False,
            "browser_user_agent": UA,
            "browser_version": BROWSER_VERSION,
            "os_version": "10",
            "referrer": "",
            "referring_domain": "",
            "referrer_current": "",
            "referring_domain_current": "",
            "release_channel": "stable",
            "client_build_number": self.build_number,
            "client_event_source": None,
            "client_launch_id": generate_client_launch_id(),
            "launch_signature": generate_launch_signature(),
            "client_heartbeat_session_id": str(uuid.uuid4()),
            "client_app_state": "focused",
        }
        return base64.b64encode(
            json.dumps(props, separators=(",", ":")).encode()
        ).decode()

    def get_fingerprint(self):
        try:
            r = self.session.get(
                "https://discord.com/api/v9/experiments",
                headers=self.get_headers(
                    endpoint_type="api", include_fingerprint=False
                ),
                timeout=10,
            )
            if r.status_code == 200:
                fp = r.json().get("fingerprint")
                if fp:
                    self.fingerprint = fp
                    return fp
        except Exception:
            pass
        return None

    def get_headers(
        self,
        endpoint_type="api",
        include_auth=None,
        include_fingerprint=True,
        referer="https://discord.com/channels/@me",
    ) -> dict:
        headers = {
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "en-US,en;q=0.9",
            "Priority": "u=1, i",
            "User-Agent": UA,
            "Sec-Ch-Ua": SEC_CH_UA,
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"Windows"',
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
        }
        if endpoint_type == "api":
            headers["Content-Type"] = "application/json"
            headers["Origin"] = "https://discord.com"
            headers["Referer"] = referer
            headers["X-Discord-Locale"] = "en-US"
            headers["X-Discord-Timezone"] = "Europe/London"
            headers["X-Debug-Options"] = "bugReporterEnabled"
            headers["X-Discord-Device-Id"] = str(uuid.uuid4())
            headers["X-Super-Properties"] = self.super_properties
        if include_auth:
            headers["Authorization"] = include_auth
        if include_fingerprint and self.fingerprint:
            headers["X-Fingerprint"] = self.fingerprint
        return headers


# ============================================================================
# DATA CLASSES - UPDATED FOR email:password:token FORMAT
# ============================================================================


@dataclass
class LockedAccount:
    """FORMAT: email:password:token"""

    email: str
    discord_password: str  # 2nd field - Discord account password
    token: str  # 3rd field - Discord token/auth
    original_line: str


@dataclass
class ActivePhoneNumber:
    number: str
    activation_id: str
    rented_at: float
    client: SMSActivateClient | FiveSimClient
    is_valid: bool = True
    last_used_code: Optional[str] = None

    def is_expired(self) -> bool:
        return time.time() - self.rented_at > PHONE_REUSE_WINDOW

    def remaining_seconds(self) -> int:
        return max(0, int(PHONE_REUSE_WINDOW - (time.time() - self.rented_at)))


# ============================================================================
# TOKEN DEEP-CHECK DISPLAY
# ============================================================================


def _display_token_report(report) -> None:
    """Print a rich token report card after deep-check."""
    G = "\033[38;2;60;220;100m"
    R = "\033[38;2;255;80;80m"
    Y = "\033[38;2;255;200;60m"
    DIM = "\033[38;2;140;90;120m"
    RST = "\033[0m"

    def yn(v):
        return f"{G}YES{RST}" if v else f"{R}NO{RST}"

    def hl(v):
        return f"{Y}{v}{RST}"

    status_col = (
        f"{G}VALID{RST}"
        if report.status == "VALID"
        else f"{R}LOCKED{RST}"
        if report.status == "LOCKED"
        else f"{R}INVALID{RST}"
        if report.status == "INVALID"
        else f"{Y}{report.status}{RST}"
    )

    print(
        f"  {DIM}┌─ Token Deep-Check ───────────────────────────────────────────{RST}"
    )
    print(f"  {DIM}│{RST}  Status    : {status_col}")
    if report.username:
        print(
            f"  {DIM}│{RST}  Username  : {hl(report.username + '#' + report.user_id)}"
        )
    print(f"  {DIM}│{RST}  Verified  : {yn(report.verified)}")
    print(f"  {DIM}│{RST}  Phone     : {yn(report.phone)}")
    print(f"  {DIM}│{RST}  MFA       : {yn(report.mfa)}")
    print(f"  {DIM}│{RST}  Nitro     : {yn(report.nitro)}")
    if report.guild_count >= 0:
        print(f"  {DIM}│{RST}  Guilds    : {hl(str(report.guild_count))}")
    if report.flag_labels:
        print(f"  {DIM}│{RST}  Flags     : {hl(', '.join(report.flag_labels))}")
    print(f"  {DIM}└─────────────────────────────────────────────────────────────{RST}")


# ============================================================================
# TOKEN LOGIN & VALIDATION
# ============================================================================


async def login_with_token(token: str, ctx: SessionContext) -> Tuple[bool, dict, str]:
    """Login using token and get account info. Returns (success, user_data, status)"""
    try:
        headers = ctx.get_headers(
            endpoint_type="api", include_auth=token, include_fingerprint=True
        )
        response = await asyncio.to_thread(
            ctx.session.get,
            "https://discord.com/api/v9/users/@me",
            headers=headers,
            timeout=15,
        )

        if response.status_code == 200:
            user_data = response.json()
            return True, user_data, "VALID"
        elif response.status_code == 403:
            # Account is locked/disabled
            error_data = response.json() if response.text else {}
            return True, error_data, "LOCKED"
        else:
            return False, {}, f"INVALID_{response.status_code}"

    except Exception as e:
        return False, {}, f"ERROR_{str(e)}"


async def check_account_locked_status(
    token: str, ctx: SessionContext
) -> Tuple[bool, str, dict]:
    """Check if account needs unlock. Returns (needs_unlock, status, data)"""
    success, data, status = await login_with_token(token, ctx)

    if not success:
        return False, status, data

    if status == "VALID":
        # Account is fine, check if it needs phone/email verification
        user = data
        phone = user.get("phone", "")
        verified = user.get("verified", False)

        needs_verification = (not phone) or (not verified)
        if needs_verification:
            return True, "NEEDS_VERIFICATION", user
        else:
            return False, "ALREADY_UNLOCKED", user

    elif status == "LOCKED":
        # Account is locked, needs unlock
        return True, "LOCKED", data
    else:
        return False, status, data


# ============================================================================
# PHONE MANAGER
# ============================================================================


class PhoneNumberManager:
    """Manages a single phone number for multiple unlocks within 20 minutes."""

    # Human-readable names for each provider key
    _PROVIDER_DISPLAY = {
        "sms_activate": "HeroSMS",
        "5sim": "5Sim",
    }

    def __init__(
        self,
        provider: str = "sms_activate",
        country_code: str = "43",
        reuse: bool = True,
        fallback_countries: Optional[List[str]] = None,
    ):
        self.provider = provider.lower()
        self.country_code = country_code
        self.reuse = reuse
        self.fallback_countries: List[str] = fallback_countries or []

        # Add reliable fallbacks if none provided for sms_activate
        if self.provider == "sms_activate" and not self.fallback_countries:
            self.fallback_countries = [
                str(c)
                for c in RELIABLE_SMS_ACTIVATE_COUNTRIES
                if str(c) != str(self.country_code)
            ]

        self.active_number: Optional[ActivePhoneNumber] = None
        self._lock = asyncio.Lock()

    @property
    def display_name(self) -> str:
        """Human-readable provider label shown in logs."""
        return self._PROVIDER_DISPLAY.get(self.provider, self.provider.capitalize())

    async def get_number(self) -> Tuple[str, str, SMSActivateClient | FiveSimClient]:
        async with self._lock:
            if (
                self.reuse
                and self.active_number
                and not self.active_number.is_expired()
                and self.active_number.is_valid
            ):
                remaining = self.active_number.remaining_seconds()
                log.info(
                    f"Reusing active phone number {self.active_number.number} (expires in {remaining}s)"
                )
                try:
                    await asyncio.to_thread(
                        self.active_number.client.request_another_code,
                        self.active_number.activation_id,
                    )
                    log.info("Requested another OTP via API")
                except Exception as e:
                    log.warning(f"Failed to request another OTP: {e}")
                return (
                    self.active_number.number,
                    self.active_number.activation_id,
                    self.active_number.client,
                )

            if self.active_number:
                log.info(f"Phone number {self.active_number.number} expired/cancelled")
                self.active_number = None

            log.info(
                f"Renting new phone number (Provider: {self.display_name}, Country: {self.country_code})..."
            )

            if self.provider == "5sim":
                client = FiveSimClient()
                service = FiveSimClient.SERVICE_DISCORD
            else:
                client = SMSActivateClient()
                service = SMSActivateClient.SERVICE_DISCORD

            balance = await asyncio.to_thread(client.get_balance)
            log.info(f"{self.display_name} balance: ${balance:.2f}")

            if balance < 0.05:
                raise Exception(
                    f"Insufficient balance on {self.provider} for phone rental"
                )

            # Map country_code for 5sim if it looks like a number but 5sim needs name
            country = self.country_code
            if self.provider == "5sim" and country.isdigit():
                cc_map = {
                    "0": "russia",
                    "43": "germany",
                    "16": "england",
                    "78": "france",
                    "90": "turkey",
                    "62": "indonesia",
                    "91": "india",
                    "55": "brazil",
                    "1": "usa",
                }
                country = cc_map.get(country, "any")

            if self.provider == "5sim":
                activation_id, phone_number = await asyncio.to_thread(
                    client.get_number, service=service, country=country
                )
            else:
                # For sms_activate: pass fallback countries so it auto-tries them on NO_NUMBERS
                fallbacks = (
                    [int(c) for c in self.fallback_countries if c.isdigit()]
                    if self.fallback_countries
                    else None
                )
                activation_id, phone_number = await asyncio.to_thread(
                    client.get_number,
                    service=service,
                    country=int(country) if str(country).isdigit() else 0,
                    retries=2,
                    retry_delay=3.0,
                    fallback_countries=fallbacks,
                )
            log.success(f"Rented number: +{phone_number} (ID: {activation_id})")

            self.active_number = ActivePhoneNumber(
                number=phone_number,
                activation_id=activation_id,
                rented_at=time.time(),
                client=client,
            )
            return phone_number, activation_id, client

    async def mark_invalid(self):
        if self.active_number:
            self.active_number.is_valid = False
            log.warning(f"Marked {self.active_number.number} as invalid")

    def record_used_code(self, code: str):
        if self.active_number:
            self.active_number.last_used_code = code

    async def cancel_current(self):
        if self.active_number:
            elapsed = time.time() - self.active_number.rented_at
            if elapsed < PHONE_CANCEL_TIMEOUT:
                log.info(
                    f"Cancelling activation {self.active_number.activation_id} for refund"
                )
                try:
                    await asyncio.to_thread(
                        self.active_number.client.cancel_activation,
                        self.active_number.activation_id,
                    )
                except Exception as e:
                    log.warning(f"Cancel error: {e}")
            else:
                log.info(f"Cancel window expired - completing anyway")
                try:
                    await asyncio.to_thread(
                        self.active_number.client.complete_activation,
                        self.active_number.activation_id,
                    )
                except Exception:
                    pass
            self.active_number = None


# ============================================================================
# CAPTCHA SOLVER
# ============================================================================


class OnyxDirectSolver:
    """Direct API client for Onyx hCaptcha solver."""

    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://onyxsolver.io"

    def solve_hcaptcha(self, sitekey, url, rqdata=None, proxy=None):
        task = {
            "type": "PopularCaptchaTask" if proxy else "PopularCaptchaTaskProxyless",
            "websiteURL": url,
            "websiteKey": sitekey,
        }
        if rqdata:
            task["rqdata"] = rqdata
        if proxy:
            task["proxy"] = proxy if "://" not in proxy else proxy.split("://")[-1]

        try:
            resp = sync_requests.post(
                f"{self.base_url}/api/createTask",
                json={"clientKey": self.api_key, "task": task},
                timeout=30,
                verify=False,
            )
        except Exception:
            resp = sync_requests.post(
                f"{self.base_url}/api/createTask",
                json={"clientKey": self.api_key, "task": task},
                timeout=30,
            )

        result = resp.json()

        if result.get("errorId") != 0:
            raise Exception(result.get("errorDescription", "Unknown error"))

        task_id = result["taskId"]
        log.info(f"[Onyx] Task created! Awaiting solution...")

        for attempt in range(60):
            time.sleep(3)
            try:
                resp = sync_requests.post(
                    f"{self.base_url}/api/getTaskResult",
                    json={"clientKey": self.api_key, "taskId": task_id},
                    timeout=15,
                    verify=False,
                )
            except Exception:
                continue

            data = resp.json()
            if data.get("status") == "ready":
                solution = data.get("solution", {})
                token = solution.get("gRecaptchaResponse")
                log.success(f"[Onyx] Captcha solved!")
                return token
            elif data.get("errorId") != 0:
                raise Exception(data.get("errorDescription", "Unknown error"))

        raise Exception("Timeout waiting for captcha")


class RezoSolver:
    """
    Direct API client for Rezo Solver (https://huzaif.online).
    Docs: POST /createtask  →  POST /gettaskresult  (token in 'uuid' field)
    All endpoints are POST-only; polling interval 1-2 s.
    """

    BASE_URL = "https://huzaif.online"

    def __init__(self, api_key: str):
        self.api_key = api_key
        self.session = sync_requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})

    def solve_hcaptcha(
        self,
        sitekey: str,
        siteurl: str,
        rqdata: str = None,
        proxy: str = None,
    ) -> str:
        """
        Solve hCaptcha via Rezo Solver.
        Returns the captcha token (uuid field on success).
        """
        task: dict = {
            "site_url": siteurl,
            "site_key": sitekey,
            "ua": UA,
        }
        if rqdata:
            task["rqdata"] = rqdata
        if proxy:
            task["proxy"] = proxy if proxy.startswith("http") else f"http://{proxy}"
            self.session.proxies = {"http": proxy, "https": proxy}

        create_payload = {"clientKey": self.api_key, "task": task}

        log.info(f"[Rezo] Creating task for {siteurl}")

        for retry in range(3):
            try:
                resp = self.session.post(
                    f"{self.BASE_URL}/createtask",
                    json=create_payload,
                    timeout=30,
                )
                if resp.status_code != 200:
                    raise Exception(f"HTTP {resp.status_code}: {resp.text[:200]}")

                result = resp.json()
                task_id = result.get("taskId")
                if not task_id:
                    raise Exception(f"No taskId in response: {result}")

                log.info(f"[Rezo] Task created: {task_id} — polling...")

                # Poll — recommended interval 1-2 s per docs
                for attempt in range(180):  # up to 3 min
                    time.sleep(2)
                    try:
                        poll = self.session.post(
                            f"{self.BASE_URL}/gettaskresult",
                            json={"clientKey": self.api_key, "taskId": task_id},
                            timeout=15,
                        ).json()
                    except Exception as pe:
                        if attempt >= 175:
                            raise
                        log.warning(f"[Rezo] Poll error: {pe}, retrying...")
                        continue

                    status = poll.get("status", "")

                    if status == "success":
                        token = poll.get("uuid", "")
                        if not token:
                            raise Exception("[Rezo] success but no uuid in response")
                        log.success("[Rezo] Captcha solved!")
                        return token

                    elif status == "error":
                        raise Exception("[Rezo] Task returned error — will retry")

                    # status == "solving" — keep waiting
                    if attempt % 15 == 0 and attempt > 0:
                        log.info(f"[Rezo] Still solving... ({attempt * 2}s elapsed)")

                raise Exception("[Rezo] Timed out after 360 s")

            except Exception as e:
                if retry == 2:
                    raise Exception(f"[Rezo] API failed after 3 retries: {e}")
                log.warning(f"[Rezo] Attempt {retry + 1} failed: {e}, retrying...")
                time.sleep(2**retry)
                continue


# ============================================================================
# /hackers REMOTE SOLVER  (https://discord.gg/hackers)
# Max Mayfield Edition — Sadie Sink tribute solver
# ============================================================================


class HackersSolver:
    """
    Client for the /hackers cloud API at https://discord.gg/hackers.
    Permanent URL — no need to update on restart (per api_docs.md).
    Protocol: POST /api/createTask  →  GET /api/getResult/:taskId
    """

    def __init__(self, api_key: str, base_url: str = None):
        # default resolved at runtime so HACKERS_BASE_URL global is respected
        if base_url is None:
            base_url = HACKERS_BASE_URL
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

    def solve_hcaptcha(
        self,
        sitekey: str,
        siteurl: str,
        rqdata: str = None,
        proxy: str = None,
    ) -> str:
        """
        Submit an hCaptcha task and poll until solved.
        Returns the captcha token string.
        Raises Exception on failure / timeout.
        """
        payload = {"sitekey": sitekey, "url": siteurl, "user_agent": UA}
        if rqdata:
            payload["rqdata"] = rqdata
        if proxy:
            payload["proxy"] = proxy if proxy.startswith("http") else f"http://{proxy}"

        log.info(f"[/hackers] Submitting task → {siteurl}")
        try:
            resp = sync_requests.post(
                f"{self.base_url}/api/createTask",
                headers=self.headers,
                json=payload,
                timeout=20,
            )
            result = resp.json()
        except Exception as e:
            raise Exception(f"[/hackers] Network error on createTask: {e}")

        if not result.get("success"):
            raise Exception(
                f"[/hackers] Task creation failed: {result.get('error', result)}"
            )

        task_id = result["taskId"]
        log.info(f"[/hackers] Task created: {task_id} — polling...")

        start = time.time()
        spinner = ["-", "\\\\", "|", "/"]
        i = 0
        while time.time() - start < 180:
            time.sleep(2)
            try:
                poll = sync_requests.get(
                    f"{self.base_url}/api/getResult/{task_id}",
                    headers=self.headers,
                    timeout=10,
                ).json()
            except Exception:
                continue

            status = poll.get("status", "unknown")
            elapsed = time.time() - start
            spin = spinner[i % len(spinner)]
            i += 1

            if status == "success":
                token = poll.get("solution", {}).get("token", "")
                if not token:
                    raise Exception("[/hackers] success but no token in response")
                cost = poll.get("cost", "?")
                log.success(f"[/hackers] Solved in {elapsed:.1f}s  cost=${cost}")
                return token

            elif status in ("error", "timeout"):
                raise Exception(f"[/hackers] Task failed: {poll.get('error', status)}")

            else:
                if i % 5 == 0:
                    log.info(
                        f"[/hackers] {spin} status={status}  elapsed={elapsed:.0f}s"
                    )

        raise Exception("[/hackers] Timed out waiting for captcha solution (180s)")


# ============================================================================
# LOCAL BROWSER SOLVER  (Browser_solver/solver.py  ·  localhost:5002)
# ============================================================================


class LocalBrowserSolver:
    """
    Client for the local hCaptcha browser solver (Browser_solver/solver.py).
    Uses the v2 API: POST /api/createTask  →  GET /api/getResult/<taskId>
    The solver must be running separately on LOCAL_SOLVER_URL (default port 5002).
    """

    def __init__(self, base_url: str = None):
        self.base_url = (base_url or LOCAL_SOLVER_URL).rstrip("/")

    def solve_hcaptcha(
        self,
        sitekey: str,
        siteurl: str,
        rqdata: str = None,
        proxy: str = None,
    ) -> str:
        payload = {"sitekey": sitekey, "url": siteurl}
        if rqdata:
            payload["rqdata"] = rqdata
        if proxy:
            payload["proxy"] = proxy if proxy.startswith("http") else f"http://{proxy}"

        log.info(f"[LocalSolver] Submitting task → {siteurl}")
        try:
            resp = sync_requests.post(
                f"{self.base_url}/api/createTask",
                json=payload,
                timeout=15,
            )
            log.info(
                f"[LocalSolver] createTask HTTP {resp.status_code}: {resp.text[:200]}"
            )
            if resp.status_code not in (200, 202):
                raise Exception(f"HTTP {resp.status_code}: {resp.text}")
            result = resp.json()
        except Exception as e:
            raise Exception(f"[LocalSolver] Network error on createTask: {e}")

        task_id = result.get("taskId")
        if not task_id:
            raise Exception(f"[LocalSolver] No taskId in response: {result}")
        log.info(f"[LocalSolver] Task created: {task_id} — polling...")

        start = time.time()
        attempt = 0
        while time.time() - start < 180:
            time.sleep(3)
            attempt += 1
            try:
                poll = sync_requests.get(
                    f"{self.base_url}/api/getResult/{task_id}",
                    timeout=10,
                ).json()
            except Exception:
                continue

            status = poll.get("status", "unknown")
            log.info(f"[LocalSolver] Poll {attempt}: status={status}")
            if status == "success":
                token = poll.get("solution", {}).get("token", "")
                if not token:
                    raise Exception("[LocalSolver] success status but no token")
                elapsed = round(time.time() - start, 1)
                log.success(f"[LocalSolver] Solved in {elapsed}s")
                return token
            elif status == "error":
                raise Exception(
                    f"[LocalSolver] Task failed: {poll.get('error', 'unknown')}"
                )
            else:
                if attempt % 5 == 0:
                    log.info(
                        f"[LocalSolver] Still solving... ({int(time.time() - start)}s, status={status})"
                    )

        raise Exception("[LocalSolver] Timed out after 180s")


# ============================================================================
# UNIFIED CAPTCHA SOLVER DISPATCHER
# ============================================================================


def _solve_captcha_sync(
    sitekey: str,
    siteurl: str,
    rqdata: str = "",
    proxy: str = None,
) -> Optional[str]:
    """
    Unified captcha dispatch — picks the active solver from CAPTCHA_SOLVER.
    Returns the token string or None on failure.
    Retries up to 3 times for transient errors.
    """
    cap_proxy = proxy  # full http://... string

    for attempt in range(1, 4):
        try:
            if CAPTCHA_SOLVER == "rezo":
                solver = RezoSolver(REZO_API_KEY)
                cap = solver.solve_hcaptcha(sitekey, siteurl, rqdata or None, cap_proxy)

            elif CAPTCHA_SOLVER in ("hackers", "manthan"):
                solver = HackersSolver(HACKERS_API_KEY, HACKERS_BASE_URL)
                cap = solver.solve_hcaptcha(sitekey, siteurl, rqdata or None, cap_proxy)

            elif CAPTCHA_SOLVER == "local":
                solver = LocalBrowserSolver(LOCAL_SOLVER_URL)
                cap = solver.solve_hcaptcha(sitekey, siteurl, rqdata or None, cap_proxy)

            else:  # onyx (default)
                solver = OnyxDirectSolver(ONYX_API_KEY)
                cap = solver.solve_hcaptcha(sitekey, siteurl, rqdata or None, cap_proxy)

            if cap:
                return cap
            log.warning(f"[Captcha] Attempt {attempt}: solver returned empty token")

        except Exception as e:
            log.warning(f"[Captcha] Attempt {attempt} failed ({CAPTCHA_SOLVER}): {e}")
            if attempt < 3:
                time.sleep(2**attempt)

    log.error(f"[Captcha] All 3 attempts failed — giving up")
    return None


# ============================================================================
# EMAIL VERIFICATION
# ============================================================================


def extract_authorization_link(msg) -> Optional[str]:
    """Helper to extract new location authorization link from email."""
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/html":
                try:
                    body = part.get_payload(decode=True).decode(errors="ignore")
                    break
                except Exception:
                    pass
        if not body:
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    try:
                        body = part.get_payload(decode=True).decode(errors="ignore")
                        break
                    except Exception:
                        pass
    else:
        try:
            body = msg.get_payload(decode=True).decode(errors="ignore")
        except Exception:
            body = ""

    body_clean = (
        body.replace("&amp;", "&")
        .replace("&#38;", "&")
        .replace("%23", "#")
        .replace("%3D", "=")
    )

    def find_url(pattern_str):
        href_pattern = re.compile(
            rf'href=["\']({pattern_str}[^"\']*)["\']', re.IGNORECASE
        )
        match = href_pattern.search(body)
        if match:
            return (
                re.sub(r"\s+", "", match.group(1))
                .replace("&amp;", "&")
                .replace("&#38;", "&")
            )
        plain_pattern = re.compile(rf'({pattern_str}[^\s"\'<>]+)', re.IGNORECASE)
        match = plain_pattern.search(body_clean)
        if match:
            return match.group(1)
        return None

    authorize_ip = find_url(r"https?://(?:canary\.)?discord\.com/authorize-ip")
    if authorize_ip:
        return authorize_ip.rstrip(")")

    verify = find_url(r"https?://(?:canary\.)?discord\.com/verify\?token=")
    if verify:
        return verify

    email_ver = find_url(
        r"https?://(?:canary\.)?discord\.com/email-verification\?token="
    )
    if email_ver:
        return email_ver

    track_matches = []
    for m in re.finditer(
        r'href=["\'](https?://click\.discord\.com/ls/click\?[^"\']*)["\']',
        body,
        re.IGNORECASE,
    ):
        track_matches.append(
            re.sub(r"\s+", "", m.group(1)).replace("&amp;", "&").replace("&#38;", "&")
        )
    for m in re.finditer(
        r'(https?://click\.discord\.com/ls/click\?[^\s"\'<>]+)',
        body_clean,
        re.IGNORECASE,
    ):
        track_matches.append(m.group(1))
    track_matches = list(set(track_matches))

    if track_matches:
        for t_url in track_matches:
            try:
                r = sync_requests.get(t_url, allow_redirects=False, timeout=10)
                loc = r.headers.get("Location", "")
                if loc and "authorize-ip" in loc and "#token=" in loc:
                    return loc
            except Exception:
                pass

    broad = find_url(r"https?://(?:[\w-]+\.)?discord\.com/[a-zA-Z0-9_\-]+")
    if broad:
        return broad
    return None


async def verify_email_authorization(
    session, proxy: str, email_addr: str, email_password: str, timeout: int = 120
) -> bool:
    """Verify new location via IMAP email."""
    log.info("Connecting to IMAP — waiting for new-location verification email...")
    imap = CustomMailServer()
    if not imap.connect(email_addr, email_password):
        log.error("Failed to connect to IMAP for authorization")
        return False

    LOCATION_KEYWORDS = [
        "new location",
        "new login",
        "verify discord login",
        "verify your login",
        "login from new",
        "authorize",
    ]
    CUTOFF_SECS = 10 * 60

    try:
        loop_start = time.time()
        seen_ids: set = set()

        while time.time() - loop_start < timeout:
            try:
                imap.connection.noop()
                status, messages = imap.connection.search(None, "ALL")
                if status != "OK":
                    await asyncio.sleep(5)
                    continue

                msg_ids = messages[0].split()

                for num in list(reversed(msg_ids[-20:])):
                    status2, data = imap.connection.fetch(num, "(RFC822)")
                    if status2 != "OK":
                        continue

                    msg = _email_module.message_from_bytes(data[0][1])
                    subject_raw = msg.get("Subject", "")
                    from_raw = msg.get("From", "")
                    date_raw = msg.get("Date", "")

                    if "discord" not in from_raw.lower():
                        continue
                    if not any(kw in subject_raw.lower() for kw in LOCATION_KEYWORDS):
                        continue

                    msg_dt = _email_utils.parsedate_to_datetime(date_raw)
                    if time.time() - msg_dt.timestamp() > CUTOFF_SECS:
                        continue
                    if num in seen_ids:
                        continue
                    seen_ids.add(num)

                    url = extract_authorization_link(msg)
                    if not url:
                        continue

                    actual_url = url
                    if "click.discord.com" in url:
                        try:
                            r1 = await asyncio.to_thread(
                                sync_requests.get,
                                url,
                                allow_redirects=False,
                                timeout=10,
                                proxies={"http": proxy, "https": proxy}
                                if proxy
                                else None,
                            )
                            loc = r1.headers.get("Location", "")
                            if loc and "discord.com" in loc:
                                actual_url = loc
                            else:
                                r2 = await asyncio.to_thread(
                                    sync_requests.get,
                                    url,
                                    allow_redirects=True,
                                    timeout=10,
                                    proxies={"http": proxy, "https": proxy}
                                    if proxy
                                    else None,
                                )
                                actual_url = r2.url
                        except Exception:
                            pass

                    if "authorize-ip" in actual_url and "#token=" in actual_url:
                        token_str = actual_url.split("#token=")[-1].strip().rstrip(")")
                        try:
                            api_r = await asyncio.to_thread(
                                sync_requests.post,
                                "https://discord.com/api/v9/auth/authorize-ip",
                                json={"token": token_str},
                                headers={
                                    "Content-Type": "application/json",
                                    "User-Agent": UA,
                                    "Origin": "https://discord.com",
                                    "Referer": "https://discord.com/authorize-ip",
                                },
                                timeout=15,
                                proxies={"http": proxy, "https": proxy}
                                if proxy
                                else None,
                            )
                            if api_r.status_code in (200, 204):
                                imap.connection.store(num, "+FLAGS", "\\Seen")
                                log.success("IP authorized successfully via API")
                                return True
                        except Exception as e:
                            log.warning(f"Direct API authorize failed: {e}")

                    log.info(
                        f"Visiting fallback verification URL: {actual_url[:80]}..."
                    )
                    try:
                        await asyncio.to_thread(session.get, actual_url, timeout=15)
                        imap.connection.store(num, "+FLAGS", "\\Seen")
                        log.success("IP authorized via HTTP GET")
                        return True
                    except Exception as e:
                        log.warning(f"Fallback GET failed: {e}")

                await asyncio.sleep(5)
            except Exception as e:
                await asyncio.sleep(5)
        return False
    finally:
        imap.logout()


async def api_verify_email_after_phone(
    session, proxy: str, email_addr: str, email_password: str, token: str
) -> bool:
    """Check IMAP for verification email after phone is added."""
    if token and await is_email_verified(token):
        return True

    log.info("Email not verified. Starting IMAP verification...")
    imap = CustomMailServer()
    if not imap.connect(email_addr, email_password):
        return False

    try:
        verify_url = await imap.wait_for_discord_verification(timeout=120)
        if not verify_url:
            return False

        log.info(f"Opening verification URL: {verify_url[:80]}...")
        try:
            await asyncio.to_thread(session.get, verify_url, timeout=15)
            log.success("Opened verification URL")
        except:
            pass

        await asyncio.sleep(3)
        if token:
            for _ in range(30):
                if await is_email_verified(token):
                    return True
                await asyncio.sleep(2)
        return True
    finally:
        imap.logout()


# ============================================================================
# PHONE VERIFICATION
# ============================================================================


async def api_phone_verification(
    ctx, phone_manager, token: str, account_password: str, proxy: str = None
) -> bool:
    """Implement phone verification logic purely via direct requests."""
    for attempt in range(3):
        log.info(f"Phone verification attempt {attempt + 1}/3")
        try:
            phone_number, activation_id, sms_client = await phone_manager.get_number()
        except Exception as e:
            log.error(f"Failed to get phone number: {e}")
            return False

        # Normalize to proper E.164 format.
        # HeroSMS (sms_activate) may return numbers without the country dial
        # code prefix (e.g. '1234567890' instead of '441234567890' for UK),
        # so we look up the expected dial code from _COUNTRY_INFO and prepend
        # it when missing.
        # 5sim always returns fully-qualified E.164 numbers (country code
        # already included), and its country_code is a name string like
        # "england" — NOT a digit — so we skip normalization entirely to avoid
        # accidentally prepending the wrong dial code (e.g. Russia "7").
        raw_phone = phone_number.lstrip("+").replace(" ", "").replace("-", "")
        cc_str = str(phone_manager.country_code)
        if cc_str.isdigit():
            # sms_activate path: numeric country code, may need dial prefix
            try:
                country_info = _COUNTRY_INFO.get(int(cc_str))
                if country_info:
                    dial = country_info[0]  # e.g. '44' for UK
                    if not raw_phone.startswith(dial):
                        # Strip any leading national trunk zero then prepend
                        raw_phone = dial + raw_phone.lstrip("0")
            except Exception:
                pass  # fall through with raw number if lookup fails
        # else: 5sim already provides the full number — use as-is
        clean_phone = "+" + raw_phone

        url = "https://discord.com/api/v9/users/@me/phone"
        # Do NOT include change_phone_reason when adding a phone for the first time —
        # that field is only valid when replacing an existing number
        payload = {"phone": clean_phone}

        # Refresh fingerprint right before the phone request so it is
        # fresh and tied to the current session state.
        await asyncio.to_thread(ctx.get_fingerprint)

        req_headers = ctx.get_headers(
            endpoint_type="api", include_auth=token, include_fingerprint=True
        )
        req_headers["X-Discord-Device-Id"] = str(uuid.uuid4())
        # NOTE: Do NOT add fake X-Discord-App-* headers — real browsers don't send
        # those and they can trigger stricter server-side validation.

        log.info(f"Adding phone: {clean_phone}")

        try:
            r = await asyncio.to_thread(
                ctx.session.post, url, json=payload, headers=req_headers, timeout=30
            )
        except Exception as e:
            log.warning(
                f"Add phone request failed (network error, keeping number): {e}"
            )
            # Network timeout ≠ Discord rejection — do NOT cancel the number,
            # just retry the loop with the same number.
            await asyncio.sleep(3)
            continue

        # ── Multi-round captcha loop (Discord can challenge 2-3 times for hotmail) ──
        MAX_CAPTCHA_ROUNDS = 3
        solver_label = {
            "rezo": "Rezo Solver",
            "hackers": "/hackers",
            "local": "Local Browser",
        }.get(CAPTCHA_SOLVER, "Onyx")
        captcha_failed = False

        for cap_round in range(1, MAX_CAPTCHA_ROUNDS + 1):
            if r.status_code not in (400, 403):
                break  # No more captcha — exit inner loop

            try:
                err = r.json()
            except:
                err = {}

            if "captcha_sitekey" not in err:
                break  # 400/403 but NOT a captcha challenge — handle below

            sitekey = err.get("captcha_sitekey")
            rqdata = err.get("captcha_rqdata", "")
            rqtoken = err.get("captcha_rqtoken", "")
            sess_id = err.get("captcha_session_id", "")

            log.info(
                f"[Captcha] Round {cap_round}/{MAX_CAPTCHA_ROUNDS} — solving with {solver_label}..."
            )
            cap = await asyncio.to_thread(
                _solve_captcha_sync, sitekey, "https://discord.com", rqdata, proxy
            )

            if not cap:
                log.error(
                    f"[Captcha] Round {cap_round} solve failed — cancelling number"
                )
                captcha_failed = True
                break

            log.success(f"[Captcha] Round {cap_round} solved!")

            req_headers["X-Captcha-Key"] = cap
            if rqtoken:
                req_headers["X-Captcha-Rqtoken"] = rqtoken
            if sess_id:
                req_headers["X-Captcha-Session-Id"] = sess_id

            # Discord requires captcha_rqdata in the POST body as well
            # (not just in the captcha headers) for enterprise hCaptcha.
            captcha_payload = dict(payload)
            if rqdata:
                captcha_payload["captcha_rqdata"] = rqdata
            if rqtoken:
                captcha_payload["captcha_rqtoken"] = rqtoken

            try:
                r = await asyncio.to_thread(
                    ctx.session.post,
                    url,
                    json=captcha_payload,
                    headers=req_headers,
                    timeout=30,
                )
                log.info(
                    f"[Captcha] Round {cap_round} post-captcha response: {r.status_code}"
                )
            except Exception as e:
                log.warning(
                    f"[Captcha] Round {cap_round} request timed out (keeping number, will retry): {e}"
                )
                # Don't cancel — captcha token is spent but number is fine.
                await asyncio.sleep(3)
                captcha_failed = True
                break

        if captcha_failed:
            await phone_manager.mark_invalid()
            await phone_manager.cancel_current()
            continue

        # ── Check final response after all captcha rounds ─────────────────────
        if r.status_code in (400, 403):
            try:
                err_final = r.json()
            except:
                err_final = {}

            if "captcha_sitekey" in err_final:
                # Still getting captcha after MAX_CAPTCHA_ROUNDS — give up
                log.error(
                    f"[Captcha] Still challenged after {MAX_CAPTCHA_ROUNDS} rounds — skipping number"
                )
                await phone_manager.mark_invalid()
                await phone_manager.cancel_current()
                continue

            err_code = err_final.get("code")
            if r.status_code == 400:
                if err_code == 50022:
                    log.warning(
                        f"Phone {clean_phone} is invalid (code 50022), Discord rejected it."
                    )
                else:
                    log.warning(f"Add phone 400 error (code {err_code}): {err_final}")
                await phone_manager.mark_invalid()
                await phone_manager.cancel_current()
                continue

            if r.status_code == 403:
                log.warning(f"Add phone 403 error: {err_final}")
                await phone_manager.mark_invalid()
                await phone_manager.cancel_current()
                continue

        # ── 429 Rate Limited — bail immediately, don't waste more phone rentals ──
        if r.status_code == 429:
            try:
                rl = r.json()
            except:
                rl = {}
            retry_after = rl.get("retry_after", 0)
            wait_mins = int(retry_after / 60)
            log.error(
                f"Discord rate-limited this account for {retry_after:.0f}s (~{wait_mins}m). Skipping account."
            )
            await phone_manager.cancel_current()
            return False

        if r.status_code not in (200, 204):
            log.warning(f"Failed to add phone ({r.status_code}): {r.text[:200]}")
            await phone_manager.mark_invalid()
            await phone_manager.cancel_current()
            continue

        log.success("Phone added successfully! Awaiting OTP...")

        sms_code = None
        start_sms = time.time()
        while time.time() - start_sms < 120:
            try:
                sms_code = await asyncio.to_thread(sms_client.get_status, activation_id)
                if sms_code:
                    break
            except Exception:
                pass
            await asyncio.sleep(5)

        if not sms_code:
            log.error("OTP timeout")
            await phone_manager.mark_invalid()
            await phone_manager.cancel_current()
            continue

        log.success(f"OTP received: {sms_code}")
        phone_manager.record_used_code(sms_code)

        # ── OTP verify with retry (3 attempts, 5s backoff) ───────────────────
        verify_url = "https://discord.com/api/v9/phone-verifications/verify"
        v_payload = {"code": sms_code, "phone": clean_phone}
        phone_token = None
        otp_ok = False
        for otp_try in range(1, 4):
            try:
                vr = await asyncio.to_thread(
                    ctx.session.post,
                    verify_url,
                    json=v_payload,
                    headers=req_headers,
                    timeout=20,
                )
                if vr.status_code == 200:
                    phone_token = vr.json().get("token")
                    otp_ok = True
                    break
                else:
                    log.warning(
                        f"OTP verify attempt {otp_try}/3 failed ({vr.status_code}): {vr.text[:80]}"
                    )
                    if otp_try < 3:
                        await asyncio.sleep(5)
            except Exception as e:
                log.warning(f"OTP verify attempt {otp_try}/3 error: {e}")
                if otp_try < 3:
                    await asyncio.sleep(5)

        if not otp_ok or not phone_token:
            log.error("OTP verify failed after 3 attempts — cancelling number")
            await phone_manager.mark_invalid()
            await phone_manager.cancel_current()
            continue

        # ── Finalize with retry (3 attempts, 10s backoff, 30s timeout) ────────
        # The finalize is a simple PUT that Discord sometimes drops under load.
        # Retry in-place with the SAME phone_token — do NOT restart the outer
        # loop (which would rent a new number and waste balance).
        fin_url = "https://discord.com/api/v9/users/@me/phone"
        fin_payload = {"phone_token": phone_token, "password": account_password}
        fin_ok = False
        for fin_try in range(1, 4):
            try:
                fr = await asyncio.to_thread(
                    ctx.session.post,
                    fin_url,
                    json=fin_payload,
                    headers=req_headers,
                    timeout=30,
                )
                if fr.status_code in (200, 204):
                    log.success("Phone finalized successfully!")
                    fin_ok = True
                    break
                else:
                    log.warning(
                        f"Finalize attempt {fin_try}/3 failed ({fr.status_code}): {fr.text[:200]}"
                    )
                    if fin_try < 3:
                        await asyncio.sleep(10)
            except Exception as e:
                log.warning(f"Finalize attempt {fin_try}/3 error (will retry): {e}")
                if fin_try < 3:
                    await asyncio.sleep(10)

        if fin_ok:
            # ── Complete the activation on the SMS provider ───────────────
            # Calling complete_activation (finish_order on 5sim) signals that
            # the number was successfully used.  Clearing active_number here
            # prevents the process_task safety-net from attempting a cancel on
            # an already-finished order, which would produce a spurious 400.
            if phone_manager.active_number:
                try:
                    await asyncio.to_thread(
                        phone_manager.active_number.client.complete_activation,
                        phone_manager.active_number.activation_id,
                    )
                    log.info("Activation marked complete on SMS provider.")
                except Exception:
                    pass  # Non-fatal — number was used successfully regardless
                phone_manager.active_number = None  # Prevent cleanup cancel
            return True

        log.error("Finalize failed after 3 attempts — cancelling number")
        await phone_manager.mark_invalid()
        await phone_manager.cancel_current()
        continue

    return False


# ============================================================================
# UNLOCK ACCOUNT - FIXED VERSION
# ============================================================================


async def unlock_account(
    account: LockedAccount,
    worker_id: int,
    phone_manager: PhoneNumberManager,
    proxy: Optional[str] = None,
    tracker: Optional["ProgressTracker"] = None,
    build_number: int = FALLBACK_BUILD,
) -> bool:
    """Core function to unlock a discord account.

    FORMAT: email:password:token
    Premium features:
      - Deep token pre-check (username/phone/verified/flags)
      - Rate-limit pre-flight guard
      - Per-account cooldown timer on rate-limit
      - Dynamic build number in super-properties
    """
    log.info(f"Processing account: {account.email}")

    token = account.token
    # Determine intent label for cleaner log messages
    _intent = "ADD PHONE"  # default — may be overridden after status check
    discord_password = account.discord_password

    # Create session context with live build number
    ctx = SessionContext(proxy=proxy)
    ctx.build_number = build_number
    ctx.super_properties = ctx._encode_super_props()  # re-encode with fresh build
    await asyncio.to_thread(ctx.get_fingerprint)

    # ── STEP 0A: Deep token check ────────────────────────────────────────────
    log.info("Running deep token check...")
    report = await asyncio.to_thread(deep_check_token, token)
    _display_token_report(report)

    if report.status == "INVALID":
        log.error(f"Token is INVALID — skipping {account.email}")
        if tracker:
            tracker.inc_skipped()
            tracker.render()
        return False

    if report.status == "ERROR":
        log.warning(f"Token check returned ERROR — proceeding anyway")

    # Already has phone? nothing to do
    if report.status == "VALID" and report.phone:
        log.success(f"Account already has phone! Marked as unlocked.")
        _save_account_secure(
            account.email, account.discord_password, token, "ALREADY_UNLOCKED", report
        )
        if tracker:
            tracker.inc_skipped()
            tracker.render()
        return True

    # ── STEP 0B: Rate-limit pre-flight ──────────────────────────────────────
    ok, retry_after = await rate_limit_guard(token, ctx)
    if not ok:
        wait_m = int(retry_after / 60)
        log.warning(
            f"Account rate-limited — retry_after={retry_after:.0f}s (~{wait_m}m). Starting cooldown timer..."
        )
        # Live countdown display
        deadline = time.time() + retry_after
        while time.time() < deadline:
            remaining_secs = int(deadline - time.time())
            sys.stderr.write(
                f"\r  \033[38;2;255;200;60m[COOLDOWN]\033[0m "
                f"{account.email} — waiting {remaining_secs}s for rate-limit to clear...   "
            )
            sys.stderr.flush()
            await asyncio.sleep(1)
        sys.stderr.write("\n")
        log.success("Cooldown complete — resuming.")
        # Re-get fingerprint after the wait
        await asyncio.to_thread(ctx.get_fingerprint)

    # STEP 1: Login with token to check account status
    log.info("Logging in with token...")
    success, user_data, status = await login_with_token(token, ctx)

    if not success:
        log.error(f"Failed to login with token: {status}")
        return False

    log.success(f"Token login successful! Account status: {status}")

    # Check if account needs unlock
    needs_unlock = False
    unlock_reason = ""

    if status == "LOCKED":
        needs_unlock = True
        unlock_reason = "Account is locked/disabled"
        _intent = "UNLOCK + ADD PHONE"
        log.warning(f"Account is LOCKED — proceeding with unlock + phone add...")
    elif status == "VALID":
        # Check if account needs phone/email verification
        phone = user_data.get("phone", "")
        verified = user_data.get("verified", False)

        # ── EMAIL VERIFICATION ADVISORY ──────────────────────────────────────
        # Discord PREFERS email to be verified before phone addition.
        # We warn the user but still attempt — Discord will return an error if
        # it genuinely cannot proceed, and we will surface that error clearly.
        if not verified:
            log.warning(
                f"⚠  Account email is NOT verified — Discord may reject phone verification!"
            )
            log.warning(f"   Attempting anyway for: {account.email}")
        # ────────────────────────────────────────────────────────────────────

        if not phone:
            needs_unlock = True
            unlock_reason = "Valid token — no phone attached"
            _intent = "ADD PHONE"
            log.info(f"✅ Token is VALID — adding phone number to account...")
        else:
            log.success(
                f"Account already has phone! (Phone: {phone[:4]}***, Verified: {verified})"
            )
            # Save and skip — nothing to do
            _save_account_secure(
                account.email,
                account.discord_password,
                token,
                "ALREADY_UNLOCKED",
                {"status": "VALID"},
            )
            return True
    else:
        log.error(f"Unexpected account status: {status}")
        return False

    if not needs_unlock:
        log.success(f"Account doesn't need unlock!")
        return True

    log.info(f"Mode: [{_intent}]  Reason: {unlock_reason}")

    # STEP 2: Phone verification (if needed)
    phone_verified = False

    if status == "VALID":
        if user_data.get("phone"):
            log.success("Phone already attached!")
            phone_verified = True
        else:
            log.info("Starting phone verification...")
            phone_verified = await api_phone_verification(
                ctx, phone_manager, token, discord_password, proxy
            )
            if not phone_verified:
                log.error("Phone verification failed.")
                return False
    else:
        # Account is LOCKED - try phone verification anyway
        log.info("Account locked, attempting phone verification...")
        phone_verified = await api_phone_verification(
            ctx, phone_manager, token, discord_password, proxy
        )
        if not phone_verified:
            log.error("Phone verification failed on locked account.")
            return False

    log.success("Phone verification completed!")
    await asyncio.sleep(3)

    # STEP 5: Final validation - check if account is now unlocked
    log.info("Performing final validation...")
    final_success, final_data, final_status = await login_with_token(token, ctx)

    if final_success and final_status == "VALID":
        # Check if phone and email are now set
        final_phone = final_data.get("phone", "")
        final_verified = final_data.get("verified", False)

        if final_phone and final_verified:
            log.success(
                f"✅ Account FULLY DONE! Phone: {final_phone[:4]}***, Verified: {final_verified}"
            )
            _save_account_secure(
                account.email, account.discord_password, token, "UNLOCKED", final_data
            )
            # Also write to phone_added output
            try:
                PHONE_ADDED_FILE.parent.mkdir(exist_ok=True)
                with open(PHONE_ADDED_FILE, "a", encoding="utf-8") as pf:
                    pf.write(f"{account.original_line}\n")
            except Exception:
                pass
            return True
        elif final_phone:
            log.success(f"✅ Phone attached! (email not yet verified — partial)")
            _save_account_secure(
                account.email,
                account.discord_password,
                token,
                "PARTIAL_UNLOCK",
                final_data,
            )
            try:
                PHONE_ADDED_FILE.parent.mkdir(exist_ok=True)
                with open(PHONE_ADDED_FILE, "a", encoding="utf-8") as pf:
                    pf.write(f"{account.original_line}\n")
            except Exception:
                pass
            return True
        else:
            log.warning(f"Account validation passed but phone still missing")
            _save_account_secure(
                account.email, account.discord_password, token, "VALID", final_data
            )
            return False
    elif final_success and final_status == "LOCKED":
        log.error(f"Account still locked after unlock attempts")
        return False
    else:
        log.error(f"Final validation failed: {final_status}")
        return False


# ============================================================================
# FILE LOADING - UPDATED FOR email:password:token FORMAT
# ============================================================================


def _parse_accounts_file(filepath: Path) -> List[LockedAccount]:
    """Parse a file of accounts in email:password:token format."""
    accounts = []
    if not filepath.exists():
        return accounts
    lines = filepath.read_text(encoding="utf-8").splitlines()
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(":", 2)
        if len(parts) >= 3:
            accounts.append(
                LockedAccount(
                    email=parts[0].strip(),
                    discord_password=parts[1].strip(),
                    token=parts[2].strip(),
                    original_line=line,
                )
            )
        else:
            log.warning(f"Skipping invalid line (need 3 fields): {line[:50]}")
    return accounts


def load_locked_accounts() -> List[LockedAccount]:
    """Load accounts from locked_accounts.txt AND valid_accounts.txt.

    Both files use the same format: email:password:token
    Duplicates (by token) are automatically removed.

    Example:
    user@gmail.com:MyDiscordPassword:MyDiscordToken123
    """
    accounts: List[LockedAccount] = []
    seen_tokens: set = set()

    # Primary file — locked tokens
    locked = _parse_accounts_file(LOCKED_ACCOUNTS_FILE)
    if locked:
        log.info(f"Loaded {len(locked)} accounts from {LOCKED_ACCOUNTS_FILE.name}")
    else:
        log.warning(f"{LOCKED_ACCOUNTS_FILE} not found or empty")

    # Secondary file — valid tokens that need a phone
    valid = _parse_accounts_file(VALID_ACCOUNTS_FILE)
    if valid:
        log.info(f"Loaded {len(valid)} accounts from {VALID_ACCOUNTS_FILE.name}")

    for acc in locked + valid:
        tok = acc.token.strip()
        if tok and tok not in seen_tokens:
            seen_tokens.add(tok)
            accounts.append(acc)

    if not accounts:
        log.error("No accounts found in locked_accounts.txt or valid_accounts.txt")

    log.info(f"Total unique accounts to process: {len(accounts)}")
    return accounts


# ============================================================================
# MAIN EXECUTION
# ============================================================================


def _apply_gradient_block_local(
    lines: list, c1=(255, 42, 42), c2=(90, 184, 255)
) -> list:
    total = len(lines)
    out = []
    for i, line in enumerate(lines):
        llen = max(1, len(line) - 1)
        row = []
        for j, ch in enumerate(line):
            t = ((i / max(1, total - 1)) + (j / llen)) / 2
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            row.append(f"\033[38;2;{r};{g};{b}m{ch}")
        row.append("\033[0m")
        out.append("".join(row))
    return out


def show_unlocker_interface():
    # MAX MAYFIELD / Sadie Sink theme:
    # blood-red (Vecna / Max's hair) -> Hawkins ice-blue (Max's jacket / skateboard)
    MAX_RED = (255, 42, 42)
    HAWKINS_BLUE = (90, 184, 255)
    logo = [
        "                                                                  ",
        "  ███╗   ███╗ █████╗ ██╗  ██╗                                     ",
        "  ████╗ ████║██╔══██╗╚██╗██╔╝                                     ",
        "  ██╔████╔██║███████║ ╚███╔╝                                      ",
        "  ██║╚██╔╝██║██╔══██║ ██╔██╗                                      ",
        "  ██║ ╚═╝ ██║██║  ██║██╔╝ ██╗                                     ",
        "  ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝                                     ",
        "  ██╗   ██╗███╗   ██╗██╗      ██████╗  ██████╗██╗  ██╗███████╗██████╗  ",
        "  ██║   ██║████╗  ██║██║     ██╔═══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗ ",
        "  ██║   ██║██╔██╗ ██║██║     ██║   ██║██║     █████╔╝ █████╗  ██████╔╝ ",
        "  ██║   ██║██║╚██╗██║██║     ██║   ██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗ ",
        "  ╚██████╔╝██║ ╚████║███████╗╚██████╔╝╚██████╗██║  ██╗███████╗██║  ██║ ",
        "   ╚═════╝ ╚═╝  ╚═══╝╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝ ",
        "                                                                  ",
    ]
    os.system("cls" if os.name == "nt" else "clear")
    print("\n\n")
    try:
        tw = os.get_terminal_size().columns
    except OSError:
        tw = 100
    max_len = max(len(l) for l in logo)
    centered = [" " * max(0, (tw - max_len) // 2) + l for l in logo]
    for line in _apply_gradient_block_local(centered, MAX_RED, HAWKINS_BLUE):
        print(line)
        time.sleep(0.035)

    tag = "✦  MAX MAYFIELD EDITION v5.0  —  by /hackers  ✦"
    print(
        " " * max(0, (tw - len(tag)) // 2)
        + _gradient_text(tag, MAX_RED, (255, 200, 80))
    )
    tribute = "Sadie Sink tribute  •  Hawkins 1986  •  Running Up That Hill  •  She's Our Fighter"
    print(
        " " * max(0, (tw - len(tribute)) // 2)
        + _gradient_text(tribute, (255, 120, 120), HAWKINS_BLUE)
    )
    sub = "Valid + Locked Tokens  •  Phone Verify  •  Captcha Solve  •  Multi-Thread"
    print(
        " " * max(0, (tw - len(sub)) // 2)
        + _gradient_text(sub, (140, 40, 50), (80, 140, 200))
    )
    print("\n\n")


# ── Settings persistence ──────────────────────────────────────────────────
_SETTINGS_FILE = Path(__file__).parent / "settings_unlocker.json"


def _load_settings() -> dict:
    try:
        if _SETTINGS_FILE.exists():
            return json.loads(_SETTINGS_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _save_settings(cfg: dict) -> None:
    try:
        _SETTINGS_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
        log.success("Settings saved to settings_unlocker.json")
    except Exception as e:
        log.warning(f"Could not save settings: {e}")


async def run_unlocker():
    global \
        PROXY_SESSION, \
        PHONE_COUNTRY_CODE, \
        ONYX_API_KEY, \
        REZO_API_KEY, \
        HACKERS_API_KEY, \
        HACKERS_BASE_URL, \
        MANTHAN_API_KEY, \
        MANTHAN_BASE_URL, \
        LOCAL_SOLVER_URL, \
        CAPTCHA_SOLVER

    Path("output").mkdir(exist_ok=True)
    accounts = load_locked_accounts()
    if not accounts:
        log.error("No accounts to process")
        return

    show_unlocker_interface()

    # ── Fetch live Discord build number upfront ──────────────────────────────
    log.info("Fetching live Discord build number...")
    live_build = await get_live_build_number(fallback=FALLBACK_BUILD)

    def ask_input(prompt_text: str) -> str:
        ts = datetime.now().strftime("%H:%M:%S")
        ts_col = _gradient_text(f"[{ts}]", (140, 80, 110), (180, 120, 140))
        q_lbl = _gradient_text("[?]", (255, 180, 50), (255, 100, 0))
        msg = _gradient_text(prompt_text, (255, 42, 42), (90, 184, 255))
        return input(f" {ts_col} {q_lbl} {msg} ").strip()

    locked_cnt = sum(
        1
        for a in accounts
        if LOCKED_ACCOUNTS_FILE.exists()
        and a.original_line in LOCKED_ACCOUNTS_FILE.read_text(encoding="utf-8")
    )
    valid_cnt = len(accounts) - locked_cnt
    log.info(
        f"Accounts to process: {len(accounts)} total  ({locked_cnt} from locked_accounts.txt  |  {valid_cnt} from valid_accounts.txt)"
    )
    print()

    # ── Load existing config ──────────────────────────────────────────────
    cfg = _load_settings()
    use_saved = False

    if cfg:
        cap_solver_saved = cfg.get("captcha_solver", "onyx")
        if cap_solver_saved == "rezo":
            key_saved = cfg.get("rezo_api_key", "")
            key_label = "Rezo API Key"
        elif cap_solver_saved in ("hackers", "manthan"):
            key_saved = cfg.get(
                "hackers_api_key", cfg.get("manthan_api_key", HACKERS_API_KEY)
            )
            key_label = "/hackers API Key"
        else:
            key_saved = cfg.get("onyx_api_key", "")
            key_label = "Onyx API Key"
        key_mask = (
            (key_saved[:8] + "…" + key_saved[-4:])
            if len(key_saved) > 12
            else key_saved or "—"
        )
        print(
            _gradient_text("  💾  Saved config found!", (255, 42, 42), (90, 184, 255))
        )
        fields = [
            ("SMS Provider", cfg.get("sms_provider", "sms_activate")),
            ("Captcha Solver", cap_solver_saved),
            (key_label, key_mask),
            ("Proxy", (cfg.get("proxy") or "None")[:50]),
            ("Country Code", str(cfg.get("phone_cc", 0))),
            ("Threads", str(cfg.get("threads", 1))),
        ]
        for label, val in fields:
            lbl_c = _gradient_text(
                f"  {label.ljust(16)}", (255, 160, 200), (255, 120, 180)
            )
            val_c = _gradient_text(val, (255, 200, 220), (255, 160, 200))
            print(f"{lbl_c}: {val_c}")
        print()
        choice = ask_input("Load saved config? [Y/n]:").lower()
        use_saved = choice not in ("n", "no")

    # Clear screen and redraw banner after config preview
    show_unlocker_interface()
    log.info(
        f"Total accounts: {len(accounts)}  (locked_accounts.txt + valid_accounts.txt)"
    )
    print()

    if use_saved:
        # ── Apply saved config ────────────────────────────────────────────
        raw_proxy = cfg.get("proxy") or ""
        raw_cc = cfg.get("phone_cc", 0)
        PHONE_COUNTRY_CODE = (
            int(raw_cc) if str(raw_cc).lstrip("-").isdigit() else raw_cc
        )
        max_threads = min(int(cfg.get("threads", 1)), 5)  # hard-cap at 5
        CAPTCHA_SOLVER = cfg.get("captcha_solver", "onyx")
        if CAPTCHA_SOLVER == "rezo":
            saved_key = cfg.get("rezo_api_key", "").strip()
            if saved_key:
                REZO_API_KEY = saved_key
        elif CAPTCHA_SOLVER in ("hackers", "manthan"):
            CAPTCHA_SOLVER = "hackers"  # normalize old "manthan" value
            saved_key = cfg.get(
                "hackers_api_key", cfg.get("manthan_api_key", "")
            ).strip()
            if saved_key:
                HACKERS_API_KEY = saved_key
                globals()["MANTHAN_API_KEY"] = saved_key
            HACKERS_BASE_URL = (
                cfg.get(
                    "hackers_base_url",
                    cfg.get("manthan_base_url", "https://discord.gg/hackers"),
                ).strip()
                or "https://discord.gg/hackers"
            )
            globals()["MANTHAN_BASE_URL"] = HACKERS_BASE_URL
        else:
            saved_key = cfg.get("onyx_api_key", "").strip()
            if saved_key:
                ONYX_API_KEY = saved_key
        if raw_proxy:
            PROXY_SESSION = (
                raw_proxy if raw_proxy.startswith("http") else f"http://{raw_proxy}"
            )
            log.success(f"Proxy loaded: {PROXY_SESSION[:50]}")
        log.success(
            f"Config loaded — starting immediately (threads: {max_threads}, solver: {CAPTCHA_SOLVER})"
        )

    else:
        # ── Manual input ──────────────────────────────────────────────────
        # Pick captcha solver first
        cap_raw = (
            ask_input("Captcha solver (onyx / rezo / hackers / local) [onyx]:")
            .lower()
            .strip()
        )
        CAPTCHA_SOLVER = (
            cap_raw if cap_raw in ("onyx", "rezo", "hackers", "local") else "onyx"
        )

        if CAPTCHA_SOLVER == "rezo":
            rezo_raw = ask_input("Rezo Solver API key (https://huzaif.online):")
            if rezo_raw:
                REZO_API_KEY = rezo_raw
            else:
                log.warning("No Rezo API key entered — captcha solving may fail")
        elif CAPTCHA_SOLVER in ("hackers", "manthan"):
            hackers_key_raw = ask_input(
                f"/hackers API Key [{HACKERS_API_KEY[:12]}…] or Enter to keep:"
            )
            if hackers_key_raw:
                HACKERS_API_KEY = hackers_key_raw
            # URL is always https://discord.gg/hackers — permanent, no prompt needed
            log.info(f"[/hackers] Checking cloud solver at {HACKERS_BASE_URL}...")
            try:
                hr = sync_requests.get(f"{HACKERS_BASE_URL}/health", timeout=8)
                if hr.status_code == 200:
                    h = hr.json()
                    log.success(
                        f"[/hackers] ✅ Online — uptime={h.get('uptime_s', 0):.0f}s  browsers={h.get('browsers_active', 0)}  queue={h.get('queue_depth', 0)}"
                    )
                else:
                    log.warning(
                        f"[/hackers] Health check returned HTTP {hr.status_code}"
                    )
            except Exception as he:
                log.warning(f"[/hackers] Cannot reach {HACKERS_BASE_URL}: {he}")
        elif CAPTCHA_SOLVER == "local":
            url_raw = ask_input(
                f"Local solver URL [{LOCAL_SOLVER_URL}] or Enter to keep:"
            )
            if url_raw:
                LOCAL_SOLVER_URL = url_raw.rstrip("/")
            log.info(f"[LocalSolver] Checking local solver at {LOCAL_SOLVER_URL}...")
            try:
                lr = sync_requests.get(f"{LOCAL_SOLVER_URL}/task/ping", timeout=5)
                if lr.status_code == 200:
                    log.success(f"[LocalSolver] ✅ Online — {LOCAL_SOLVER_URL}")
                else:
                    log.warning(
                        f"[LocalSolver] Ping returned HTTP {lr.status_code} — is Browser_solver/solver.py running?"
                    )
            except Exception as le:
                log.warning(f"[LocalSolver] Cannot reach {LOCAL_SOLVER_URL}: {le}")
                log.warning(
                    "Make sure Browser_solver/solver.py is running before continuing!"
                )
        else:
            onyx_raw = ask_input(f"Onyx API key [{ONYX_API_KEY[:8]}…]:")
            if onyx_raw:
                ONYX_API_KEY = onyx_raw

        proxy_raw = ask_input("Proxy (http://user:pass@ip:port) or Enter to skip:")
        if proxy_raw:
            PROXY_SESSION = (
                proxy_raw if proxy_raw.startswith("http") else f"http://{proxy_raw}"
            )
            log.success(f"Proxy set: {PROXY_SESSION[:50]}")
        else:
            proxy_raw = ""

        sms_provider = ask_input(
            "SMS Provider (sms_activate / 5sim) [sms_activate]:"
        ).lower()
        if not sms_provider or sms_provider not in ("sms_activate", "5sim"):
            sms_provider = "sms_activate"

        fallback_cc_str = ""  # default empty
        if sms_provider == "5sim":
            cc_raw = ask_input(
                "5sim Country (england, russia, germany, etc.) [england]:"
            )
            if not cc_raw:
                cc_raw = "england"
            PHONE_COUNTRY_CODE = cc_raw
        else:
            log.info(
                "⚠  Turkey (90) and India (91) are VIRTUAL-ONLY on sms-activate — Discord rejects them!"
            )
            log.info(
                "   Best choice for Discord: 16=UK ($0.006, 77% success) | 68=Colombia ($0.006) | 89=Vietnam ($0.01)"
            )
            cc_raw = ask_input("Phone country code [16=UK recommended]:")
            if cc_raw.isdigit():
                PHONE_COUNTRY_CODE = int(cc_raw)
                if PHONE_COUNTRY_CODE in VIRTUAL_ONLY_COUNTRIES:
                    log.warning(
                        f"Country {PHONE_COUNTRY_CODE} is virtual-only — Discord will likely reject these numbers!"
                    )
                    log.warning(
                        "Strongly recommend switching to UK (16) or Colombia (68)."
                    )
            else:
                PHONE_COUNTRY_CODE = 16  # Default UK

            fallback_raw = ask_input(
                "Fallback country codes if primary has no stock (comma-sep, e.g. 68,89) or Enter to skip:"
            )
            fallback_cc_str = fallback_raw.strip()

        while True:
            threads_raw = ask_input("Number of concurrent threads (1-5):")
            if threads_raw.isdigit() and 1 <= int(threads_raw) <= 5:
                max_threads = int(threads_raw)
                break
            log.warning(
                "Enter a valid number between 1 and 5 (max 5 to avoid rate-limits)"
            )

        # Save config
        _save_settings(
            {
                "captcha_solver": CAPTCHA_SOLVER,
                "onyx_api_key": ONYX_API_KEY,
                "rezo_api_key": REZO_API_KEY,
                "hackers_api_key": HACKERS_API_KEY,
                "hackers_base_url": HACKERS_BASE_URL,  # always https://discord.gg/hackers
                "proxy": proxy_raw,
                "phone_cc": PHONE_COUNTRY_CODE,
                "threads": max_threads,
                "sms_provider": sms_provider,
                "fallback_countries": fallback_cc_str,
            }
        )

    SMS_PROVIDER = (
        cfg.get("sms_provider", "sms_activate") if use_saved else sms_provider
    )
    FALLBACK_CC_LIST: List[str] = [
        s.strip()
        for s in (
            cfg.get("fallback_countries", "") if use_saved else fallback_cc_str
        ).split(",")
        if s.strip()
    ]

    # ── Proxy dead-check ─────────────────────────────────────────────────────
    if PROXY_SESSION:
        log.info(f"Checking proxy liveness: {PROXY_SESSION[:50]}...")
        alive, latency = await ProxyChecker.check_async(PROXY_SESSION)
        if alive:
            log.success(f"Proxy is alive ✅  latency: {latency:.0f}ms")
        else:
            log.error("Proxy is DEAD ❌  — proceeding proxyless (requests may fail)")
            PROXY_SESSION = None

    print()
    log.info(f"Starting unlock for {len(accounts)} accounts with {max_threads} threads")
    solver_label = CAPTCHA_SOLVER.upper()
    if CAPTCHA_SOLVER == "rezo":
        solver_label = "REZO (huzaif.online)"
    elif CAPTCHA_SOLVER in ("hackers", "manthan"):
        solver_label = f"/hackers (cloud @ {HACKERS_BASE_URL})"
    elif CAPTCHA_SOLVER == "local":
        solver_label = f"LOCAL (Browser_solver @ {LOCAL_SOLVER_URL})"
    log.info(f"Discord build: {live_build}  |  Solver: {solver_label}")
    print()

    # ── Progress tracker ─────────────────────────────────────────────────────
    tracker = ProgressTracker(total=len(accounts))
    tracker.render()

    unlocked_count = 0
    failed_count = 0
    active_count = 0
    semaphore = asyncio.Semaphore(max_threads)
    file_lock = asyncio.Lock()
    import threading

    _counter_lock = threading.Lock()
    _active_lock = threading.Lock()

    async def process_task(idx: int, account: LockedAccount):
        nonlocal unlocked_count, failed_count, active_count
        async with semaphore:
            with _active_lock:
                active_count += 1
                tracker.set_active(active_count)
                tracker.render()

            log.account_header(idx, len(accounts), account.email)

            phone_manager = PhoneNumberManager(
                provider=SMS_PROVIDER,
                country_code=str(PHONE_COUNTRY_CODE),
                reuse=False,
                fallback_countries=FALLBACK_CC_LIST,
            )
            await asyncio.sleep(random.uniform(0.5, 3.0))

            success = False
            try:
                success = await unlock_account(
                    account=account,
                    worker_id=idx,
                    phone_manager=phone_manager,
                    proxy=PROXY_SESSION,
                    tracker=tracker,
                    build_number=live_build,
                )
            except Exception as exc:
                log.error(f"[{account.email}] UNEXPECTED ERROR in worker: {exc}")
                success = False
            finally:
                with _active_lock:
                    active_count -= 1
                    tracker.set_active(active_count)
                # Cleanup leftover phone rental (safety net)
                if phone_manager.active_number:
                    try:
                        await phone_manager.cancel_current()
                    except Exception:
                        pass

            # ── Always remove from locked_accounts.txt once processed ────────
            # Runs regardless of success/fail/email-not-verified/crash.
            # Prevents the same account from being retried on next run.
            async with file_lock:
                try:
                    lines = LOCKED_ACCOUNTS_FILE.read_text(
                        encoding="utf-8"
                    ).splitlines()
                    lines = [
                        l for l in lines if l.strip() != account.original_line.strip()
                    ]
                    LOCKED_ACCOUNTS_FILE.write_text(
                        "\n".join(lines) + ("\n" if lines else ""), encoding="utf-8"
                    )
                except Exception as e:
                    log.warning(
                        f"[{account.email}] Could not remove from locked_accounts.txt: {e}"
                    )

            if success:
                with _counter_lock:
                    unlocked_count += 1
                tracker.inc_unlocked()
                tracker.render()
                log.success(f"✅ [{account.email}] Unlocked successfully")
                async with file_lock:
                    with open(UNLOCKED_OUTPUT_FILE, "a", encoding="utf-8") as f:
                        f.write(f"{account.original_line}\n")
            else:
                with _counter_lock:
                    failed_count += 1
                tracker.inc_failed()
                tracker.render()
                log.error(f"❌ [{account.email}] Failed to unlock")
                async with file_lock:
                    with open(FAILED_OUTPUT_FILE, "a", encoding="utf-8") as f:
                        f.write(f"{account.original_line}\n")

    tasks = [
        asyncio.create_task(process_task(idx, account))
        for idx, account in enumerate(accounts, 1)
    ]
    if tasks:
        await asyncio.gather(*tasks)

    tracker.finish()
    print()
    log.divider()
    log.success(
        f"ALL DONE  —  ✅ {unlocked_count} processed  |  ❌ {failed_count} failed  |  ⏭  {tracker.skipped} skipped"
    )
    log.info(f"Phone-added accounts : {PHONE_ADDED_FILE}")
    log.info(f"All successful output: {UNLOCKED_OUTPUT_FILE}")
    log.info(f"Failed output        : {FAILED_OUTPUT_FILE}")
    log.divider()
    print()


def print_about():
    """Prints a stylized 'About' screen for the tool — Max Mayfield Edition."""
    try:
        tw = os.get_terminal_size().columns
    except OSError:
        tw = 80

    print("\n")
    header = " 🛹 ABOUT — MAX MAYFIELD EDITION "
    print(
        " " * ((tw - len(header)) // 2)
        + _gradient_text(header, (255, 42, 42), (90, 184, 255))
    )
    print(
        " " * ((tw - 50) // 2) + _gradient_text("─" * 50, (140, 40, 50), (60, 120, 180))
    )

    info = [
        ("Developer", "/hackers"),
        ("Theme", "Sadie Sink as Max Mayfield"),
        ("Version", "5.0-MAX"),
        ("Type", "Request-based (Headless)"),
        ("Bypass", "curl_cffi / tls_client"),
        ("Solvers", "Onyx, RazorCap, /hackers"),
        ("SMS", "HeroSMS, 5Sim"),
        ("Anthem", "Running Up That Hill"),
    ]

    for label, value in info:
        lbl = _gradient_text(f"  {label.ljust(15)}", (255, 120, 120), (255, 200, 120))
        val = _gradient_text(f": {value}", (160, 200, 255), (120, 160, 220))
        print(" " * ((tw - 30) // 2) + lbl + val)

    print(
        "\n"
        + " " * ((tw - 60) // 2)
        + _gradient_text(
            "She's our fighter — Hawkins 1986 never looked so clean.",
            (180, 120, 140),
            (120, 180, 220),
        )
    )
    print("\n")


def main():
    if "--about" in sys.argv:
        print_about()
        return

    try:
        asyncio.run(run_unlocker())
    except KeyboardInterrupt:
        print(
            "\n"
            + _gradient_text(
                "  ✋ Interrupted — exiting.", (255, 200, 60), (255, 120, 0)
            )
        )


if __name__ == "__main__":
    main()
