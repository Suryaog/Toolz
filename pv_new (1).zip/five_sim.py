"""5sim.net API client for phone verification."""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Optional, List, Dict, Any

import requests


class FiveSimClient:
    """Client for 5sim.net API."""
    
    BASE_URL = "https://5sim.net/v1"
    
    # Service codes
    SERVICE_DISCORD = "discord"
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the client.
        
        Args:
            api_key: 5sim API key. If not specified, taken from keys/five_sim.txt
        """
        self.api_key = api_key or self._load_api_key()
        if not self.api_key or self.api_key == "YOUR_5SIM_API_KEY_HERE":
            raise ValueError(
                "5sim API key is missing or still set to placeholder! Please put your real key in keys/five_sim.txt"
            )
        
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json",
        }
    
    def _load_api_key(self) -> Optional[str]:
        """Loads API key from keys/five_sim.txt"""
        try:
            key_path = Path(__file__).parent / "keys" / "five_sim.txt"
            if key_path.exists():
                text = key_path.read_text(encoding='utf-8').strip()
                if text:
                    return text
        except Exception:
            pass
            
        return None
    
    def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Performs a request to the API."""
        url = f"{self.BASE_URL}/{endpoint.lstrip('/')}"
        
        try:
            response = requests.request(method, url, headers=self.headers, timeout=30, **kwargs)
            response.raise_for_status()

            text = response.text.strip()

            # Empty body — 5sim sometimes returns nothing on stock exhaustion
            if not text:
                raise Exception(f"5sim returned empty response body (HTTP {response.status_code}) for {endpoint}")

            # Plain-text error (e.g. "no free phones", "not enough user balance")
            if not text.startswith('{') and not text.startswith('['):
                raise Exception(f"5sim returned non-JSON error: {text[:120]}")

            return response.json()

        except requests.RequestException as e:
            # Handle 5sim JSON error responses
            try:
                if e.response is not None and e.response.text.strip().startswith('{'):
                    error_data = e.response.json()
                    error_msg = error_data.get("error", str(e))
                    raise Exception(f"5sim API Error: {error_msg}")
            except (ValueError, AttributeError):
                pass
            raise Exception(f"Request error to 5sim: {e}")
    
    def get_balance(self) -> float:
        """Gets account balance."""
        result = self._request("GET", "user/profile")
        return float(result.get("balance", 0))
    
    def get_number(
        self,
        service: str = SERVICE_DISCORD,
        country: str = "any",
        operator: str = "any",
        target_price: float = 0.01
    ) -> tuple[str, str]:
        """
        Gets a phone number for activation.

        When operator='any', fetches the price list and tries operators in
        ascending price order, falling back to the next cheapest if the
        purchase fails (e.g. stock exhausted between price-check and buy).

        Args:
            service: Service code (default discord)
            country: Country name (default any)
            operator: Operator name (default any) — pass a specific name to skip price lookup
            target_price: Unused; kept for API compatibility

        Returns:
            Tuple (activation_id, phone_number)
        """
        country = country.lower()

        # Build a ranked operator list when caller passes 'any'
        operators_to_try: List[str] = []
        if operator != "any":
            operators_to_try = [operator]
        else:
            try:
                prices = self._request(
                    "GET", "guest/prices",
                    params={"country": country, "product": service}
                )
                country_data = prices.get(country, {})
                product_data = country_data.get(service, {})

                # Sort all operators with stock by price (cheapest first)
                ranked = [
                    (op_name, op_info.get("cost", float('inf')))
                    for op_name, op_info in product_data.items()
                    if op_info.get("count", 0) > 0
                ]
                ranked.sort(key=lambda x: x[1])

                if not ranked:
                    raise Exception(f"No operators with stock for '{service}' in '{country}'")

                operators_to_try = [op for op, _ in ranked]
                print(
                    f" [5sim] {len(operators_to_try)} operators available — "
                    f"cheapest: '{ranked[0][0]}' at ${ranked[0][1]:.4f}",
                    flush=True
                )
            except Exception as e:
                if "No operators" in str(e):
                    raise
                raise Exception(f"[5sim] Failed to fetch price list: {e}")

        last_error = "Unknown error"
        for op in operators_to_try:
            endpoint = f"user/buy/activation/{country}/{op}/{service}"
            try:
                result = self._request("GET", endpoint)
                activation_id = str(result.get("id", ""))
                phone_raw = result.get("phone", "")
                if not activation_id or not phone_raw:
                    last_error = f"Incomplete response from operator '{op}': {result}"
                    print(f" [5sim] Skipping operator '{op}': {last_error}", flush=True)
                    continue
                phone_number = phone_raw.lstrip("+")
                print(f" [5sim] Purchased via operator '{op}': +{phone_number}", flush=True)
                return activation_id, phone_number
            except Exception as e:
                last_error = str(e)
                print(f" [5sim] Operator '{op}' failed: {last_error} — trying next...", flush=True)
                continue

        raise Exception(f"[5sim] All {len(operators_to_try)} operator(s) exhausted. Last error: {last_error}")
    
    def get_status(self, activation_id: str) -> Optional[str]:
        """
        Gets activation status and SMS code.
        
        Args:
            activation_id: Activation ID
        
        Returns:
            SMS code or None if not received yet
        """
        result = self._request("GET", f"user/check/{activation_id}")
        
        status = result.get("status")
        sms_list = result.get("sms", [])
        
        if sms_list and len(sms_list) > 0:
            # Sort by date and take the last one or just take the first code found
            # The API doc shows "code" field in the sms object
            for sms in sms_list:
                if sms.get("code"):
                    return sms.get("code")
            
            # If no explicit code field, try to extract from text (fallback)
            text = sms_list[0].get("text", "")
            import re
            match = re.search(r'\b(\d{6})\b', text)
            if match:
                return match.group(1)
                
        return None
    
    def finish_order(self, activation_id: str) -> bool:
        """Finishes the order."""
        result = self._request("GET", f"user/finish/{activation_id}")
        return result.get("status") == "FINISHED"
    
    def cancel_order(self, activation_id: str) -> bool:
        """Cancels the order."""
        result = self._request("GET", f"user/cancel/{activation_id}")
        return result.get("status") == "CANCELED"
    
    # Aliases to match SMSActivateClient interface where possible
    def set_status(self, activation_id: str, status: int) -> bool:
        # 5sim doesn't use numeric statuses like 1, 3, 6, 8
        if status == 6: # Complete
            return self.finish_order(activation_id)
        elif status == 8: # Cancel
            return self.cancel_order(activation_id)
        return False

    def request_another_code(self, activation_id: str) -> bool:
        # 5sim doesn't really have a "request another" status in the same way,
        # usually you just wait for more SMS in the check response.
        # But for interface compatibility:
        return True

    def complete_activation(self, activation_id: str) -> bool:
        return self.finish_order(activation_id)
    
    def cancel_activation(self, activation_id: str) -> bool:
        return self.cancel_order(activation_id)
