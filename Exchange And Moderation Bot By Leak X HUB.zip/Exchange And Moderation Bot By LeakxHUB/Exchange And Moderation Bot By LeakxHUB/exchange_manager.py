"""
Exchange Manager
================
Core orchestration engine for automated LTC ↔ SOL swaps.
Handles deposit address generation, blockchain monitoring, auto-payout dispatch,
anti-double-spend locking, and liquidity management.
"""

from __future__ import annotations

import asyncio
import json
import logging
import secrets
import time
from decimal import Decimal
from typing import Any, Optional

import database
from blockchain import SolanaClient, LitecoinClient
from crypto_utils import (
    SolanaKeypair,
    LitecoinWallet,
    validate_crypto_address,
)
from price_oracle import (
    calculate_swap_quote,
    format_crypto,
    format_usd,
    get_live_prices,
    SwapQuote,
)

log = logging.getLogger("exchange.manager")


def get_explorer_url(coin: str, tx_hash: str) -> str:
    """Return public block explorer link for transaction."""
    c = coin.upper()
    if c == "SOL":
        return f"https://solscan.io/tx/{tx_hash}"
    elif c == "LTC":
        return f"https://litecoinspace.org/tx/{tx_hash}"
    return tx_hash


def get_qr_code_url(address: str) -> str:
    """Generate a clean QR code URL for any crypto address."""
    return f"https://api.qrserver.com/v1/create-qr-code/?size=250x250&data={address}"


class ExchangeManager:
    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.solana_client = SolanaClient(config.get("solana_rpc_urls"))
        self.litecoin_client = LitecoinClient(config.get("litecoin_rpc_url"))

        # Initialize or load hot wallets
        self.solana_hotwallet: Optional[SolanaKeypair] = None
        self.litecoin_hotwallet: Optional[LitecoinWallet] = None
        self._init_hot_wallets()

        # Monitoring state
        self._monitor_task: Optional[asyncio.Task] = None
        self._running = False
        self._payout_locks: set[str] = set()

    def _init_hot_wallets(self) -> None:
        """Load hot wallet keys from config or generate and log notice."""
        # Solana Hot Wallet
        sol_key = self.config.get("solana_hotwallet_private_key")
        if sol_key:
            try:
                self.solana_hotwallet = SolanaKeypair.from_base58_private_key(sol_key)
                log.info("Solana Hot Wallet loaded: %s", self.solana_hotwallet.address)
            except Exception as exc:
                log.error("Failed to load Solana hot wallet from config: %s", exc)
        else:
            # Generate fallback hot wallet for immediate operation
            self.solana_hotwallet = SolanaKeypair.generate()
            log.warning(
                "No 'solana_hotwallet_private_key' found in config.json. "
                "Generated temporary hot wallet: %s (Key: %s)",
                self.solana_hotwallet.address,
                self.solana_hotwallet.to_base58_private_key(),
            )

        # Litecoin Hot Wallet
        ltc_key = self.config.get("litecoin_hotwallet_private_key")
        if ltc_key:
            try:
                self.litecoin_hotwallet = LitecoinWallet.from_wif(ltc_key)
                log.info("Litecoin Hot Wallet loaded: %s", self.litecoin_hotwallet.address)
            except Exception as exc:
                log.error("Failed to load Litecoin hot wallet from config: %s", exc)
        else:
            # Generate fallback hot wallet for immediate operation
            self.litecoin_hotwallet = LitecoinWallet.generate()
            log.warning(
                "No 'litecoin_hotwallet_private_key' found in config.json. "
                "Generated temporary hot wallet: %s (WIF: %s)",
                self.litecoin_hotwallet.address,
                self.litecoin_hotwallet.to_wif(),
            )

    async def get_hotwallet_balances(self) -> dict[str, Decimal]:
        """Fetch live balances for both hot wallets."""
        sol_bal = Decimal("0.0")
        ltc_bal = Decimal("0.0")
        if self.solana_hotwallet:
            sol_bal = await self.solana_client.get_balance(self.solana_hotwallet.address)
        if self.litecoin_hotwallet:
            ltc_bal = await self.litecoin_client.get_balance(self.litecoin_hotwallet.address)
        return {"SOL": sol_bal, "LTC": ltc_bal}

    async def create_swap(
        self,
        *,
        user_id: int,
        guild_id: int,
        channel_id: Optional[int],
        from_coin: str,
        to_coin: str,
        amount_in: Decimal,
        payout_address: str,
    ) -> dict[str, Any]:
        """
        Create a new automated swap order with a dedicated unique deposit address.
        """
        fc = from_coin.upper().strip()
        tc = to_coin.upper().strip()
        payout_addr = payout_address.strip()

        # 1. Validate destination payout address
        if not validate_crypto_address(tc, payout_addr):
            raise ValueError(f"Invalid {tc} destination address format.")

        # 2. Get current fee and minimum settings from database / config
        fee_percent = Decimal(str(await database.get_setting("fee_percent", self.config.get("fee_percent", 1.0))))
        min_usd = Decimal(str(await database.get_setting("min_exchange_usd", self.config.get("min_exchange_usd", 0.01))))

        # 3. Calculate swap quote
        quote: SwapQuote = await calculate_swap_quote(
            from_coin=fc,
            to_coin=tc,
            amount_in=amount_in,
            fee_percent=fee_percent,
            min_amount_usd=min_usd,
        )

        # 4. Generate unique ephemeral deposit address dedicated to this swap
        # Guarantees 0-collision deposit tracking across thousands of users
        deposit_priv = None
        if fc == "SOL":
            ephemeral_sol = SolanaKeypair.generate()
            deposit_address = ephemeral_sol.address
            deposit_priv = ephemeral_sol.to_base58_private_key()
        else:  # fc == "LTC"
            ephemeral_ltc = LitecoinWallet.generate()
            deposit_address = ephemeral_ltc.address
            deposit_priv = ephemeral_ltc.to_wif()

        # 5. Generate human-friendly unique Swap ID
        random_hex = secrets.token_hex(3).upper()
        swap_id = f"SWAP-{random_hex}"

        # 6. Save in SQLite database with ACID transaction
        swap_record = await database.create_swap(
            {
                "swap_id": swap_id,
                "user_id": user_id,
                "guild_id": guild_id,
                "channel_id": channel_id,
                "from_coin": fc,
                "to_coin": tc,
                "expected_deposit_amount": float(quote.from_amount),
                "expected_payout_amount": float(quote.to_amount),
                "usd_value": float(quote.usd_value),
                "exchange_rate": float(quote.exchange_rate),
                "fee_percent": float(quote.fee_percent),
                "fee_amount_usd": float(quote.fee_usd),
                "network_fee_crypto": float(quote.network_fee),
                "deposit_address": deposit_address,
                "deposit_private_key": deposit_priv,
                "user_payout_address": payout_addr,
                "status": "PENDING_DEPOSIT",
                "timeout_seconds": 1800,  # 30 min
            }
        )

        log.info(
            "Created %s: %s %s -> %s %s for user %s",
            swap_id,
            quote.from_amount,
            fc,
            quote.to_amount,
            tc,
            user_id,
        )
        return swap_record

    # -----------------------------------------------------------------------
    # Background Blockchain Monitoring Loop
    # -----------------------------------------------------------------------

    def start_monitoring(self, bot_instance: Any) -> None:
        """Start the background monitor task."""
        if not self._running:
            self._running = True
            self._monitor_task = asyncio.create_task(self._monitor_loop(bot_instance))
            log.info("Background blockchain swap monitor started.")

    def stop_monitoring(self) -> None:
        self._running = False
        if self._monitor_task:
            self._monitor_task.cancel()

    async def _monitor_loop(self, bot: Any) -> None:
        while self._running:
            try:
                active_swaps = await database.get_active_swaps()
                for swap in active_swaps:
                    await self._process_swap(swap, bot)
            except asyncio.CancelledError:
                break
            except Exception as exc:
                log.exception("Error in swap monitoring loop: %s", exc)

            await asyncio.sleep(10)  # Check every 10 seconds

    async def _process_swap(self, swap: dict[str, Any], bot: Any) -> None:
        swap_id = swap["swap_id"]
        status = swap["status"]
        from_coin = swap["from_coin"]
        to_coin = swap["to_coin"]
        deposit_addr = swap["deposit_address"]
        expected_deposit = Decimal(str(swap["expected_deposit_amount"]))
        expected_payout = Decimal(str(swap["expected_payout_amount"]))
        payout_addr = swap["user_payout_address"]
        expires_at = swap["expires_at"]

        now = int(time.time())

        # Check expiration
        if status == "PENDING_DEPOSIT" and now > expires_at:
            log.info("Swap %s expired without deposit.", swap_id)
            await database.update_swap(swap_id, status="EXPIRED")
            await self._notify_status_update(swap, "EXPIRED", bot)
            return

        # 1. Check deposit on blockchain
        if status in ("PENDING_DEPOSIT", "DEPOSIT_DETECTED"):
            is_confirmed = False
            tx_hash = None
            amount_recv = Decimal("0.0")
            confs = 0

            if from_coin == "SOL":
                is_confirmed, tx_hash, amount_recv, confs = await self.solana_client.check_deposit(
                    deposit_addr, expected_deposit
                )
            else:  # LTC
                req_confs = int(swap.get("required_confirmations", 1))
                is_confirmed, tx_hash, amount_recv, confs = await self.litecoin_client.check_deposit(
                    deposit_addr, expected_deposit, required_confirmations=req_confs
                )

            if amount_recv > Decimal("0.0"):
                if status == "PENDING_DEPOSIT":
                    log.info("Deposit detected for %s: %s %s (tx: %s)", swap_id, amount_recv, from_coin, tx_hash)
                    await database.update_swap(
                        swap_id,
                        status="DEPOSIT_DETECTED",
                        deposit_tx_hash=tx_hash,
                        deposit_amount_received=float(amount_recv),
                        confirmations=confs,
                    )
                    await self._notify_status_update(swap, "DEPOSIT_DETECTED", bot)

                if is_confirmed:
                    # Proceed to automated payout
                    await self._execute_payout(swap, bot)

        elif status == "PROCESSING_PAYOUT":
            # Attempt payout execution if not already locked
            await self._execute_payout(swap, bot)

    async def _execute_payout(self, swap: dict[str, Any], bot: Any) -> None:
        swap_id = swap["swap_id"]
        to_coin = swap["to_coin"]
        expected_payout = Decimal(str(swap["expected_payout_amount"]))
        payout_addr = swap["user_payout_address"]

        # Concurrency safety lock per swap to strictly prevent double-payouts
        if swap_id in self._payout_locks:
            return
        self._payout_locks.add(swap_id)

        try:
            # Set state to PROCESSING_PAYOUT atomically
            await database.update_swap(swap_id, status="PROCESSING_PAYOUT")
            await self._notify_status_update(swap, "PROCESSING_PAYOUT", bot)

            success = False
            payout_tx = None
            err_msg = None

            if to_coin == "SOL":
                if not self.solana_hotwallet:
                    err_msg = "Solana hot wallet not configured"
                else:
                    success, payout_tx, err_msg = await self.solana_client.send_payout(
                        self.solana_hotwallet,
                        payout_addr,
                        expected_payout,
                    )
            else:  # to_coin == "LTC"
                if not self.litecoin_hotwallet:
                    err_msg = "Litecoin hot wallet not configured"
                else:
                    success, payout_tx, err_msg = await self.litecoin_client.send_payout(
                        self.litecoin_hotwallet,
                        payout_addr,
                        expected_payout,
                    )

            if success and payout_tx:
                log.info("Swap %s successfully paid out! Tx: %s", swap_id, payout_tx)
                await database.update_swap(
                    swap_id,
                    status="COMPLETED",
                    payout_tx_hash=payout_tx,
                )
                await self._notify_status_update(swap, "COMPLETED", bot, payout_tx=payout_tx)
            else:
                log.error("Swap %s payout failed: %s", swap_id, err_msg)
                # Keep status as PROCESSING_PAYOUT or mark needs attention
                await database.update_swap(
                    swap_id,
                    notes=f"Payout error: {err_msg}",
                )
        finally:
            self._payout_locks.discard(swap_id)

    async def _notify_status_update(
        self,
        swap: dict[str, Any],
        new_status: str,
        bot: Any,
        payout_tx: Optional[str] = None,
    ) -> None:
        """Send live Discord notification to channel/ticket when status changes."""
        channel_id = swap.get("channel_id")
        user_id = swap["user_id"]
        swap_id = swap["swap_id"]
        if not channel_id or not bot:
            return

        try:
            channel = bot.get_channel(channel_id) or await bot.fetch_channel(channel_id)
            if not channel:
                return

            if new_status == "DEPOSIT_DETECTED":
                msg = (
                    f"## ⚡ Deposit Detected!\n\n"
                    f"**Swap ID:** `{swap_id}`\n"
                    f"Received `{swap['from_coin']}` on blockchain. Verifying confirmations..."
                )
            elif new_status == "PROCESSING_PAYOUT":
                msg = (
                    f"## 🔄 Deposit Confirmed — Dispatching Payout\n\n"
                    f"**Swap ID:** `{swap_id}`\n"
                    f"Sending `{format_crypto(swap['to_coin'], swap['expected_payout_amount'])} {swap['to_coin']}` "
                    f"to `{swap['user_payout_address']}`..."
                )
            elif new_status == "COMPLETED":
                explorer = get_explorer_url(swap["to_coin"], payout_tx or "")
                msg = (
                    f"## ✅ Swap Completed Automatically!\n\n"
                    f"**Swap ID:** `{swap_id}`\n"
                    f"**Sent:** `{format_crypto(swap['to_coin'], swap['expected_payout_amount'])} {swap['to_coin']}`\n"
                    f"**To Address:** `{swap['user_payout_address']}`\n\n"
                    f"🔗 **[View Transaction on Blockchain]({explorer})**"
                )
            elif new_status == "EXPIRED":
                msg = f"## ⏱️ Swap Expired\n\n**Swap ID:** `{swap_id}` was closed due to deposit timeout."
            else:
                return

            await channel.send(
                content=f"<@{user_id}>" if new_status in ("COMPLETED", "DEPOSIT_DETECTED") else None,
                embed=None,
            )
        except Exception as exc:
            log.debug("Could not send Discord status notification for swap %s: %s", swap_id, exc)
