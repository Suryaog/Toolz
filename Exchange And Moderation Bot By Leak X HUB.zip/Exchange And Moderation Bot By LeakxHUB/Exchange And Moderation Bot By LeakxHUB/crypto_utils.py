"""
Crypto Utilities for LTC and SOL
=================================
Pure-Python implementations with zero mandatory external C-dependencies.
Includes Base58, Bech32/Bech32m, Ed25519, and address format validators.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import re
import secrets
import struct
from typing import Optional, Tuple


# ---------------------------------------------------------------------------
# Base58 (Bitcoin / Solana standard)
# ---------------------------------------------------------------------------

ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
_BASE58_MAP = {c: i for i, c in enumerate(ALPHABET)}


def b58encode(b: bytes) -> str:
    """Encode bytes to a base58 string."""
    n = int.from_bytes(b, "big")
    chars = []
    while n > 0:
        n, rem = divmod(n, 58)
        chars.append(ALPHABET[rem])
    chars = "".join(reversed(chars))

    # Pad leading zero bytes
    pad = 0
    for byte in b:
        if byte == 0:
            pad += 1
        else:
            break
    return (ALPHABET[0] * pad) + chars


def b58decode(s: str) -> bytes:
    """Decode a base58 string into bytes."""
    s = s.strip()
    n = 0
    for char in s:
        if char not in _BASE58_MAP:
            raise ValueError(f"Invalid character {char!r} in base58 string")
        n = n * 58 + _BASE58_MAP[char]

    # Convert int to bytes
    raw = n.to_bytes((n.bit_length() + 7) // 8, "big") if n > 0 else b""

    # Count leading ones
    pad = 0
    for char in s:
        if char == ALPHABET[0]:
            pad += 1
        else:
            break
    return (b"\x00" * pad) + raw


def b58encode_check(payload: bytes) -> str:
    """Base58Check encode (used for Litecoin Legacy and WIF)."""
    checksum = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
    return b58encode(payload + checksum)


def b58decode_check(s: str) -> bytes:
    """Base58Check decode with checksum verification."""
    decoded = b58decode(s)
    if len(decoded) < 4:
        raise ValueError("Invalid Base58Check string: too short")
    payload, checksum = decoded[:-4], decoded[-4:]
    expected = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
    if checksum != expected:
        raise ValueError("Base58Check checksum mismatch")
    return payload


# ---------------------------------------------------------------------------
# Bech32 / Bech32m (Litecoin SegWit standard - ltc1...)
# ---------------------------------------------------------------------------

CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
CHARSET_MAP = {c: i for i, c in enumerate(CHARSET)}


def bech32_polymod(values: list[int]) -> int:
    GEN = [0x3B6A57B2, 0x26508E6D, 0x1EA119FA, 0x3D4233DD, 0x2A1462B3]
    chk = 1
    for v in values:
        b = chk >> 25
        chk = ((chk & 0x1FFFFFF) << 5) ^ v
        for i in range(5):
            chk ^= GEN[i] if ((b >> i) & 1) else 0
    return chk


def bech32_hrp_expand(hrp: str) -> list[int]:
    return [ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp]


def bech32_verify_checksum(hrp: str, data: list[int]) -> bool:
    const = bech32_polymod(bech32_hrp_expand(hrp) + data)
    return const == 1 or const == 0x2BC830A3  # bech32 or bech32m


def bech32_create_checksum(hrp: str, data: list[int], spec: int = 1) -> list[int]:
    values = bech32_hrp_expand(hrp) + data
    polymod = bech32_polymod(values + [0, 0, 0, 0, 0, 0]) ^ spec
    return [(polymod >> 5 * (5 - i)) & 31 for i in range(6)]


def bech32_encode(hrp: str, data: list[int], spec: int = 1) -> str:
    combined = data + bech32_create_checksum(hrp, data, spec)
    return hrp + "1" + "".join([CHARSET[d] for d in combined])


def convertbits(data: bytes, frombits: int, tobits: int, pad: bool = True) -> Optional[list[int]]:
    acc = 0
    bits = 0
    ret = []
    maxv = (1 << tobits) - 1
    max_acc = (1 << (frombits + tobits - 1)) - 1
    for value in data:
        if value < 0 or (value >> frombits):
            return None
        acc = ((acc << frombits) | value) & max_acc
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            ret.append((acc >> bits) & maxv)
    if pad:
        if bits:
            ret.append((acc << (tobits - bits)) & maxv)
    elif bits >= frombits or ((acc << (tobits - bits)) & maxv):
        return None
    return ret


def encode_segwit_address(hrp: str, witver: int, witprog: bytes) -> str:
    """Encode a SegWit address (e.g. ltc1q...)."""
    conv = convertbits(witprog, 8, 5)
    if conv is None:
        raise ValueError("Failed to convert bits for segwit address")
    spec = 1 if witver == 0 else 0x2BC830A3
    return bech32_encode(hrp, [witver] + conv, spec)


# ---------------------------------------------------------------------------
# Pure-Python Ed25519 (Solana Keypairs & Signatures)
# ---------------------------------------------------------------------------

_b = 256
_q = 2**255 - 19
_l = 2**252 + 27742317777372353535851937790883648493


def _inv(x: int) -> int:
    return pow(x, _q - 2, _q)


_d = -121665 * _inv(121666)
_I = pow(2, (_q - 1) // 4, _q)


def _xrecover(y: int) -> int:
    xx = (y * y - 1) * _inv(_d * y * y + 1)
    x = pow(xx, (_q + 3) // 8, _q)
    if (x * x - xx) % _q != 0:
        x = (x * _I) % _q
    if x % 2 != 0:
        x = _q - x
    return x


_By = 4 * _inv(5)
_Bx = _xrecover(_By)
_B = [_Bx % _q, _By % _q]


def _edwards(P: list[int], Q: list[int]) -> list[int]:
    x1, y1 = P[0], P[1]
    x2, y2 = Q[0], Q[1]
    x3 = (x1 * y2 + x2 * y1) * _inv(1 + _d * x1 * x2 * y1 * y2)
    y3 = (y1 * y2 + x1 * x2) * _inv(1 - _d * x1 * x2 * y1 * y2)
    return [x3 % _q, y3 % _q]


def _scalarmult(P: list[int], e: int) -> list[int]:
    if e == 0:
        return [0, 1]
    Q = _scalarmult(P, e // 2)
    Q = _edwards(Q, Q)
    if e & 1:
        Q = _edwards(Q, P)
    return Q


def _encodeint(y: int) -> bytes:
    bits = [(y >> i) & 1 for i in range(_b)]
    return bytes(sum([bits[i * 8 + j] << j for j in range(8)]) for i in range(_b // 8))


def _encodepoint(P: list[int]) -> bytes:
    x, y = P[0], P[1]
    bits = [(y >> i) & 1 for i in range(_b - 1)] + [x & 1]
    return bytes(sum([bits[i * 8 + j] << j for j in range(8)]) for i in range(_b // 8))


def _bit(h: bytes, i: int) -> int:
    return (h[i // 8] >> (i % 8)) & 1


def _decodeint(s: bytes) -> int:
    return int.from_bytes(s, "little")


def _decodepoint(s: bytes) -> list[int]:
    y = int.from_bytes(s[:31] + bytes([s[31] & 127]), "little")
    x = _xrecover(y)
    if (x & 1) != ((s[31] >> 7) & 1):
        x = _q - x
    return [x, y]


def ed25519_publickey(sk: bytes) -> bytes:
    """Generate 32-byte Ed25519 public key from 32-byte secret seed."""
    h = hashlib.sha512(sk).digest()
    a = 2**(_b - 2) + sum(2**i * _bit(h, i) for i in range(3, _b - 2))
    A = _scalarmult(_B, a)
    return _encodepoint(A)


def ed25519_sign(msg: bytes, sk: bytes, pk: bytes) -> bytes:
    """Sign message using Ed25519 secret seed and public key."""
    h = hashlib.sha512(sk).digest()
    a = 2**(_b - 2) + sum(2**i * _bit(h, i) for i in range(3, _b - 2))
    r = _decodeint(hashlib.sha512(h[32:] + msg).digest()) % _l
    R = _scalarmult(_B, r)
    R_bytes = _encodepoint(R)
    k = _decodeint(hashlib.sha512(R_bytes + pk + msg).digest()) % _l
    S = (r + k * a) % _l
    return R_bytes + _encodeint(S)


# ---------------------------------------------------------------------------
# Solana Keypair and Wallet Support
# ---------------------------------------------------------------------------

class SolanaKeypair:
    """Manages Solana ed25519 keypair and public address."""

    def __init__(self, secret_seed: bytes) -> None:
        if len(secret_seed) == 64:
            self.seed = secret_seed[:32]
            self.public_key_bytes = secret_seed[32:]
        elif len(secret_seed) == 32:
            self.seed = secret_seed
            self.public_key_bytes = ed25519_publickey(self.seed)
        else:
            raise ValueError("Secret seed must be 32 or 64 bytes")
        self.address = b58encode(self.public_key_bytes)

    @classmethod
    def generate(cls) -> "SolanaKeypair":
        """Generate a brand new random Solana keypair."""
        return cls(secrets.token_bytes(32))

    @classmethod
    def from_base58_private_key(cls, b58_key: str) -> "SolanaKeypair":
        """Parse keypair from a Base58-encoded private key."""
        raw = b58decode(b58_key.strip())
        return cls(raw)

    def to_base58_private_key(self) -> str:
        """Export full 64-byte private key as Base58 string."""
        return b58encode(self.seed + self.public_key_bytes)

    def sign(self, message: bytes) -> bytes:
        """Sign a binary payload (e.g. transaction message)."""
        return ed25519_sign(message, self.seed, self.public_key_bytes)


# ---------------------------------------------------------------------------
# Litecoin Keypair & Address Generation
# ---------------------------------------------------------------------------

def sha256(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()


def ripemd160(b: bytes) -> bytes:
    h = hashlib.new("ripemd160")
    h.update(b)
    return h.digest()


def hash160(b: bytes) -> bytes:
    return ripemd160(sha256(b))


class LitecoinWallet:
    """Litecoin address generator and key manager (Native SegWit Bech32 & Legacy)."""

    def __init__(self, private_key_bytes: bytes) -> None:
        if len(private_key_bytes) != 32:
            raise ValueError("Private key must be 32 bytes")
        self.private_key_bytes = private_key_bytes
        self.public_key_bytes = self._derive_compressed_public_key()
        self.pkh = hash160(self.public_key_bytes)
        # Native SegWit (ltc1q...)
        self.bech32_address = encode_segwit_address("ltc", 0, self.pkh)
        # Legacy P2PKH (L...)
        self.legacy_address = b58encode_check(b"\x30" + self.pkh)
        # Default address is Native SegWit for lowest fees
        self.address = self.bech32_address

    def _derive_compressed_public_key(self) -> bytes:
        """Derive secp256k1 public key point."""
        try:
            # Check if ecdsa is available
            import ecdsa
            sk = ecdsa.SigningKey.from_string(self.private_key_bytes, curve=ecdsa.SECP256k1)
            vk = sk.verifying_key
            x = vk.pubkey.point.x()
            y = vk.pubkey.point.y()
            prefix = b"\x02" if y % 2 == 0 else b"\x03"
            return prefix + x.to_bytes(32, "big")
        except ImportError:
            # Fallback pure-python secp256k1 point multiplication
            return _secp256k1_pubkey(self.private_key_bytes)

    @classmethod
    def generate(cls) -> "LitecoinWallet":
        """Generate a random new Litecoin wallet."""
        return cls(secrets.token_bytes(32))

    @classmethod
    def from_wif(cls, wif_str: str) -> "LitecoinWallet":
        """Load from Litecoin WIF private key."""
        raw = b58decode_check(wif_str.strip())
        # LTC WIF prefix is 0xB0 (176) for mainnet
        if raw[0] not in (0xB0, 0x80):
            raise ValueError(f"Invalid WIF prefix byte: {hex(raw[0])}")
        key_bytes = raw[1:33]
        return cls(key_bytes)

    def to_wif(self, compressed: bool = True) -> str:
        """Export as Litecoin WIF private key."""
        payload = b"\xB0" + self.private_key_bytes
        if compressed:
            payload += b"\x01"
        return b58encode_check(payload)


# Fallback pure python secp256k1 point multiplication
_SECP_P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
_SECP_A = 0
_SECP_B = 7
_SECP_GX = 0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798
_SECP_GY = 0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8


def _secp256k1_inv(a: int, n: int = _SECP_P) -> int:
    return pow(a, n - 2, n)


def _secp256k1_add(P: tuple[int, int], Q: tuple[int, int]) -> tuple[int, int]:
    if P == (0, 0):
        return Q
    if Q == (0, 0):
        return P
    x1, y1 = P
    x2, y2 = Q
    if x1 == x2 and y1 != y2:
        return (0, 0)
    if x1 == x2:
        m = (3 * x1 * x1 + _SECP_A) * _secp256k1_inv(2 * y1)
    else:
        m = (y2 - y1) * _secp256k1_inv(x2 - x1)
    m %= _SECP_P
    x3 = (m * m - x1 - x2) % _SECP_P
    y3 = (m * (x1 - x3) - y1) % _SECP_P
    return (x3, y3)


def _secp256k1_mul(k: int, P: tuple[int, int] = (_SECP_GX, _SECP_GY)) -> tuple[int, int]:
    R = (0, 0)
    while k > 0:
        if k & 1:
            R = _secp256k1_add(R, P)
        P = _secp256k1_add(P, P)
        k >>= 1
    return R


def _secp256k1_pubkey(privkey_bytes: bytes) -> bytes:
    k = int.from_bytes(privkey_bytes, "big")
    x, y = _secp256k1_mul(k)
    prefix = b"\x02" if y % 2 == 0 else b"\x03"
    return prefix + x.to_bytes(32, "big")


# ---------------------------------------------------------------------------
# Address Validators
# ---------------------------------------------------------------------------

_SOLANA_ADDR_REGEX = re.compile(r"^[1-9A-HJ-NP-Za-km-z]{32,44}$")
_LTC_BECH32_REGEX = re.compile(r"^(ltc1)[0-9ac-hj-np-z]{38,59}$", re.IGNORECASE)
_LTC_LEGACY_REGEX = re.compile(r"^[LM3][a-km-zA-HJ-NP-Z1-9]{26,35}$")


def validate_solana_address(address: str) -> bool:
    """Validate a Solana public address."""
    addr = address.strip()
    if not _SOLANA_ADDR_REGEX.match(addr):
        return False
    try:
        raw = b58decode(addr)
        return len(raw) == 32
    except Exception:
        return False


def validate_litecoin_address(address: str) -> bool:
    """Validate a Litecoin address (Bech32 Native SegWit, Legacy L, or P2SH M/3)."""
    addr = address.strip()
    # Check Bech32 Native SegWit (ltc1...)
    if addr.lower().startswith("ltc1"):
        if not _LTC_BECH32_REGEX.match(addr):
            return False
        # Decode and verify checksum
        try:
            hrp, data = addr.lower().split("1", 1)
            if hrp != "ltc":
                return False
            data_ints = [CHARSET_MAP[c] for c in data]
            return bech32_verify_checksum(hrp, data_ints)
        except Exception:
            return False

    # Check Legacy or P2SH
    if _LTC_LEGACY_REGEX.match(addr):
        try:
            raw = b58decode_check(addr)
            # 0x30 = 'L' (P2PKH), 0x32 = 'M' (P2SH), 0x05 = '3' (Legacy P2SH)
            return len(raw) == 21 and raw[0] in (0x30, 0x32, 0x05)
        except Exception:
            return False

    return False


def validate_crypto_address(coin: str, address: str) -> bool:
    """Validate address for the specified coin ('LTC' or 'SOL')."""
    c = coin.upper()
    if c == "LTC":
        return validate_litecoin_address(address)
    elif c == "SOL":
        return validate_solana_address(address)
    return False
