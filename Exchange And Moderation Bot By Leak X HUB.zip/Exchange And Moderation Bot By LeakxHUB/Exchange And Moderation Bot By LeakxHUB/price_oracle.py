"""
Price Oracle and Swap Calculation Engine
========================================
High-reliability price feeds from Binance, CoinGecko, and Coinbase with multi-tier fallbacks,
30-second smart caching, and precise Decimal arithmetic for LTC ↔ SOL swaps.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
import urllib.request
from decimal import Decimal, InvalidOperation, ROUND_DOWN, ROUND_HALF_UP
from typing import NamedTuple, Optional

log = logging.getLogger("exchange.oracle")

CACHE_TTL_SECONDS = 30.0

# Standard estimated network gas/miner fees subtracted for destination payouts
ESTIMATED_NETWORK_FEES = {
    "LTC": Decimal("0.00005"),   # ~0.00005 LTC (~$0.004)
    "SOL": Decimal("0.000005"),  # ~0.000005 SOL (~$0.0008)
}


class SwapQuote(NamedTuple):
    from_coin: str
    to_coin: str
    from_amount: Decimal
    to_amount: Decimal
    usd_value: Decimal
    exchange_rate: Decimal
    fee_percent: Decimal
    fee_usd: Decimal
    network_fee: Decimal
    min_amount_usd: Decimal
    valid_until: int


class PriceCache:
    def __init__(self) -> None:
        self.ltc_usd: Decimal = Decimal("85.00")  # safe initial fallback
        self.sol_usd: Decimal = Decimal("150.00") # safe initial fallback
        self.last_updated: float = 0.0
        self._lock = asyncio.Lock()


_cache = PriceCache()


async def _fetch_binance() -> Optional[dict[str, Decimal]]:
    """Fetch prices from Binance public ticker API."""
    def _sync():
        req = urllib.request.Request(
            "https://api.binance.com/api/v3/ticker/price",
            headers={"User-Agent": "ExchangeBot/2.0"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            prices = {}
            for item in data:
                if item.get("symbol") == "LTCUSDT":
                    prices["LTC"] = Decimal(str(item["price"]))
                elif item.get("symbol") == "SOLUSDT":
                    prices["SOL"] = Decimal(str(item["price"]))
            if "LTC" in prices and "SOL" in prices:
                return prices
        return None

    try:
        return await asyncio.to_thread(_sync)
    except Exception as exc:
        log.warning("Binance price fetch error: %s", exc)
        return None


async def _fetch_coingecko() -> Optional[dict[str, Decimal]]:
    """Fetch prices from CoinGecko public API."""
    def _sync():
        req = urllib.request.Request(
            "https://api.coingecko.com/api/v3/simple/price?ids=litecoin,solana&vs_currencies=usd",
            headers={"User-Agent": "ExchangeBot/2.0"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            ltc = data.get("litecoin", {}).get("usd")
            sol = data.get("solana", {}).get("usd")
            if ltc and sol:
                return {"LTC": Decimal(str(ltc)), "SOL": Decimal(str(sol))}
        return None

    try:
        return await asyncio.to_thread(_sync)
    except Exception as exc:
        log.warning("CoinGecko price fetch error: %s", exc)
        return None


async def _fetch_coinbase() -> Optional[dict[str, Decimal]]:
    """Fetch prices from Coinbase public API."""
    def _sync():
        prices = {}
        for coin in ("LTC", "SOL"):
            req = urllib.request.Request(
                f"https://api.coinbase.com/v2/prices/{coin}-USD/spot",
                headers={"User-Agent": "ExchangeBot/2.0"},
            )
            with urllib.request.urlopen(req, timeout=4) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                amount = data.get("data", {}).get("amount")
                if amount:
                    prices[coin] = Decimal(str(amount))
        if "LTC" in prices and "SOL" in prices:
            return prices
        return None

    try:
        return await asyncio.to_thread(_sync)
    except Exception as exc:
        log.warning("Coinbase price fetch error: %s", exc)
        return None


async def get_live_prices(force_refresh: bool = False) -> tuple[Decimal, Decimal]:
    """
    Returns (ltc_usd, sol_usd) with multi-provider fallbacks and smart caching.
    """
    now = time.time()
    if not force_refresh and (now - _cache.last_updated < CACHE_TTL_SECONDS):
        return _cache.ltc_usd, _cache.sol_usd

    async with _cache._lock:
        # Re-check under lock
        if not force_refresh and (time.time() - _cache.last_updated < CACHE_TTL_SECONDS):
            return _cache.ltc_usd, _cache.sol_usd

        # Try providers in sequence: Binance -> CoinGecko -> Coinbase
        prices = await _fetch_binance()
        if not prices:
            prices = await _fetch_coingecko()
        if not prices:
            prices = await _fetch_coinbase()

        if prices and "LTC" in prices and "SOL" in prices:
            _cache.ltc_usd = prices["LTC"]
            _cache.sol_usd = prices["SOL"]
            _cache.last_updated = time.time()
            log.info("Live rates updated: LTC=$%s, SOL=$%s", _cache.ltc_usd, _cache.sol_usd)
        else:
            log.warning("All price providers failed, retaining last cached prices: LTC=$%s, SOL=$%s", _cache.ltc_usd, _cache.sol_usd)

        return _cache.ltc_usd, _cache.sol_usd


async def calculate_swap_quote(
    from_coin: str,
    to_coin: str,
    amount_in: Decimal,
    fee_percent: Decimal = Decimal("1.0"),
    min_amount_usd: Decimal = Decimal("0.01"),
) -> SwapQuote:
    """
    Calculate an accurate swap quote for LTC ↔ SOL with fee and minimum checks.
    Raises ValueError on invalid pairs or amounts.
    """
    fc = from_coin.upper().strip()
    tc = to_coin.upper().strip()

    if fc not in ("LTC", "SOL") or tc not in ("LTC", "SOL"):
        raise ValueError("Only LTC and SOL currencies are supported.")
    if fc == tc:
        raise ValueError("Source and destination currencies must be different.")
    if amount_in <= Decimal("0"):
        raise ValueError("Amount must be greater than zero.")

    ltc_usd, sol_usd = await get_live_prices()

    if fc == "LTC":
        usd_value = (amount_in * ltc_usd).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
        raw_rate = ltc_usd / sol_usd
        network_fee = ESTIMATED_NETWORK_FEES["SOL"]
    else:  # fc == "SOL"
        usd_value = (amount_in * sol_usd).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
        raw_rate = sol_usd / ltc_usd
        network_fee = ESTIMATED_NETWORK_FEES["LTC"]

    # Check minimum USD amount (user asked for $0.01 minimum)
    if usd_value < min_amount_usd:
        raise ValueError(
            f"Amount too low: ${usd_value:.4f} USD. Minimum exchange amount is ${min_amount_usd:.2f} USD."
        )

    # Calculate fee
    fee_multiplier = (Decimal("100") - fee_percent) / Decimal("100")
    effective_rate = raw_rate * fee_multiplier
    fee_usd = (usd_value * (fee_percent / Decimal("100"))).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)

    # Gross payout before network fee
    gross_payout = amount_in * effective_rate

    # Subtract estimated network miner/gas fee
    net_payout = gross_payout - network_fee
    if net_payout <= Decimal("0"):
        raise ValueError(
            f"Amount after network fee is too small to payout. Try a slightly higher amount."
        )

    # Truncate to appropriate decimal places (8 decimals for LTC and SOL)
    to_amount = net_payout.quantize(Decimal("0.00000001"), rounding=ROUND_DOWN)
    effective_rate = effective_rate.quantize(Decimal("0.00000001"), rounding=ROUND_HALF_UP)

    valid_until = int(time.time() + 1800)  # Quote valid for 30 minutes

    return SwapQuote(
        from_coin=fc,
        to_coin=tc,
        from_amount=amount_in,
        to_amount=to_amount,
        usd_value=usd_value,
        exchange_rate=effective_rate,
        fee_percent=fee_percent,
        fee_usd=fee_usd,
        network_fee=network_fee,
        min_amount_usd=min_amount_usd,
        valid_until=valid_until,
    )


# ---------------------------------------------------------------------------
# Formatting Helpers
# ---------------------------------------------------------------------------

def format_crypto(coin: str, amount: Decimal | float | int) -> str:
    """Format crypto amount cleanly without excessive scientific notation or trailing zeros."""
    dec = Decimal(str(amount)).normalize()
    text = format(dec, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text or "0"


def format_usd(amount: Decimal | float | int) -> str:
    """Format USD value with 2-4 decimal places."""
    dec = Decimal(str(amount))
    if dec < Decimal("1.00"):
        return f"${dec:.4f}"
    return f"${dec:.2f}"
