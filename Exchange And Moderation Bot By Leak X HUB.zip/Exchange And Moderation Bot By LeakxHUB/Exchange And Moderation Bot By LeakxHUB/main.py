"""
Discord Automated C2C Crypto Exchange & Moderation Bot
======================================================
Automated, high-scale Crypto-to-Crypto (LTC ↔ SOL) exchange bot.
Designed for 10,000+ users and thousands of daily transactions.

Features:
- Automated instant exchange: LTC ➔ SOL and SOL ➔ LTC
- Real-time price oracle (Binance + CoinGecko + Coinbase with smart caching)
- Minimum exchange: $0.01 USD
- Unique ephemeral deposit address per swap (0 collision, anti-double-spend)
- Background blockchain monitoring & automatic payout dispatch
- High-concurrency SQLite WAL database with ACID transactions
- Components V2 LayoutViews with full persistent button interactions
- Server moderation suite (kick, ban, unban, mute, lock, unlock, hide, unhide)
- Giveaways system with reaction tracking
- Full administrator controls (fee, min amount, hot wallet balance & withdrawal)
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
import re
import secrets
import time
from datetime import timedelta
from decimal import Decimal, InvalidOperation, ROUND_DOWN, ROUND_HALF_UP
from pathlib import Path
from typing import Any, Optional

import discord
from discord import app_commands
from discord.ext import commands

import database
import price_oracle
from crypto_utils import (
    validate_crypto_address,
    validate_litecoin_address,
    validate_solana_address,
)
from exchange_manager import (
    ExchangeManager,
    get_explorer_url,
    get_qr_code_url,
)
from price_oracle import (
    calculate_swap_quote,
    format_crypto,
    format_usd,
    get_live_prices,
    SwapQuote,
)

# ---------------------------------------------------------------------------
# Directories and Configuration
# ---------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "config.json"
SETTINGS_FILE = BASE_DIR / "settings.json"
GIVEAWAYS_FILE = BASE_DIR / "giveaways.json"
EMOJIS_FILE = BASE_DIR / "emojis.json"


def _parse_snowflake(value: Any) -> Optional[int]:
    if value is None or value is False:
        return None
    if isinstance(value, int):
        return value if value > 0 else None
    text = str(value).strip()
    if text.isdigit():
        parsed = int(text)
        return parsed if parsed > 0 else None
    return None


def load_config() -> dict[str, Any]:
    if not CONFIG_FILE.exists():
        raise SystemExit(
            "config.json was not found. Please create config.json with your bot token and guild_id."
        )
    try:
        raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"config.json is not valid JSON: {exc}") from exc

    if not isinstance(raw, dict):
        raise SystemExit("config.json must contain a JSON object.")

    token = str(raw.get("token") or raw.get("DISCORD_TOKEN") or "").strip()
    guild_id = _parse_snowflake(raw.get("guild_id", raw.get("GUILD_ID")))

    if not token or token == "YOUR_BOT_TOKEN_HERE":
        raise SystemExit("config.json is missing a valid 'token'.")
    if guild_id is None:
        raise SystemExit("config.json is missing a valid 'guild_id'.")

    return raw


CONFIG_DATA = load_config()
DISCORD_TOKEN = str(CONFIG_DATA.get("token")).strip()
GUILD_ID = int(CONFIG_DATA.get("guild_id"))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
log = logging.getLogger("c2c-bot")

ACCENT_GOLD = 0xF0B90B
ACCENT_OK = 0x2ECC71
ACCENT_ERR = 0xE74C3C
ACCENT_PURPLE = 0x9945FF  # Solana purple
ACCENT_BLUE = 0x345D9D    # Litecoin blue

# ---------------------------------------------------------------------------
# Emojis Setup
# ---------------------------------------------------------------------------

DEFAULT_EMOJIS = {
    "thunder": "⚡",
    "exchange": "🔄",
    "crypto": "🪙",
    "blue_dot": "🔹",
    "warning": "⚠️",
    "cross": "❌",
    "tick": "✅",
    "wallet": "👛",
    "details": "📋",
    "dot": "•",
    "arrow_addy": "➔",
    "arrow_name": "➔",
    "note": "📝",
    "sa_tick": "✅",
    "gift": "🎁",
    "falcon_react": "🎁",
    "dev": "⚙️",
    "slash": "💻",
    "star": "⭐",
    "calculator": "🧮",
    "ok": "✅",
    "err": "❌",
    "currency": "💱",
    "ltc": "🪙",
    "sol": "🟣",
}


def load_emojis() -> dict[str, str]:
    if not EMOJIS_FILE.exists():
        try:
            EMOJIS_FILE.write_text(json.dumps(DEFAULT_EMOJIS, indent=4) + "\n", encoding="utf-8")
        except OSError:
            pass
        return dict(DEFAULT_EMOJIS)
    try:
        data = json.loads(EMOJIS_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            merged = dict(DEFAULT_EMOJIS)
            merged.update({str(k): str(v) for k, v in data.items()})
            return merged
    except (OSError, json.JSONDecodeError):
        pass
    return dict(DEFAULT_EMOJIS)


EMOJI_MAP = load_emojis()


def e(key: str) -> str:
    return EMOJI_MAP.get(key, DEFAULT_EMOJIS.get(key, "•"))


def parse_emoji_markup(value: str) -> Optional[discord.PartialEmoji]:
    match = re.match(r"^<(a?):([a-zA-Z0-9_]+):([0-9]+)>$", value.strip())
    if not match:
        return None
    animated = bool(match.group(1))
    name = match.group(2)
    emoji_id = int(match.group(3))
    return discord.PartialEmoji(name=name, id=emoji_id, animated=animated)


def pe(key: str) -> Optional[discord.PartialEmoji]:
    markup = e(key)
    parsed = parse_emoji_markup(markup)
    if parsed is not None:
        return parsed
    if len(markup) <= 4:
        return discord.PartialEmoji(name=markup)
    return None


EMOJI_THUNDER = e("thunder")
EMOJI_EXCHANGE = e("exchange")
EMOJI_CRYPTO = e("crypto")
EMOJI_DOT = e("blue_dot")
EMOJI_WARNING = e("warning")
EMOJI_CROSS = e("cross")
EMOJI_TICK = e("tick")
EMOJI_WALLET = e("wallet")
EMOJI_DETAILS = e("details")
EMOJI_NOTE = e("note")
EMOJI_GIFT = e("gift")
EMOJI_FALCON = e("falcon_react")
EMOJI_CALCULATOR = e("calculator")

PARTIAL_EXCHANGE = pe("exchange")
PARTIAL_CALCULATOR = pe("calculator")
PARTIAL_TICK = pe("tick")
PARTIAL_CROSS = pe("cross")
PARTIAL_WALLET = pe("wallet")
PARTIAL_FALCON = pe("falcon_react")
PARTIAL_DEV = pe("dev")
PARTIAL_SLASH = pe("slash")
PARTIAL_STAR = pe("star")

# ---------------------------------------------------------------------------
# Exchange Manager Engine & Database
# ---------------------------------------------------------------------------

database.init_db()
exchange_mgr = ExchangeManager(CONFIG_DATA)

# ---------------------------------------------------------------------------
# Settings & Giveaways Persistence
# ---------------------------------------------------------------------------

def _default_settings() -> dict[str, Any]:
    return {
        "staff_role_id": None,
        "ticket_category_id": None,
        "ticket_counter": 1,
        "prefix": ".",
    }


def load_settings_sync() -> dict[str, Any]:
    if not SETTINGS_FILE.exists():
        save_settings_sync(_default_settings())
        return _default_settings()
    try:
        raw = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            return _default_settings()
        return {
            "staff_role_id": _parse_snowflake(raw.get("staff_role_id")),
            "ticket_category_id": _parse_snowflake(raw.get("ticket_category_id")),
            "ticket_counter": int(raw.get("ticket_counter") or 1),
            "prefix": str(raw.get("prefix") or ".").strip() or ".",
        }
    except Exception:
        return _default_settings()


def save_settings_sync(data: dict[str, Any]) -> None:
    payload = {
        "staff_role_id": data.get("staff_role_id"),
        "ticket_category_id": data.get("ticket_category_id"),
        "ticket_counter": data.get("ticket_counter", 1),
        "prefix": data.get("prefix", "."),
    }
    tmp = SETTINGS_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=4) + "\n", encoding="utf-8")
    tmp.replace(SETTINGS_FILE)


_settings_lock = asyncio.Lock()


async def get_settings() -> dict[str, Any]:
    async with _settings_lock:
        return load_settings_sync()


async def update_settings(**kwargs: Any) -> dict[str, Any]:
    async with _settings_lock:
        current = load_settings_sync()
        current.update(kwargs)
        save_settings_sync(current)
        return current


async def next_ticket_number() -> int:
    async with _settings_lock:
        current = load_settings_sync()
        num = int(current.get("ticket_counter", 1))
        current["ticket_counter"] = num + 1
        save_settings_sync(current)
        return num


# Giveaways
def load_giveaways_sync() -> list[dict[str, Any]]:
    if not GIVEAWAYS_FILE.exists():
        return []
    try:
        raw = json.loads(GIVEAWAYS_FILE.read_text(encoding="utf-8"))
        return raw if isinstance(raw, list) else []
    except Exception:
        return []


def save_giveaways_sync(items: list[dict[str, Any]]) -> None:
    tmp = GIVEAWAYS_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(items, indent=4) + "\n", encoding="utf-8")
    tmp.replace(GIVEAWAYS_FILE)


_giveaways_lock = asyncio.Lock()


async def add_giveaway(record: dict[str, Any]) -> None:
    async with _giveaways_lock:
        items = load_giveaways_sync()
        items.append(record)
        save_giveaways_sync(items)


async def update_giveaway(message_id: int, **kwargs: Any) -> Optional[dict[str, Any]]:
    async with _giveaways_lock:
        items = load_giveaways_sync()
        target = None
        for item in items:
            if item.get("message_id") == message_id:
                item.update(kwargs)
                target = item
                break
        if target is not None:
            save_giveaways_sync(items)
        return target


async def add_giveaway_entry(message_id: int, user_id: int) -> None:
    async with _giveaways_lock:
        items = load_giveaways_sync()
        for item in items:
            if item.get("message_id") == message_id and not item.get("ended"):
                entries = item.setdefault("entries", [])
                if user_id not in entries:
                    entries.append(user_id)
                    save_giveaways_sync(items)
                break


async def remove_giveaway_entry(message_id: int, user_id: int) -> None:
    async with _giveaways_lock:
        items = load_giveaways_sync()
        for item in items:
            if item.get("message_id") == message_id and not item.get("ended"):
                entries = item.setdefault("entries", [])
                if user_id in entries:
                    entries.remove(user_id)
                    save_giveaways_sync(items)
                break


# ---------------------------------------------------------------------------
# Formatting & Duration Helpers
# ---------------------------------------------------------------------------

_DURATION_RE = re.compile(r"^(\d+)\s*([smhdw])$", re.IGNORECASE)
_DURATION_UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}


def parse_duration(raw: str) -> tuple[int, str]:
    cleaned = (raw or "").strip().lower()
    match = _DURATION_RE.fullmatch(cleaned)
    if not match:
        raise ValueError("invalid duration")
    amount = int(match.group(1))
    unit = match.group(2).lower()
    seconds = amount * _DURATION_UNITS[unit]
    if amount <= 0 or seconds <= 0:
        raise ValueError("invalid duration")
    return seconds, cleaned


def parse_crypto_amount(raw: str, coin: str, ltc_usd: Decimal, sol_usd: Decimal) -> Decimal:
    """
    Parse user amount input. Supports:
    - Pure crypto amount: e.g. '0.05', '1.25'
    - USD amount with dollar sign: e.g. '$10', '$0.01'
    """
    cleaned = (raw or "").strip().replace(",", "")
    if not cleaned:
        raise ValueError("Amount cannot be empty.")

    is_usd = False
    if cleaned.startswith("$"):
        is_usd = True
        cleaned = cleaned[1:].strip()

    try:
        val = Decimal(cleaned)
    except (InvalidOperation, ValueError):
        raise ValueError(f"'{raw}' is not a valid numeric amount.")

    if val <= Decimal("0") or not val.is_finite():
        raise ValueError("Amount must be greater than zero.")

    if is_usd:
        # Convert USD to crypto amount
        price = ltc_usd if coin.upper() == "LTC" else sol_usd
        return (val / price).quantize(Decimal("0.00000001"), rounding=ROUND_HALF_UP)

    return val


def is_administrator(interaction: discord.Interaction) -> bool:
    perms = getattr(interaction.user, "guild_permissions", None)
    return bool(perms and perms.administrator)


def guild_display_name(interaction: discord.Interaction) -> str:
    if interaction.guild and interaction.guild.name:
        return interaction.guild.name
    return "Exchange"


# ---------------------------------------------------------------------------
# Components V2 Base Layout Helpers
# ---------------------------------------------------------------------------

class NoticeView(discord.ui.LayoutView):
    """Components V2 LayoutView with Container and TextDisplay."""

    def __init__(self, text: str, color: int = ACCENT_GOLD, timeout: Optional[float] = 180) -> None:
        super().__init__(timeout=timeout)
        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay(text),
                accent_color=color,
            )
        )


async def send_v2(
    interaction: discord.Interaction,
    text: str,
    *,
    color: int = ACCENT_GOLD,
    ephemeral: bool = False,
    view: Optional[discord.ui.LayoutView] = None,
) -> None:
    layout = view if view is not None else NoticeView(text, color=color)
    if interaction.response.is_done():
        await interaction.followup.send(view=layout, ephemeral=ephemeral)
    else:
        await interaction.response.send_message(view=layout, ephemeral=ephemeral)


async def send_permission_denied(interaction: discord.Interaction) -> None:
    await send_v2(
        interaction,
        "## ❌ Permission Denied\n\nThis command requires **Administrator** permissions.",
        color=ACCENT_ERR,
        ephemeral=True,
    )


# ---------------------------------------------------------------------------
# C2C Exchange UI Panels & Buttons
# ---------------------------------------------------------------------------

PANEL_SWAP_LTC_TO_SOL_ID = "c2c_panel_swap_ltc_to_sol"
PANEL_SWAP_SOL_TO_LTC_ID = "c2c_panel_swap_sol_to_ltc"
PANEL_CALC_ID = "c2c_panel_calculator"
PANEL_RATES_ID = "c2c_panel_rates"
PANEL_TICKET_ID = "c2c_panel_open_ticket"


async def generate_c2c_panel_text(server_name: str) -> str:
    ltc_usd, sol_usd = await get_live_prices()
    fee = await database.get_setting("fee_percent", CONFIG_DATA.get("fee_percent", 1.0))
    min_usd = await database.get_setting("min_exchange_usd", CONFIG_DATA.get("min_exchange_usd", 0.01))

    # Calculate 1 LTC to SOL and 1 SOL to LTC
    ltc_to_sol = (ltc_usd / sol_usd).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
    sol_to_ltc = (sol_usd / ltc_usd).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)

    return (
        f"## {EMOJI_THUNDER} **{server_name.upper()} AUTOMATED C2C EXCHANGE**\n\n"
        f"Fast, automated, and secure **Crypto-to-Crypto** swaps.\n"
        f"Deposits are automatically verified on-chain and payouts are sent instantly!\n\n"
        f"### {EMOJI_EXCHANGE} **LIVE EXCHANGE RATES**\n"
        f"> **LTC ➔ SOL:** `1 LTC ≈ {ltc_to_sol} SOL` *(${ltc_usd:.2f})*\n"
        f"> **SOL ➔ LTC:** `1 SOL ≈ {sol_to_ltc} LTC` *(${sol_usd:.2f})*\n\n"
        f"### ⚙️ **EXCHANGE RULES & SPECS**\n"
        f"> {EMOJI_DOT} **Minimum Exchange:** `${min_usd:.2f} USD` *(Ultra low!)*\n"
        f"> {EMOJI_DOT} **Exchange Fee:** `{fee}%`\n"
        f"> {EMOJI_DOT} **Payout Speed:** `Automated & Instant (24/7)`\n"
        f"> {EMOJI_DOT} **Confirmations:** `1-conf / instant finality`\n\n"
        f"-# {EMOJI_WARNING} *Click a button below to start your swap instantly.*"
    )


class SwapLtcToSolButton(discord.ui.Button):
    def __init__(self) -> None:
        super().__init__(
            label="Swap LTC ➔ SOL",
            emoji="🟣",
            style=discord.ButtonStyle.primary,
            custom_id=PANEL_SWAP_LTC_TO_SOL_ID,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_modal(SwapOrderModal(from_coin="LTC", to_coin="SOL"))


class SwapSolToLtcButton(discord.ui.Button):
    def __init__(self) -> None:
        super().__init__(
            label="Swap SOL ➔ LTC",
            emoji="🪙",
            style=discord.ButtonStyle.primary,
            custom_id=PANEL_SWAP_SOL_TO_LTC_ID,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_modal(SwapOrderModal(from_coin="SOL", to_coin="LTC"))


class CalculatorButton(discord.ui.Button):
    def __init__(self) -> None:
        super().__init__(
            label="Calculator",
            emoji=PARTIAL_CALCULATOR,
            style=discord.ButtonStyle.secondary,
            custom_id=PANEL_CALC_ID,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_modal(CalculatorModal())


class RefreshRatesButton(discord.ui.Button):
    def __init__(self) -> None:
        super().__init__(
            label="Live Rates",
            emoji="📊",
            style=discord.ButtonStyle.secondary,
            custom_id=PANEL_RATES_ID,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        ltc_usd, sol_usd = await get_live_prices(force_refresh=True)
        ltc_to_sol = (ltc_usd / sol_usd).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
        sol_to_ltc = (sol_usd / ltc_usd).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
        text = (
            f"## 📊 Live Crypto Rates\n\n"
            f"• **Litecoin (LTC):** `${ltc_usd:.2f} USD`\n"
            f"• **Solana (SOL):** `${sol_usd:.2f} USD`\n\n"
            f"**1 LTC = `{ltc_to_sol} SOL`**\n"
            f"**1 SOL = `{sol_to_ltc} LTC`**\n\n"
            f"-# Updated in real-time from Binance & CoinGecko"
        )
        await send_v2(interaction, text, color=ACCENT_OK, ephemeral=True)


class TicketOpenExchangeButton(discord.ui.Button):
    def __init__(self) -> None:
        super().__init__(
            label="Open Support Ticket",
            emoji="🎫",
            style=discord.ButtonStyle.secondary,
            custom_id=PANEL_TICKET_ID,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        await create_support_ticket(interaction)


class C2CExchangePanel(discord.ui.LayoutView):
    """Public C2C Exchange Panel posted via /send_exchange_panel."""

    def __init__(self, panel_content: str) -> None:
        super().__init__(timeout=None)
        row1 = discord.ui.ActionRow()
        row1.add_item(SwapLtcToSolButton())
        row1.add_item(SwapSolToLtcButton())

        row2 = discord.ui.ActionRow()
        row2.add_item(CalculatorButton())
        row2.add_item(RefreshRatesButton())
        row2.add_item(TicketOpenExchangeButton())

        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay(panel_content),
                discord.ui.Separator(visible=True, spacing=discord.SeparatorSpacing.small),
                row1,
                row2,
                accent_color=ACCENT_GOLD,
            )
        )


class PersistentC2CExchangeView(discord.ui.LayoutView):
    """Persistent registration for C2C Exchange Panel buttons."""

    def __init__(self) -> None:
        super().__init__(timeout=None)
        row1 = discord.ui.ActionRow()
        row1.add_item(SwapLtcToSolButton())
        row1.add_item(SwapSolToLtcButton())

        row2 = discord.ui.ActionRow()
        row2.add_item(CalculatorButton())
        row2.add_item(RefreshRatesButton())
        row2.add_item(TicketOpenExchangeButton())

        self.add_item(row1)
        self.add_item(row2)


# ---------------------------------------------------------------------------
# Interactive Modals (Swap & Calculator)
# ---------------------------------------------------------------------------

class SwapOrderModal(discord.ui.Modal):
    def __init__(self, from_coin: str, to_coin: str) -> None:
        super().__init__(title=f"Exchange {from_coin} ➔ {to_coin}")
        self.from_coin = from_coin.upper()
        self.to_coin = to_coin.upper()

        self.amount = discord.ui.TextInput(
            label=f"Amount to Send ({self.from_coin} or $USD)",
            placeholder=f"e.g. 0.05 or $10.00 (min $0.01)",
            required=True,
            min_length=1,
            max_length=24,
            style=discord.TextStyle.short,
        )
        self.add_item(self.amount)

        self.payout_address = discord.ui.TextInput(
            label=f"Your {self.to_coin} Receiving Address",
            placeholder=f"Paste your personal {self.to_coin} wallet address here",
            required=True,
            min_length=15,
            max_length=64,
            style=discord.TextStyle.short,
        )
        self.add_item(self.payout_address)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        raw_amt = str(self.amount.value).strip()
        recipient_addr = str(self.payout_address.value).strip()

        # Validate destination address format
        if not validate_crypto_address(self.to_coin, recipient_addr):
            await send_v2(
                interaction,
                f"## ❌ Invalid Address\n\nThe destination address `{recipient_addr}` is not a valid **{self.to_coin}** address.\n"
                f"Please verify and try again.",
                color=ACCENT_ERR,
                ephemeral=True,
            )
            return

        ltc_usd, sol_usd = await get_live_prices()
        try:
            amt_crypto = parse_crypto_amount(raw_amt, self.from_coin, ltc_usd, sol_usd)
        except ValueError as exc:
            await send_v2(interaction, f"## ❌ Invalid Amount\n\n{exc}", color=ACCENT_ERR, ephemeral=True)
            return

        # Defer interaction while generating dedicated swap order
        await interaction.response.defer(ephemeral=True)

        try:
            swap = await exchange_mgr.create_swap(
                user_id=interaction.user.id,
                guild_id=interaction.guild_id or 0,
                channel_id=interaction.channel_id,
                from_coin=self.from_coin,
                to_coin=self.to_coin,
                amount_in=amt_crypto,
                payout_address=recipient_addr,
            )
        except Exception as exc:
            log.exception("Error creating swap: %s", exc)
            await send_v2(interaction, f"## ❌ Swap Creation Failed\n\n{exc}", color=ACCENT_ERR, ephemeral=True)
            return

        # Send Live Swap Tracker Panel
        view = SwapTrackerView(swap)
        await interaction.followup.send(view=view, ephemeral=True)


class CalculatorModal(discord.ui.Modal, title="LTC ↔ SOL Rate Calculator"):
    direction = discord.ui.TextInput(
        label="Pair: 'LTC2SOL' or 'SOL2LTC'",
        placeholder="LTC2SOL",
        default="LTC2SOL",
        required=True,
        min_length=6,
        max_length=8,
        style=discord.TextStyle.short,
    )
    amount = discord.ui.TextInput(
        label="Amount (in crypto or $USD)",
        placeholder="e.g. 0.1 or $25",
        required=True,
        min_length=1,
        max_length=20,
        style=discord.TextStyle.short,
    )

    async def on_submit(self, interaction: discord.Interaction) -> None:
        pair = str(self.direction.value).strip().upper().replace(" ", "")
        if "LTC" in pair and pair.startswith("LTC"):
            fc, tc = "LTC", "SOL"
        elif "SOL" in pair and pair.startswith("SOL"):
            fc, tc = "SOL", "LTC"
        else:
            await send_v2(interaction, "## ❌ Invalid Pair\n\nPlease enter `LTC2SOL` or `SOL2LTC`.", color=ACCENT_ERR, ephemeral=True)
            return

        ltc_usd, sol_usd = await get_live_prices()
        try:
            amt_crypto = parse_crypto_amount(str(self.amount.value), fc, ltc_usd, sol_usd)
            fee = Decimal(str(await database.get_setting("fee_percent", CONFIG_DATA.get("fee_percent", 1.0))))
            min_usd = Decimal(str(await database.get_setting("min_exchange_usd", CONFIG_DATA.get("min_exchange_usd", 0.01))))
            quote = await calculate_swap_quote(fc, tc, amt_crypto, fee, min_usd)
        except Exception as exc:
            await send_v2(interaction, f"## ❌ Calculation Error\n\n{exc}", color=ACCENT_ERR, ephemeral=True)
            return

        text = (
            f"## 💱 **C2C Rate Calculation**\n\n"
            f"**You Send:** `{format_crypto(fc, quote.from_amount)} {fc}` *({format_usd(quote.usd_value)})*\n"
            f"**You Receive:** `{format_crypto(tc, quote.to_amount)} {tc}`\n\n"
            f"**Rate:** `1 {fc} = {quote.exchange_rate} {tc}`\n"
            f"**Fee:** `{quote.fee_percent}%` *({format_usd(quote.fee_usd)})*\n"
            f"**Network Gas:** `~{format_crypto(tc, quote.network_fee)} {tc}`"
        )
        await send_v2(interaction, text, color=ACCENT_GOLD, ephemeral=True)


# ---------------------------------------------------------------------------
# Live Swap Tracker View (Ephemeral & Real-time)
# ---------------------------------------------------------------------------

class CopyDepositAddressButton(discord.ui.Button):
    def __init__(self, deposit_address: str) -> None:
        super().__init__(
            label="Copy Deposit Address",
            emoji="📋",
            style=discord.ButtonStyle.secondary,
            custom_id=f"copy_deposit_{deposit_address[:12]}",
        )
        self.deposit_address = deposit_address

    async def callback(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(
            f"`{self.deposit_address}`",
            ephemeral=True,
        )


class RefreshSwapStatusButton(discord.ui.Button):
    def __init__(self, swap_id: str) -> None:
        super().__init__(
            label="Check Status Now",
            emoji="🔄",
            style=discord.ButtonStyle.primary,
            custom_id=f"refresh_swap_{swap_id}",
        )
        self.swap_id = swap_id

    async def callback(self, interaction: discord.Interaction) -> None:
        swap = await database.get_swap(self.swap_id)
        if not swap:
            await send_v2(interaction, "## ❌ Swap Not Found", color=ACCENT_ERR, ephemeral=True)
            return
        view = SwapTrackerView(swap)
        await interaction.response.edit_message(view=view)


class SwapTrackerView(discord.ui.LayoutView):
    """Live interactive tracker for an ongoing automated swap."""

    def __init__(self, swap: dict[str, Any]) -> None:
        super().__init__(timeout=1800)  # 30 min tracker view
        swap_id = swap["swap_id"]
        from_coin = swap["from_coin"]
        to_coin = swap["to_coin"]
        send_amt = format_crypto(from_coin, swap["expected_deposit_amount"])
        recv_amt = format_crypto(to_coin, swap["expected_payout_amount"])
        usd_val = format_usd(swap["usd_value"])
        deposit_addr = swap["deposit_address"]
        payout_addr = swap["user_payout_address"]
        status = swap["status"]
        qr_url = get_qr_code_url(deposit_addr)

        # Status badge & color
        if status == "PENDING_DEPOSIT":
            status_text = "🟡 **Awaiting Deposit** — Send funds to the deposit address below."
            card_color = ACCENT_GOLD
        elif status in ("DEPOSIT_DETECTED", "CONFIRMING"):
            status_text = "🔵 **Deposit Detected!** — Verifying blockchain confirmations..."
            card_color = ACCENT_BLUE
        elif status == "PROCESSING_PAYOUT":
            status_text = "🟣 **Deposit Confirmed** — Sending payout transaction..."
            card_color = ACCENT_PURPLE
        elif status == "COMPLETED":
            payout_tx = swap.get("payout_tx_hash") or ""
            explorer_link = get_explorer_url(to_coin, payout_tx)
            status_text = f"🟢 **Completed!** — Payout sent! [View on Blockchain]({explorer_link})"
            card_color = ACCENT_OK
        elif status == "EXPIRED":
            status_text = "⏱️ **Expired** — Deposit window expired."
            card_color = ACCENT_ERR
        else:
            status_text = f"ℹ️ **Status:** `{status}`"
            card_color = ACCENT_GOLD

        tracker_text = (
            f"## {EMOJI_EXCHANGE} **ORDER {swap_id}**\n\n"
            f"{status_text}\n\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"**You Send:** `{send_amt} {from_coin}` *({usd_val})*\n"
            f"**You Receive:** `{recv_amt} {to_coin}`\n"
            f"**Destination:** `{payout_addr}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"### 📥 **DEPOSIT ADDRESS ({from_coin}):**\n"
            f"```{deposit_addr}```\n"
            f"-# ⚠️ Send the exact amount above. The bot will automatically detect your deposit and dispatch `{to_coin}` to your destination address.\n"
            f"-# 📷 [Click here to view QR Code]({qr_url})"
        )

        row = discord.ui.ActionRow()
        row.add_item(CopyDepositAddressButton(deposit_addr))
        row.add_item(RefreshSwapStatusButton(swap_id))

        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay(tracker_text),
                discord.ui.Separator(visible=True, spacing=discord.SeparatorSpacing.small),
                row,
                accent_color=card_color,
            )
        )


# ---------------------------------------------------------------------------
# Ticket System Flow
# ---------------------------------------------------------------------------

TICKET_CLOSE_CUSTOM_ID = "ticket_close"
TICKET_CLAIM_CUSTOM_ID = "ticket_claim"


class CloseTicketButton(discord.ui.Button):
    def __init__(self) -> None:
        super().__init__(
            label="Close",
            emoji=PARTIAL_CROSS,
            style=discord.ButtonStyle.danger,
            custom_id=TICKET_CLOSE_CUSTOM_ID,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        await handle_close_ticket(interaction)


class ClaimTicketButton(discord.ui.Button):
    def __init__(self) -> None:
        super().__init__(
            label="Claim",
            emoji=PARTIAL_TICK,
            style=discord.ButtonStyle.success,
            custom_id=TICKET_CLAIM_CUSTOM_ID,
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        await handle_claim_ticket(interaction)


class PersistentCloseTicketView(discord.ui.LayoutView):
    def __init__(self) -> None:
        super().__init__(timeout=None)
        row = discord.ui.ActionRow()
        row.add_item(CloseTicketButton())
        row.add_item(ClaimTicketButton())
        self.add_item(row)


async def create_support_ticket(interaction: discord.Interaction) -> None:
    if interaction.guild is None:
        await send_v2(interaction, "## ❌ Server Only", color=ACCENT_ERR, ephemeral=True)
        return

    settings = await get_settings()
    category_id = settings.get("ticket_category_id")
    staff_role_id = settings.get("staff_role_id")

    if not category_id:
        await send_v2(interaction, "## ❌ Ticket Category Not Configured\n\nRun `/tixcatogery` first.", color=ACCENT_ERR, ephemeral=True)
        return

    category = interaction.guild.get_channel(int(category_id))
    if not isinstance(category, discord.CategoryChannel):
        await send_v2(interaction, "## ❌ Ticket Category Missing\n\nSet it again with `/tixcatogery`.", color=ACCENT_ERR, ephemeral=True)
        return

    staff_role = interaction.guild.get_role(int(staff_role_id)) if staff_role_id else None

    number = await next_ticket_number()
    channel_name = f"ticket-{interaction.user.name[:10]}-{number}"

    overwrites = {
        interaction.guild.default_role: discord.PermissionOverwrite(view_channel=False),
        interaction.user: discord.PermissionOverwrite(
            view_channel=True, send_messages=True, read_message_history=True, attach_files=True
        ),
        interaction.guild.me: discord.PermissionOverwrite(
            view_channel=True, send_messages=True, read_message_history=True, manage_channels=True
        ),
    }
    if staff_role:
        overwrites[staff_role] = discord.PermissionOverwrite(
            view_channel=True, send_messages=True, read_message_history=True
        )

    try:
        channel = await interaction.guild.create_text_channel(
            name=channel_name,
            category=category,
            overwrites=overwrites,
            topic=f"owner:{interaction.user.id}|ticket:{number}",
            reason=f"Support ticket for {interaction.user}",
        )
    except discord.HTTPException as exc:
        await send_v2(interaction, f"## ❌ Failed to create ticket channel: {exc}", color=ACCENT_ERR, ephemeral=True)
        return

    # Post welcome message & exchange controls inside ticket
    server_name = guild_display_name(interaction)
    ticket_welcome_text = (
        f"## {EMOJI_THUNDER} **Welcome to {server_name} Exchange Ticket**\n\n"
        f"Hello {interaction.user.mention}! A staff member will be with you shortly.\n\n"
        f"**Need to perform an automated swap right here?**\n"
        f"Use the buttons below to initiate your exchange, or type your question for support."
    )

    row1 = discord.ui.ActionRow()
    row1.add_item(SwapLtcToSolButton())
    row1.add_item(SwapSolToLtcButton())

    row2 = discord.ui.ActionRow()
    row2.add_item(CloseTicketButton())
    row2.add_item(ClaimTicketButton())

    ticket_layout = discord.ui.LayoutView(timeout=None)
    ticket_layout.add_item(
        discord.ui.Container(
            discord.ui.TextDisplay(ticket_welcome_text),
            discord.ui.Separator(visible=True, spacing=discord.SeparatorSpacing.small),
            row1,
            row2,
            accent_color=ACCENT_GOLD,
        )
    )

    await channel.send(view=ticket_layout)
    await send_v2(interaction, f"## ✅ Ticket Created\n\nYour ticket has been opened: {channel.mention}", color=ACCENT_OK, ephemeral=True)


async def handle_close_ticket(interaction: discord.Interaction) -> None:
    if not isinstance(interaction.channel, discord.TextChannel):
        return
    await send_v2(interaction, f"## {EMOJI_CROSS} Ticket Closing\n\nThis channel will be deleted in 3 seconds...", color=ACCENT_ERR)
    await asyncio.sleep(3)
    try:
        await interaction.channel.delete(reason=f"Ticket closed by {interaction.user}")
    except Exception as exc:
        log.warning("Could not delete ticket channel: %s", exc)


async def handle_claim_ticket(interaction: discord.Interaction) -> None:
    if not isinstance(interaction.channel, discord.TextChannel):
        return
    await send_v2(interaction, f"## {EMOJI_TICK} Ticket Claimed\n\nClaimed by {interaction.user.mention}.", color=ACCENT_OK)


# ---------------------------------------------------------------------------
# Giveaway Watcher Task
# ---------------------------------------------------------------------------

def giveaway_panel_text(item: str, winners: int, end_ts: int, host: discord.abc.User) -> str:
    return (
        f"## {EMOJI_GIFT}  GIVEAWAY\n\n"
        f"{EMOJI_DETAILS}  **Item** {EMOJI_ARROW_ADDY} `{item}`\n\n"
        f"{EMOJI_DETAILS}  **Winners** {EMOJI_ARROW_ADDY} `{winners}`\n\n"
        f"{EMOJI_DETAILS}  **Ends In** {EMOJI_ARROW_ADDY} <t:{end_ts}:R>\n\n"
        f"{EMOJI_DETAILS}  **Hosted By** {EMOJI_ARROW_ADDY} {host.mention}\n\n"
        f"-# {EMOJI_WARNING}  React with {EMOJI_FALCON} To enter in this giveaway"
    )


class GiveawayPanel(discord.ui.LayoutView):
    def __init__(self, text: str) -> None:
        super().__init__(timeout=None)
        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay(text),
                accent_color=ACCENT_GOLD,
            )
        )


async def finish_giveaway(bot_client: commands.Bot, record: dict[str, Any]) -> None:
    message_id = record["message_id"]
    channel_id = record["channel_id"]
    item = record["item"]
    winners_count = int(record.get("winners", 1))
    entries: list[int] = list(record.get("entries") or [])

    channel = bot_client.get_channel(channel_id) or await bot_client.fetch_channel(channel_id)
    if not isinstance(channel, discord.TextChannel):
        await update_giveaway(message_id, ended=True)
        return

    try:
        message = await channel.fetch_message(message_id)
    except discord.HTTPException:
        await update_giveaway(message_id, ended=True)
        return

    random.shuffle(entries)
    chosen_ids = entries[: min(winners_count, len(entries))]
    if chosen_ids:
        mentions = ", ".join(f"<@{uid}>" for uid in chosen_ids)
        result_text = (
            f"## {EMOJI_GIFT} Giveaway Ended!\n\n"
            f"**Prize:** `{item}`\n"
            f"**Winner(s):** {mentions}\n\n"
            "Congratulations! Please contact staff to claim your prize."
        )
    else:
        result_text = (
            f"## {EMOJI_GIFT} Giveaway Ended\n\n"
            f"**Prize:** `{item}`\n"
            "No valid entries were received."
        )

    await update_giveaway(message_id, ended=True)
    await channel.send(
        view=NoticeView(result_text, color=ACCENT_OK),
        allowed_mentions=discord.AllowedMentions(users=True),
    )


async def giveaway_watcher(bot_client: commands.Bot) -> None:
    await bot_client.wait_until_ready()
    while not bot_client.is_closed():
        try:
            items = load_giveaways_sync()
            now = int(time.time())
            for item in items:
                if not item.get("ended") and int(item.get("end_ts", 0)) <= now:
                    await finish_giveaway(bot_client, item)
        except Exception as exc:
            log.warning("Giveaway watcher error: %s", exc)
        await asyncio.sleep(5)


# ---------------------------------------------------------------------------
# Bot Setup and Events
# ---------------------------------------------------------------------------

async def resolve_prefix(bot_inst: commands.Bot, message: discord.Message) -> list[str]:
    settings = load_settings_sync()
    prefix = str(settings.get("prefix") or ".")
    return commands.when_mentioned_or(prefix)(bot_inst, message)


class ExchangeBot(commands.Bot):
    def __init__(self) -> None:
        intents = discord.Intents.all()
        super().__init__(command_prefix=resolve_prefix, intents=intents, help_command=None)

    async def setup_hook(self) -> None:
        # Register persistent views
        self.add_view(PersistentC2CExchangeView())
        self.add_view(PersistentCloseTicketView())

        # Start blockchain swap monitoring task
        exchange_mgr.start_monitoring(self)
        self.loop.create_task(giveaway_watcher(self))

        # Sync slash commands
        guild = discord.Object(id=GUILD_ID)
        self.tree.copy_global_to(guild=guild)
        synced = await self.tree.sync(guild=guild)
        log.info("Synced %s slash command(s) to guild %s.", len(synced), GUILD_ID)

    async def on_ready(self) -> None:
        assert self.user is not None
        log.info("Logged in as %s (ID: %s)", self.user, self.user.id)
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="LTC ↔ SOL Swaps | .c2c",
            )
        )

    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent) -> None:
        if payload.user_id == (self.user.id if self.user else 0):
            return
        await add_giveaway_entry(payload.message_id, payload.user_id)

    async def on_raw_reaction_remove(self, payload: discord.RawReactionActionEvent) -> None:
        await remove_giveaway_entry(payload.message_id, payload.user_id)


bot = ExchangeBot()


# ---------------------------------------------------------------------------
# Prefix Commands (Exchange, Rates, Calc, Moderation)
# ---------------------------------------------------------------------------

@bot.command(name="ping")
async def prefix_ping(ctx: commands.Context) -> None:
    latency_ms = round(bot.latency * 1000)
    await ctx.send(view=NoticeView(f"🏓 **Pong!** Bot latency: `{latency_ms}ms`", color=ACCENT_OK))


@bot.command(name="rates")
async def prefix_rates(ctx: commands.Context) -> None:
    """Show live LTC & SOL rates."""
    ltc_usd, sol_usd = await get_live_prices()
    ltc_to_sol = (ltc_usd / sol_usd).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
    sol_to_ltc = (sol_usd / ltc_usd).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
    text = (
        f"## 📊 **Live C2C Rates**\n\n"
        f"• **Litecoin (LTC):** `${ltc_usd:.2f} USD`\n"
        f"• **Solana (SOL):** `${sol_usd:.2f} USD`\n\n"
        f"**1 LTC = `{ltc_to_sol} SOL`**\n"
        f"**1 SOL = `{sol_to_ltc} LTC`**\n"
        f"-# Minimum exchange: `$0.01 USD`"
    )
    await ctx.send(view=NoticeView(text, color=ACCENT_GOLD))


@bot.command(name="ltc2sol")
async def prefix_ltc2sol(ctx: commands.Context, amount: str | None = None) -> None:
    """Convert LTC to SOL."""
    if not amount:
        await ctx.send(view=NoticeView("## ❌ Usage\n\n`.ltc2sol <amount>`\nExample: `.ltc2sol 0.5`", color=ACCENT_ERR))
        return
    await _prefix_convert(ctx, "LTC", "SOL", amount)


@bot.command(name="sol2ltc")
async def prefix_sol2ltc(ctx: commands.Context, amount: str | None = None) -> None:
    """Convert SOL to LTC."""
    if not amount:
        await ctx.send(view=NoticeView("## ❌ Usage\n\n`.sol2ltc <amount>`\nExample: `.sol2ltc 1.5`", color=ACCENT_ERR))
        return
    await _prefix_convert(ctx, "SOL", "LTC", amount)


@bot.command(name="c2c")
async def prefix_c2c(ctx: commands.Context, amount: str | None = None, from_coin: str = "LTC", to_coin: str = "SOL") -> None:
    """General C2C conversion calculator."""
    if not amount:
        await ctx.send(view=NoticeView("## ❌ Usage\n\n`.c2c <amount> [from_coin] [to_coin]`\nExample: `.c2c 10$ LTC SOL`", color=ACCENT_ERR))
        return
    await _prefix_convert(ctx, from_coin, to_coin, amount)


async def _prefix_convert(ctx: commands.Context, fc: str, tc: str, raw_amount: str) -> None:
    fc = fc.upper()
    tc = tc.upper()
    ltc_usd, sol_usd = await get_live_prices()
    try:
        amt = parse_crypto_amount(raw_amount, fc, ltc_usd, sol_usd)
        fee = Decimal(str(await database.get_setting("fee_percent", CONFIG_DATA.get("fee_percent", 1.0))))
        min_usd = Decimal(str(await database.get_setting("min_exchange_usd", CONFIG_DATA.get("min_exchange_usd", 0.01))))
        quote = await calculate_swap_quote(fc, tc, amt, fee, min_usd)
    except Exception as exc:
        await ctx.send(view=NoticeView(f"## ❌ Error\n\n{exc}", color=ACCENT_ERR))
        return

    text = (
        f"## 💱 **C2C Calculation ({fc} ➔ {tc})**\n\n"
        f"**You Send:** `{format_crypto(fc, quote.from_amount)} {fc}` *({format_usd(quote.usd_value)})*\n"
        f"**You Receive:** `{format_crypto(tc, quote.to_amount)} {tc}`\n\n"
        f"**Rate:** `1 {fc} = {quote.exchange_rate} {tc}`\n"
        f"**Fee:** `{quote.fee_percent}%` *({format_usd(quote.fee_usd)})*\n"
        f"**Network Gas:** `~{format_crypto(tc, quote.network_fee)} {tc}`"
    )
    await ctx.send(view=NoticeView(text, color=ACCENT_GOLD))


@bot.command(name="status")
async def prefix_status(ctx: commands.Context, swap_id: str | None = None) -> None:
    """Check the live blockchain status of any swap."""
    if not swap_id:
        await ctx.send(view=NoticeView("## ❌ Usage\n\n`.status <swap_id>`\nExample: `.status SWAP-A1B2C3`", color=ACCENT_ERR))
        return
    swap = await database.get_swap(swap_id.strip())
    if not swap:
        await ctx.send(view=NoticeView(f"## ❌ Swap Not Found\n\nNo swap record for `{swap_id}`.", color=ACCENT_ERR))
        return
    await ctx.send(view=SwapTrackerView(swap))


# ---------------------------------------------------------------------------
# Slash Commands (Exchange, Panels, Admin Controls)
# ---------------------------------------------------------------------------

@bot.tree.command(name="send_exchange_panel", description="Post the interactive C2C exchange panel. Administrator only.")
@app_commands.default_permissions(administrator=True)
@app_commands.guild_only()
async def slash_send_exchange_panel(interaction: discord.Interaction) -> None:
    if not is_administrator(interaction):
        await send_permission_denied(interaction)
        return

    server_name = guild_display_name(interaction)
    text = await generate_c2c_panel_text(server_name)
    panel = C2CExchangePanel(text)
    await interaction.channel.send(view=panel)
    await send_v2(interaction, "## ✅ C2C Exchange Panel Posted Successfully!", color=ACCENT_OK, ephemeral=True)


@bot.tree.command(name="c2c_calc", description="Calculate LTC ↔ SOL exchange rate and output amount.")
@app_commands.describe(
    from_coin="Source cryptocurrency",
    to_coin="Destination cryptocurrency",
    amount="Amount in crypto (e.g. 0.05) or $USD (e.g. $10)",
)
@app_commands.choices(
    from_coin=[
        app_commands.Choice(name="Litecoin (LTC)", value="LTC"),
        app_commands.Choice(name="Solana (SOL)", value="SOL"),
    ],
    to_coin=[
        app_commands.Choice(name="Solana (SOL)", value="SOL"),
        app_commands.Choice(name="Litecoin (LTC)", value="LTC"),
    ],
)
async def slash_c2c_calc(interaction: discord.Interaction, from_coin: str, to_coin: str, amount: str) -> None:
    if from_coin == to_coin:
        await send_v2(interaction, "## ❌ Source and destination must be different.", color=ACCENT_ERR, ephemeral=True)
        return

    ltc_usd, sol_usd = await get_live_prices()
    try:
        amt = parse_crypto_amount(amount, from_coin, ltc_usd, sol_usd)
        fee = Decimal(str(await database.get_setting("fee_percent", CONFIG_DATA.get("fee_percent", 1.0))))
        min_usd = Decimal(str(await database.get_setting("min_exchange_usd", CONFIG_DATA.get("min_exchange_usd", 0.01))))
        quote = await calculate_swap_quote(from_coin, to_coin, amt, fee, min_usd)
    except Exception as exc:
        await send_v2(interaction, f"## ❌ Error\n\n{exc}", color=ACCENT_ERR, ephemeral=True)
        return

    text = (
        f"## 💱 **C2C Calculation ({from_coin} ➔ {to_coin})**\n\n"
        f"**You Send:** `{format_crypto(from_coin, quote.from_amount)} {from_coin}` *({format_usd(quote.usd_value)})*\n"
        f"**You Receive:** `{format_crypto(to_coin, quote.to_amount)} {to_coin}`\n\n"
        f"**Rate:** `1 {from_coin} = {quote.exchange_rate} {to_coin}`\n"
        f"**Fee:** `{quote.fee_percent}%` *({format_usd(quote.fee_usd)})*\n"
        f"**Network Gas:** `~{format_crypto(to_coin, quote.network_fee)} {to_coin}`"
    )
    await send_v2(interaction, text, color=ACCENT_GOLD)


@bot.tree.command(name="status", description="Check the status of an exchange by Swap ID.")
@app_commands.describe(swap_id="Swap ID (e.g. SWAP-A1B2C3)")
async def slash_status(interaction: discord.Interaction, swap_id: str) -> None:
    swap = await database.get_swap(swap_id.strip())
    if not swap:
        await send_v2(interaction, f"## ❌ Swap Not Found\n\nNo swap record for `{swap_id}`.", color=ACCENT_ERR, ephemeral=True)
        return
    await interaction.response.send_message(view=SwapTrackerView(swap), ephemeral=True)


@bot.tree.command(name="exchange_stats", description="View total exchange volume, completed swaps, and fees. Administrator only.")
@app_commands.default_permissions(administrator=True)
@app_commands.guild_only()
async def slash_exchange_stats(interaction: discord.Interaction) -> None:
    if not is_administrator(interaction):
        await send_permission_denied(interaction)
        return

    stats = await database.get_stats()
    text = (
        f"## 📈 **Automated Exchange Statistics**\n\n"
        f"• **Total Volume:** `${stats.get('total_volume_usd', 0.0):,.2f} USD`\n"
        f"• **Swaps Completed:** `{int(stats.get('total_swaps_completed', 0)):,}`\n"
        f"• **Total Revenue (Fees):** `${stats.get('total_fees_usd', 0.0):,.2f} USD`\n"
        f"• **Active Ongoing Swaps:** `{stats.get('active_swaps', 0)}`"
    )
    await send_v2(interaction, text, color=ACCENT_OK, ephemeral=True)


@bot.tree.command(name="wallet_balance", description="Check on-chain balances of bot hot wallets. Administrator only.")
@app_commands.default_permissions(administrator=True)
@app_commands.guild_only()
async def slash_wallet_balance(interaction: discord.Interaction) -> None:
    if not is_administrator(interaction):
        await send_permission_denied(interaction)
        return

    await interaction.response.defer(ephemeral=True)
    balances = await exchange_mgr.get_hotwallet_balances()

    sol_addr = exchange_mgr.solana_hotwallet.address if exchange_mgr.solana_hotwallet else "Not configured"
    ltc_addr = exchange_mgr.litecoin_hotwallet.address if exchange_mgr.litecoin_hotwallet else "Not configured"

    text = (
        f"## 👛 **Bot Hot Wallet Balances**\n\n"
        f"### 🟣 **Solana Hot Wallet**\n"
        f"• **Balance:** `{balances['SOL']} SOL`\n"
        f"• **Address:** `{sol_addr}`\n\n"
        f"### 🪙 **Litecoin Hot Wallet**\n"
        f"• **Balance:** `{balances['LTC']} LTC`\n"
        f"• **Address:** `{ltc_addr}`\n\n"
        f"-# Keep both wallets funded with liquidity to ensure instantaneous automated payouts."
    )
    await send_v2(interaction, text, color=ACCENT_GOLD, ephemeral=True)


@bot.tree.command(name="set_fee", description="Configure exchange fee percentage. Administrator only.")
@app_commands.describe(percentage="Fee percent, e.g. 1.0 for 1% fee")
@app_commands.default_permissions(administrator=True)
@app_commands.guild_only()
async def slash_set_fee(interaction: discord.Interaction, percentage: float) -> None:
    if not is_administrator(interaction):
        await send_permission_denied(interaction)
        return

    if percentage < 0 or percentage > 25:
        await send_v2(interaction, "## ❌ Fee percentage must be between 0% and 25%.", color=ACCENT_ERR, ephemeral=True)
        return

    await database.set_setting("fee_percent", percentage)
    await send_v2(interaction, f"## ✅ Exchange Fee Updated\n\nNew fee: **{percentage}%**", color=ACCENT_OK)


@bot.tree.command(name="set_min", description="Configure minimum exchange USD amount. Administrator only.")
@app_commands.describe(usd_amount="Minimum USD amount, e.g. 0.01 for 1 cent")
@app_commands.default_permissions(administrator=True)
@app_commands.guild_only()
async def slash_set_min(interaction: discord.Interaction, usd_amount: float) -> None:
    if not is_administrator(interaction):
        await send_permission_denied(interaction)
        return

    if usd_amount <= 0:
        await send_v2(interaction, "## ❌ Minimum amount must be greater than $0.00.", color=ACCENT_ERR, ephemeral=True)
        return

    await database.set_setting("min_exchange_usd", usd_amount)
    await send_v2(interaction, f"## ✅ Minimum Exchange Amount Updated\n\nNew minimum: **${usd_amount:.2f} USD**", color=ACCENT_OK)


@bot.tree.command(name="withdraw_hotwallet", description="Withdraw funds from hot wallet to cold storage. Administrator only.")
@app_commands.describe(
    coin="LTC or SOL",
    amount="Amount to withdraw",
    destination="Your cold storage address",
)
@app_commands.choices(
    coin=[
        app_commands.Choice(name="Litecoin (LTC)", value="LTC"),
        app_commands.Choice(name="Solana (SOL)", value="SOL"),
    ]
)
@app_commands.default_permissions(administrator=True)
@app_commands.guild_only()
async def slash_withdraw_hotwallet(interaction: discord.Interaction, coin: str, amount: float, destination: str) -> None:
    if not is_administrator(interaction):
        await send_permission_denied(interaction)
        return

    c = coin.upper()
    dest = destination.strip()
    if not validate_crypto_address(c, dest):
        await send_v2(interaction, f"## ❌ Invalid {c} destination address.", color=ACCENT_ERR, ephemeral=True)
        return

    dec_amt = Decimal(str(amount))
    await interaction.response.defer(ephemeral=True)

    if c == "SOL":
        if not exchange_mgr.solana_hotwallet:
            await send_v2(interaction, "## ❌ Solana hot wallet not configured.", color=ACCENT_ERR, ephemeral=True)
            return
        success, tx_sig, err = await exchange_mgr.solana_client.send_payout(
            exchange_mgr.solana_hotwallet, dest, dec_amt
        )
    else:
        if not exchange_mgr.litecoin_hotwallet:
            await send_v2(interaction, "## ❌ Litecoin hot wallet not configured.", color=ACCENT_ERR, ephemeral=True)
            return
        success, tx_sig, err = await exchange_mgr.litecoin_client.send_payout(
            exchange_mgr.litecoin_hotwallet, dest, dec_amt
        )

    if success and tx_sig:
        exp = get_explorer_url(c, tx_sig)
        text = (
            f"## ✅ Withdrawal Successful!\n\n"
            f"• **Coin:** `{c}`\n"
            f"• **Amount:** `{dec_amt} {c}`\n"
            f"• **Destination:** `{dest}`\n\n"
            f"🔗 **[View Transaction on Explorer]({exp})**"
        )
        await send_v2(interaction, text, color=ACCENT_OK, ephemeral=True)
    else:
        await send_v2(interaction, f"## ❌ Withdrawal Failed\n\n{err}", color=ACCENT_ERR, ephemeral=True)


# ---------------------------------------------------------------------------
# Server Settings & Ticket Slash Commands
# ---------------------------------------------------------------------------

@bot.tree.command(name="send_ticket", description="Post the ticket panel in a channel. Administrator only.")
@app_commands.default_permissions(administrator=True)
@app_commands.guild_only()
async def send_ticket(interaction: discord.Interaction) -> None:
    if not is_administrator(interaction):
        await send_permission_denied(interaction)
        return

    server_name = guild_display_name(interaction)
    text = (
        f"# {EMOJI_THUNDER} **{server_name} EXCHANGE & SUPPORT TICKETS**\n\n"
        f"Need help or want to perform an exchange privately with support?\n"
        f"Click the button below to open a private ticket.\n\n"
        f"> {EMOJI_DOT} **Automated C2C:** LTC ↔ SOL\n"
        f"> {EMOJI_DOT} **Minimum Exchange:** `$0.01 USD`\n"
        f"> {EMOJI_DOT} **Support:** Staff assistance available 24/7"
    )
    row = discord.ui.ActionRow()
    row.add_item(TicketOpenExchangeButton())
    view = discord.ui.LayoutView(timeout=None)
    view.add_item(
        discord.ui.Container(
            discord.ui.TextDisplay(text),
            discord.ui.Separator(visible=True, spacing=discord.SeparatorSpacing.small),
            row,
            accent_color=ACCENT_GOLD,
        )
    )
    await interaction.channel.send(view=view)
    await send_v2(interaction, "## ✅ Ticket Panel Posted", color=ACCENT_OK, ephemeral=True)


@bot.tree.command(name="tixstaff", description="Set the staff role for tickets. Administrator only.")
@app_commands.describe(role="Staff role")
@app_commands.default_permissions(administrator=True)
@app_commands.guild_only()
async def tixstaff(interaction: discord.Interaction, role: discord.Role) -> None:
    if not is_administrator(interaction):
        await send_permission_denied(interaction)
        return
    await update_settings(staff_role_id=role.id)
    await send_v2(interaction, f"## ✅ Staff Role Updated\n\nTickets will notify **{role.name}**.", color=ACCENT_OK)


@bot.tree.command(name="tixcatogery", description="Set the category for new tickets. Administrator only.")
@app_commands.describe(category="Category channel")
@app_commands.default_permissions(administrator=True)
@app_commands.guild_only()
async def tixcategory(interaction: discord.Interaction, category: discord.CategoryChannel) -> None:
    if not is_administrator(interaction):
        await send_permission_denied(interaction)
        return
    await update_settings(ticket_category_id=category.id)
    await send_v2(interaction, f"## ✅ Ticket Category Updated\n\nTickets will open under **{category.name}**.", color=ACCENT_OK)


# ---------------------------------------------------------------------------
# Giveaways
# ---------------------------------------------------------------------------

@bot.tree.command(name="gstart", description="Start a giveaway. Administrator only.")
@app_commands.describe(
    time="Duration such as 10s, 5m, 1d, 1w",
    winners="How many winners",
    item="Prize name",
)
@app_commands.default_permissions(administrator=True)
@app_commands.guild_only()
async def gstart(interaction: discord.Interaction, time: str, winners: int, item: str) -> None:
    if not is_administrator(interaction):
        await send_permission_denied(interaction)
        return
    if not isinstance(interaction.channel, discord.TextChannel):
        await send_v2(interaction, "## ❌ Run this in a text channel.", color=ACCENT_ERR, ephemeral=True)
        return
    try:
        seconds, _label = parse_duration(time)
    except ValueError:
        await send_v2(interaction, "## ❌ Use a duration like `10s`, `5m`, `1d`, or `1w`.", color=ACCENT_ERR, ephemeral=True)
        return
    if winners < 1:
        await send_v2(interaction, "## ❌ Winners must be at least 1.", color=ACCENT_ERR, ephemeral=True)
        return

    prize = item.strip()
    end_ts = int(time_module_now() + seconds)
    text = giveaway_panel_text(prize, winners, end_ts, interaction.user)
    await interaction.response.send_message(view=GiveawayPanel(text))
    message = await interaction.original_response()
    try:
        await message.add_reaction(PARTIAL_FALCON or "🎁")
    except Exception as exc:
        log.warning("Could not add giveaway reaction: %s", exc)
    await add_giveaway(
        {
            "message_id": message.id,
            "channel_id": message.channel.id,
            "guild_id": interaction.guild_id,
            "item": prize,
            "winners": winners,
            "end_ts": end_ts,
            "host_id": interaction.user.id,
            "ended": False,
            "entries": [],
        }
    )


def time_module_now() -> int:
    return int(time.time())


# ---------------------------------------------------------------------------
# Moderation Commands Suite (Preserved and Enhanced)
# ---------------------------------------------------------------------------

def _can_moderate(actor: discord.Member, target: discord.Member, bot_member: discord.Member) -> Optional[str]:
    if actor.id == target.id:
        return "You cannot moderate yourself."
    if target.id == actor.guild.owner_id:
        return "You cannot moderate the server owner."
    if actor.id != actor.guild.owner_id and actor.top_role <= target.top_role:
        return "That member has an equal or higher role than you."
    if bot_member.top_role <= target.top_role:
        return "My role is not high enough to moderate that member."
    return None


@bot.tree.command(name="kick", description="Kick a member. Requires Kick Members.")
@app_commands.describe(user="Member to kick", reason="Reason")
@app_commands.checks.has_permissions(kick_members=True)
@app_commands.guild_only()
async def slash_kick(interaction: discord.Interaction, user: discord.Member, reason: str | None = None) -> None:
    if interaction.guild is None or not isinstance(interaction.user, discord.Member):
        return
    problem = _can_moderate(interaction.user, user, interaction.guild.me)
    if problem:
        await send_v2(interaction, f"## ❌ Cannot Kick\n\n{problem}", color=ACCENT_ERR, ephemeral=True)
        return
    why = reason or "No reason provided"
    await user.kick(reason=f"{why} | by {interaction.user}")
    await send_v2(
        interaction,
        f"{EMOJI_DOT} **Successfully Kicked:** `{user}`\n"
        f"{EMOJI_DOT} **Kicked By:** `{interaction.user}`\n"
        f"{EMOJI_DOT} **Reason:** `{why}`",
    )


@bot.tree.command(name="ban", description="Ban a member. Requires Ban Members.")
@app_commands.describe(user="Member to ban", reason="Reason")
@app_commands.checks.has_permissions(ban_members=True)
@app_commands.guild_only()
async def slash_ban(interaction: discord.Interaction, user: discord.Member, reason: str | None = None) -> None:
    if interaction.guild is None or not isinstance(interaction.user, discord.Member):
        return
    problem = _can_moderate(interaction.user, user, interaction.guild.me)
    if problem:
        await send_v2(interaction, f"## ❌ Cannot Ban\n\n{problem}", color=ACCENT_ERR, ephemeral=True)
        return
    why = reason or "No reason provided"
    await user.ban(reason=f"{why} | by {interaction.user}", delete_message_days=0)
    await send_v2(
        interaction,
        f"{EMOJI_DOT} **Successfully Banned:** `{user}`\n"
        f"{EMOJI_DOT} **Banned By:** `{interaction.user}`\n"
        f"{EMOJI_DOT} **Reason:** `{why}`",
    )


@bot.tree.command(name="unban", description="Unban a user. Requires Ban Members.")
@app_commands.describe(user="User to unban")
@app_commands.checks.has_permissions(ban_members=True)
@app_commands.guild_only()
async def slash_unban(interaction: discord.Interaction, user: discord.User) -> None:
    if interaction.guild is None:
        return
    try:
        await interaction.guild.unban(user, reason=f"Unbanned by {interaction.user}")
        await send_v2(interaction, f"{EMOJI_DOT} **Successfully Unbanned:** `{user}`\n{EMOJI_DOT} **By:** `{interaction.user}`")
    except discord.NotFound:
        await send_v2(interaction, "## ❌ That user is not banned.", color=ACCENT_ERR, ephemeral=True)


@bot.tree.command(name="mute", description="Timeout a member. Requires Moderate Members.")
@app_commands.describe(user="Member to mute", duration="Duration (e.g. 10m, 1h, 1d)", reason="Reason")
@app_commands.checks.has_permissions(moderate_members=True)
@app_commands.guild_only()
async def slash_mute(interaction: discord.Interaction, user: discord.Member, duration: str, reason: str | None = None) -> None:
    if interaction.guild is None or not isinstance(interaction.user, discord.Member):
        return
    problem = _can_moderate(interaction.user, user, interaction.guild.me)
    if problem:
        await send_v2(interaction, f"## ❌ Cannot Mute\n\n{problem}", color=ACCENT_ERR, ephemeral=True)
        return
    try:
        seconds, label = parse_duration(duration)
    except ValueError:
        await send_v2(interaction, "## ❌ Use duration like `10s`, `5m`, `1d`, or `1w`.", color=ACCENT_ERR, ephemeral=True)
        return
    why = reason or "No reason provided"
    await user.timeout(timedelta(seconds=min(seconds, 28 * 86400)), reason=f"{why} | by {interaction.user}")
    await send_v2(
        interaction,
        f"{EMOJI_DOT} **Successfully Muted:** `{user}`\n"
        f"{EMOJI_DOT} **Duration:** `{label}`\n"
        f"{EMOJI_DOT} **Reason:** `{why}`",
    )


@bot.tree.command(name="lock", description="Lock a channel. Requires Manage Channels.")
@app_commands.describe(channel="Channel to lock")
@app_commands.checks.has_permissions(manage_channels=True)
@app_commands.guild_only()
async def slash_lock(interaction: discord.Interaction, channel: discord.TextChannel) -> None:
    overwrite = channel.overwrites_for(channel.guild.default_role)
    overwrite.send_messages = False
    await channel.set_permissions(channel.guild.default_role, overwrite=overwrite)
    await send_v2(interaction, f"{EMOJI_DOT} **Successfully Locked:** {channel.mention}\n{EMOJI_DOT} **By:** {interaction.user.mention}")


@bot.tree.command(name="unlock", description="Unlock a channel. Requires Manage Channels.")
@app_commands.describe(channel="Channel to unlock")
@app_commands.checks.has_permissions(manage_channels=True)
@app_commands.guild_only()
async def slash_unlock(interaction: discord.Interaction, channel: discord.TextChannel) -> None:
    overwrite = channel.overwrites_for(channel.guild.default_role)
    overwrite.send_messages = True
    await channel.set_permissions(channel.guild.default_role, overwrite=overwrite)
    await send_v2(interaction, f"{EMOJI_DOT} **Successfully Unlocked:** {channel.mention}\n{EMOJI_DOT} **By:** {interaction.user.mention}")


# Prefix moderation commands
@bot.command(name="kick")
@commands.has_permissions(kick_members=True)
@commands.guild_only()
async def prefix_kick(ctx: commands.Context, member: discord.Member, *, reason: str | None = None) -> None:
    problem = _can_moderate(ctx.author, member, ctx.guild.me)
    if problem:
        await ctx.send(view=NoticeView(f"## ❌ Cannot Kick\n\n{problem}", color=ACCENT_ERR))
        return
    why = reason or "No reason provided"
    await member.kick(reason=f"{why} | by {ctx.author}")
    await ctx.send(view=NoticeView(f"✅ **Kicked:** `{member}` | **Reason:** `{why}`", color=ACCENT_OK))


@bot.command(name="ban")
@commands.has_permissions(ban_members=True)
@commands.guild_only()
async def prefix_ban(ctx: commands.Context, member: discord.Member, *, reason: str | None = None) -> None:
    problem = _can_moderate(ctx.author, member, ctx.guild.me)
    if problem:
        await ctx.send(view=NoticeView(f"## ❌ Cannot Ban\n\n{problem}", color=ACCENT_ERR))
        return
    why = reason or "No reason provided"
    await member.ban(reason=f"{why} | by {ctx.author}", delete_message_days=0)
    await ctx.send(view=NoticeView(f"✅ **Banned:** `{member}` | **Reason:** `{why}`", color=ACCENT_OK))


@bot.command(name="mute")
@commands.has_permissions(moderate_members=True)
@commands.guild_only()
async def prefix_mute(ctx: commands.Context, member: discord.Member, duration: str, *, reason: str | None = None) -> None:
    problem = _can_moderate(ctx.author, member, ctx.guild.me)
    if problem:
        await ctx.send(view=NoticeView(f"## ❌ Cannot Mute\n\n{problem}", color=ACCENT_ERR))
        return
    try:
        seconds, label = parse_duration(duration)
    except ValueError:
        await ctx.send(view=NoticeView("## ❌ Invalid duration format (`10s`, `5m`, `1d`).", color=ACCENT_ERR))
        return
    why = reason or "No reason provided"
    await member.timeout(timedelta(seconds=min(seconds, 28 * 86400)), reason=f"{why} | by {ctx.author}")
    await ctx.send(view=NoticeView(f"✅ **Muted:** `{member}` for `{label}` | **Reason:** `{why}`", color=ACCENT_OK))


# Prefix setting
set_group = app_commands.Group(
    name="set",
    description="Bot settings",
    default_permissions=discord.Permissions(administrator=True),
    guild_only=True,
)


@set_group.command(name="prefix", description="Change the bot text-command prefix. Administrator only.")
@app_commands.describe(new_prefix="New prefix, for example . or ! or ?")
async def set_prefix(interaction: discord.Interaction, new_prefix: str) -> None:
    if not is_administrator(interaction):
        await send_permission_denied(interaction)
        return

    prefix = new_prefix.strip()
    if not prefix or len(prefix) > 5 or any(ch.isspace() for ch in prefix):
        await send_v2(interaction, "## ❌ Prefix must be 1 to 5 characters with no spaces.", color=ACCENT_ERR, ephemeral=True)
        return

    await update_settings(prefix=prefix)
    await send_v2(interaction, f"## ✅ Prefix Updated\n\nNew prefix: `{prefix}`\nExample: `{prefix}rates`", color=ACCENT_OK)


bot.tree.add_command(set_group)


# ---------------------------------------------------------------------------
# Help Menu
# ---------------------------------------------------------------------------

@bot.tree.command(name="help", description="Show the automated exchange help menu.")
async def slash_help(interaction: discord.Interaction) -> None:
    text = (
        f"## {EMOJI_THUNDER} **Automated C2C Exchange Bot Help**\n\n"
        f"### 🔄 **Exchange Commands**\n"
        f"• `/c2c_calc [from] [to] [amount]` — Live swap rate calculation\n"
        f"• `/status [swap_id]` — Check on-chain confirmation & payout status\n"
        f"• `.rates` — Current LTC and SOL USD prices\n"
        f"• `.ltc2sol [amount]` — Quick calculate LTC to SOL\n"
        f"• `.sol2ltc [amount]` — Quick calculate SOL to LTC\n\n"
        f"### 🛡️ **Moderation Commands**\n"
        f"• `/kick` `/ban` `/unban` `/mute` `/lock` `/unlock`\n\n"
        f"### ⚙️ **Administrator Commands**\n"
        f"• `/send_exchange_panel` — Post public interactive exchange panel\n"
        f"• `/send_ticket` `/tixstaff` `/tixcatogery` — Tickets setup\n"
        f"• `/exchange_stats` — Volume, fees, and swap counts\n"
        f"• `/wallet_balance` — Hot wallet liquidity balances\n"
        f"• `/set_fee` — Set exchange fee percentage\n"
        f"• `/set_min` — Set minimum exchange USD (default $0.01)\n"
        f"• `/withdraw_hotwallet` — Transfer funds to cold storage\n"
        f"• `/gstart` — Launch giveaways"
    )
    await send_v2(interaction, text, color=ACCENT_GOLD)


@bot.command(name="help")
async def prefix_help(ctx: commands.Context) -> None:
    prefix = load_settings_sync().get("prefix") or "."
    text = (
        f"## {EMOJI_THUNDER} **Automated C2C Exchange Bot**\n\n"
        f"**Prefix:** `{prefix}`\n\n"
        f"• `{prefix}rates` — Live crypto rates\n"
        f"• `{prefix}ltc2sol <amount>` — Convert LTC to SOL\n"
        f"• `{prefix}sol2ltc <amount>` — Convert SOL to LTC\n"
        f"• `{prefix}c2c <amount> <from> <to>` — General calculator\n"
        f"• `{prefix}status <swap_id>` — Track swap status\n"
        f"• `{prefix}ping` — Bot latency\n"
        f"• Moderation: `{prefix}kick`, `{prefix}ban`, `{prefix}mute`, `{prefix}lock`"
    )
    await ctx.send(view=NoticeView(text, color=ACCENT_GOLD))


# ---------------------------------------------------------------------------
# Error Handlers
# ---------------------------------------------------------------------------

@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError) -> None:
    if isinstance(error, (app_commands.MissingPermissions, app_commands.CheckFailure)):
        await send_permission_denied(interaction)
        return
    log.exception("Slash command error: %s", error)
    try:
        await send_v2(interaction, "## ❌ An unexpected error occurred. Please try again.", color=ACCENT_ERR, ephemeral=True)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Main Entry Point
# ---------------------------------------------------------------------------

def main() -> None:
    log.info("Starting Automated C2C Exchange Bot...")
    bot.run(DISCORD_TOKEN)


if __name__ == "__main__":
    main()
