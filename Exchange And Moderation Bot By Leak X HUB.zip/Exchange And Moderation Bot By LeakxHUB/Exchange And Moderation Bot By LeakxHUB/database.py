"""
Database Layer for C2C Exchange
===============================
High-concurrency SQLite database with Write-Ahead Logging (WAL) and ACID transactions.
Built to comfortably handle tens of thousands of daily swaps and concurrent Discord interactions.
"""

from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import time
from pathlib import Path
from typing import Any, Optional

log = logging.getLogger("exchange.db")

DB_PATH = Path(__file__).resolve().parent / "exchange.db"
_db_lock = asyncio.Lock()


def get_db_connection() -> sqlite3.Connection:
    """Create a connection configured with WAL mode and row factory."""
    conn = sqlite3.connect(
        str(DB_PATH),
        timeout=20.0,
        isolation_level=None,  # autocommit mode, explicit transactions when needed
    )
    conn.row_factory = sqlite3.Row
    # Configure high-concurrency pragmas
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.execute("PRAGMA busy_timeout = 20000;")
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db() -> None:
    """Initialize SQLite database schema and indices."""
    conn = get_db_connection()
    try:
        with conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS swaps (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    swap_id TEXT UNIQUE NOT NULL,
                    user_id INTEGER NOT NULL,
                    guild_id INTEGER NOT NULL,
                    channel_id INTEGER,
                    message_id INTEGER,
                    from_coin TEXT NOT NULL,
                    to_coin TEXT NOT NULL,
                    expected_deposit_amount REAL NOT NULL,
                    expected_payout_amount REAL NOT NULL,
                    usd_value REAL NOT NULL,
                    exchange_rate REAL NOT NULL,
                    fee_percent REAL NOT NULL,
                    fee_amount_usd REAL NOT NULL,
                    network_fee_crypto REAL NOT NULL,
                    deposit_address TEXT NOT NULL,
                    deposit_private_key TEXT,
                    user_payout_address TEXT NOT NULL,
                    status TEXT NOT NULL,
                    deposit_tx_hash TEXT,
                    deposit_amount_received REAL DEFAULT 0.0,
                    payout_tx_hash TEXT,
                    confirmations INTEGER DEFAULT 0,
                    required_confirmations INTEGER DEFAULT 1,
                    notes TEXT,
                    created_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL,
                    expires_at INTEGER NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_swaps_status ON swaps(status);
                CREATE INDEX IF NOT EXISTS idx_swaps_deposit_addr ON swaps(deposit_address);
                CREATE INDEX IF NOT EXISTS idx_swaps_user_id ON swaps(user_id);
                CREATE INDEX IF NOT EXISTS idx_swaps_created_at ON swaps(created_at);

                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS stats (
                    key TEXT PRIMARY KEY,
                    value REAL DEFAULT 0.0
                );
                """
            )
            # Seed default stats if not present
            conn.execute("INSERT OR IGNORE INTO stats (key, value) VALUES ('total_volume_usd', 0.0);")
            conn.execute("INSERT OR IGNORE INTO stats (key, value) VALUES ('total_swaps_completed', 0.0);")
            conn.execute("INSERT OR IGNORE INTO stats (key, value) VALUES ('total_fees_usd', 0.0);")
        log.info("Database initialized successfully at %s", DB_PATH)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Swaps CRUD Operations (Async safe via asyncio.to_thread)
# ---------------------------------------------------------------------------

def _row_to_dict(row: Optional[sqlite3.Row]) -> Optional[dict[str, Any]]:
    return dict(row) if row is not None else None


def _create_swap_sync(data: dict[str, Any]) -> dict[str, Any]:
    conn = get_db_connection()
    try:
        now = int(time.time())
        expires_at = now + int(data.get("timeout_seconds", 1800))  # 30 min default
        with conn:
            conn.execute(
                """
                INSERT INTO swaps (
                    swap_id, user_id, guild_id, channel_id, message_id,
                    from_coin, to_coin, expected_deposit_amount, expected_payout_amount,
                    usd_value, exchange_rate, fee_percent, fee_amount_usd, network_fee_crypto,
                    deposit_address, deposit_private_key, user_payout_address, status,
                    deposit_tx_hash, deposit_amount_received, payout_tx_hash,
                    confirmations, required_confirmations, notes,
                    created_at, updated_at, expires_at
                ) VALUES (
                    :swap_id, :user_id, :guild_id, :channel_id, :message_id,
                    :from_coin, :to_coin, :expected_deposit_amount, :expected_payout_amount,
                    :usd_value, :exchange_rate, :fee_percent, :fee_amount_usd, :network_fee_crypto,
                    :deposit_address, :deposit_private_key, :user_payout_address, :status,
                    :deposit_tx_hash, :deposit_amount_received, :payout_tx_hash,
                    :confirmations, :required_confirmations, :notes,
                    :created_at, :updated_at, :expires_at
                )
                """,
                {
                    "swap_id": data["swap_id"],
                    "user_id": data["user_id"],
                    "guild_id": data.get("guild_id", 0),
                    "channel_id": data.get("channel_id"),
                    "message_id": data.get("message_id"),
                    "from_coin": data["from_coin"].upper(),
                    "to_coin": data["to_coin"].upper(),
                    "expected_deposit_amount": float(data["expected_deposit_amount"]),
                    "expected_payout_amount": float(data["expected_payout_amount"]),
                    "usd_value": float(data.get("usd_value", 0.0)),
                    "exchange_rate": float(data.get("exchange_rate", 1.0)),
                    "fee_percent": float(data.get("fee_percent", 1.0)),
                    "fee_amount_usd": float(data.get("fee_amount_usd", 0.0)),
                    "network_fee_crypto": float(data.get("network_fee_crypto", 0.0)),
                    "deposit_address": data["deposit_address"],
                    "deposit_private_key": data.get("deposit_private_key"),
                    "user_payout_address": data["user_payout_address"],
                    "status": data.get("status", "PENDING_DEPOSIT"),
                    "deposit_tx_hash": data.get("deposit_tx_hash"),
                    "deposit_amount_received": float(data.get("deposit_amount_received", 0.0)),
                    "payout_tx_hash": data.get("payout_tx_hash"),
                    "confirmations": int(data.get("confirmations", 0)),
                    "required_confirmations": int(data.get("required_confirmations", 1)),
                    "notes": data.get("notes"),
                    "created_at": now,
                    "updated_at": now,
                    "expires_at": expires_at,
                },
            )
        cur = conn.execute("SELECT * FROM swaps WHERE swap_id = ?", (data["swap_id"],))
        return dict(cur.fetchone())
    finally:
        conn.close()


async def create_swap(data: dict[str, Any]) -> dict[str, Any]:
    return await asyncio.to_thread(_create_swap_sync, data)


def _get_swap_sync(swap_id: str) -> Optional[dict[str, Any]]:
    conn = get_db_connection()
    try:
        cur = conn.execute("SELECT * FROM swaps WHERE swap_id = ? COLLATE NOCASE", (swap_id.strip(),))
        return _row_to_dict(cur.fetchone())
    finally:
        conn.close()


async def get_swap(swap_id: str) -> Optional[dict[str, Any]]:
    return await asyncio.to_thread(_get_swap_sync, swap_id)


def _get_swap_by_deposit_sync(address: str) -> Optional[dict[str, Any]]:
    conn = get_db_connection()
    try:
        cur = conn.execute("SELECT * FROM swaps WHERE deposit_address = ?", (address.strip(),))
        return _row_to_dict(cur.fetchone())
    finally:
        conn.close()


async def get_swap_by_deposit_address(address: str) -> Optional[dict[str, Any]]:
    return await asyncio.to_thread(_get_swap_by_deposit_sync, address)


def _get_active_swaps_sync() -> list[dict[str, Any]]:
    conn = get_db_connection()
    try:
        cur = conn.execute(
            """
            SELECT * FROM swaps
            WHERE status IN ('PENDING_DEPOSIT', 'DEPOSIT_DETECTED', 'CONFIRMING', 'PROCESSING_PAYOUT')
            ORDER BY created_at ASC
            """
        )
        return [dict(r) for r in cur.fetchall()]
    finally:
        conn.close()


async def get_active_swaps() -> list[dict[str, Any]]:
    return await asyncio.to_thread(_get_active_swaps_sync)


def _update_swap_sync(swap_id: str, **kwargs: Any) -> Optional[dict[str, Any]]:
    conn = get_db_connection()
    try:
        if not kwargs:
            cur = conn.execute("SELECT * FROM swaps WHERE swap_id = ?", (swap_id,))
            return _row_to_dict(cur.fetchone())

        now = int(time.time())
        kwargs["updated_at"] = now

        set_clauses = [f"{k} = :{k}" for k in kwargs.keys()]
        query = f"UPDATE swaps SET {', '.join(set_clauses)} WHERE swap_id = :swap_id"
        params = dict(kwargs)
        params["swap_id"] = swap_id

        with conn:
            conn.execute(query, params)

            # If marked completed, update aggregate statistics
            if kwargs.get("status") == "COMPLETED":
                cur_swap = conn.execute("SELECT usd_value, fee_amount_usd FROM swaps WHERE swap_id = ?", (swap_id,)).fetchone()
                if cur_swap:
                    usd_val = float(cur_swap["usd_value"] or 0.0)
                    fee_val = float(cur_swap["fee_amount_usd"] or 0.0)
                    conn.execute("UPDATE stats SET value = value + ? WHERE key = 'total_volume_usd'", (usd_val,))
                    conn.execute("UPDATE stats SET value = value + 1 WHERE key = 'total_swaps_completed'")
                    conn.execute("UPDATE stats SET value = value + ? WHERE key = 'total_fees_usd'", (fee_val,))

        cur = conn.execute("SELECT * FROM swaps WHERE swap_id = ?", (swap_id,))
        return _row_to_dict(cur.fetchone())
    finally:
        conn.close()


async def update_swap(swap_id: str, **kwargs: Any) -> Optional[dict[str, Any]]:
    return await asyncio.to_thread(_update_swap_sync, swap_id, **kwargs)


def _get_user_swaps_sync(user_id: int, limit: int = 10) -> list[dict[str, Any]]:
    conn = get_db_connection()
    try:
        cur = conn.execute(
            "SELECT * FROM swaps WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
            (user_id, limit),
        )
        return [dict(r) for r in cur.fetchall()]
    finally:
        conn.close()


async def get_user_swaps(user_id: int, limit: int = 10) -> list[dict[str, Any]]:
    return await asyncio.to_thread(_get_user_swaps_sync, user_id, limit)


# ---------------------------------------------------------------------------
# Statistics and Settings
# ---------------------------------------------------------------------------

def _get_stats_sync() -> dict[str, float]:
    conn = get_db_connection()
    try:
        cur = conn.execute("SELECT key, value FROM stats")
        stats_map = {row["key"]: float(row["value"]) for row in cur.fetchall()}
        # Also query active count
        cur_active = conn.execute(
            "SELECT count(*) as count FROM swaps WHERE status IN ('PENDING_DEPOSIT', 'DEPOSIT_DETECTED', 'CONFIRMING', 'PROCESSING_PAYOUT')"
        )
        stats_map["active_swaps"] = cur_active.fetchone()["count"]
        return stats_map
    finally:
        conn.close()


async def get_stats() -> dict[str, float]:
    return await asyncio.to_thread(_get_stats_sync)


def _get_setting_sync(key: str, default: Any = None) -> Any:
    conn = get_db_connection()
    try:
        cur = conn.execute("SELECT value FROM settings WHERE key = ?", (key,))
        row = cur.fetchone()
        if row is None:
            return default
        try:
            return json.loads(row["value"])
        except Exception:
            return row["value"]
    finally:
        conn.close()


async def get_setting(key: str, default: Any = None) -> Any:
    return await asyncio.to_thread(_get_setting_sync, key, default)


def _set_setting_sync(key: str, value: Any) -> None:
    conn = get_db_connection()
    try:
        val_str = json.dumps(value) if not isinstance(value, str) else value
        with conn:
            conn.execute(
                "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (key, val_str),
            )
    finally:
        conn.close()


async def set_setting(key: str, value: Any) -> None:
    await asyncio.to_thread(_set_setting_sync, key, value)
