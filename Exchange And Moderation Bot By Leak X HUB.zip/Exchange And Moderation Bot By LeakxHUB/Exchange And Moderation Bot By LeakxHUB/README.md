# ⚡ Automated C2C Crypto Exchange Bot (LTC ↔ SOL)

High-performance, automated Crypto-to-Crypto (C2C) Discord exchange bot for **Litecoin (LTC)** and **Solana (SOL)**. Built to handle **10,000+ users** and **thousands of daily exchanges** safely without manual staff intervention.

---

## 🌟 Key Features

1. **Fully Automated Exchanges (LTC ➔ SOL & SOL ➔ LTC)**:
   - User inputs the amount and their receiving address.
   - The bot generates a **unique, dedicated deposit address** for every single swap order (100% collision-free, anti-double-spend).
   - An asynchronous background monitor tracks blockchain deposits.
   - Once confirmed on-chain, the bot **automatically signs and broadcasts the payout** to the user's destination wallet.
   - Payout transaction link (Solscan / LitecoinSpace) is automatically sent to the user.

2. **$0.01 Minimum Exchange**:
   - Swaps as low as **$0.01 USD** equivalent in LTC or SOL are supported.
   - Transparent network miner fee calculation ensures exact net payouts without bot losses.

3. **High-Scale & Concurrency Architecture**:
   - **SQLite with WAL Mode** (`journal_mode=WAL`, `synchronous=NORMAL`, `busy_timeout=20000`): Non-blocking concurrent reads and ACID writes that comfortably scale to tens of thousands of daily swaps without database locking or file corruption.
   - **Idempotent Payout Locks**: In-memory and database status locks guarantee that no swap can ever be paid out twice, even under heavy network load or rapid retries.

4. **Multi-Source Real-Time Price Oracle**:
   - Queries **Binance**, **CoinGecko**, and **Coinbase** public APIs with automatic failover.
   - Smart 30-second TTL in-memory caching ensures live rates without ever hitting API rate limits.

5. **Discord Components V2 Modern UI**:
   - Interactive Public Exchange Panel (`/send_exchange_panel`) with live rates, swap buttons, calculator, and support ticket creation.
   - Ephemeral Live Swap Tracker with QR code links, 1-tap address copy, live status badges (`Awaiting Deposit` ➔ `Deposit Detected` ➔ `Confirming` ➔ `Completed`), and instant status refresh.

6. **Comprehensive Server Suite**:
   - Moderation: `/kick`, `/ban`, `/unban`, `/mute`, `/lock`, `/unlock`, `/hide`, `/unhide` (slash & prefix).
   - Giveaways: `/gstart` with interactive reaction tracking.
   - Admin Controls: `/exchange_stats`, `/wallet_balance`, `/set_fee`, `/set_min`, `/withdraw_hotwallet`.

---

## 📁 Project Architecture

```
├── main.py              # Discord bot entry point, UI views, modals, slash & prefix commands
├── exchange_manager.py  # Swap lifecycle engine, background blockchain monitor & auto-payout
├── blockchain.py        # Solana RPC client & Litecoin block explorer client
├── price_oracle.py      # Real-time price feeds (Binance / CoinGecko) & quote calculator
├── crypto_utils.py      # Zero-dependency Base58, Bech32, Ed25519 & secp256k1 key generation
├── database.py          # SQLite WAL database layer with ACID transactions & indexing
├── config.json          # Discord tokens, RPC URLs, hot wallet private keys, fee %
├── emojis.json          # Custom emoji mappings
├── requirements.txt     # Python dependencies
└── exchange.db          # Auto-created SQLite database file
```

---

## 🚀 Setup & Installation

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure `config.json`
Open `config.json` and configure your settings:
```json
{
    "token": "YOUR_DISCORD_BOT_TOKEN",
    "guild_id": 123456789012345678,
    "fee_percent": 1.0,
    "min_exchange_usd": 0.01,
    "solana_rpc_urls": [
        "https://api.mainnet-beta.solana.com",
        "https://solana-mainnet.rpc.extrnode.com"
    ],
    "solana_hotwallet_private_key": "YOUR_SOLANA_BASE58_PRIVATE_KEY",
    "litecoin_hotwallet_private_key": "YOUR_LTC_WIF_PRIVATE_KEY",
    "litecoin_rpc_url": ""
}
```

> **Note on Hot Wallets:**
> - If you leave `solana_hotwallet_private_key` or `litecoin_hotwallet_private_key` empty, the bot will automatically generate temporary test keypairs on startup and display their addresses in the console.
> - For production, export your Solana hot wallet private key (from Phantom / Solflare as Base58 string) and your Litecoin hot wallet private key (WIF format from Electrum / Core) and paste them into `config.json`.
> - Keep sufficient liquidity in both hot wallets so automated payouts execute immediately.

### 3. Run the Bot
```bash
python main.py
```

---

## 🛠️ Commands Reference

### 🔄 Exchange & Calculator Commands
| Command | Type | Description |
|---|---|---|
| `/c2c_calc [from] [to] [amount]` | Slash | Calculate live exchange quote and net payout |
| `/status [swap_id]` | Slash | View real-time blockchain confirmation & payout status |
| `.rates` | Prefix | Display current LTC & SOL prices in USD |
| `.ltc2sol [amount]` | Prefix | Convert LTC to SOL with current rates |
| `.sol2ltc [amount]` | Prefix | Convert SOL to LTC with current rates |
| `.c2c [amount] [from] [to]` | Prefix | General rate calculation |
| `.status [swap_id]` | Prefix | Check status of any swap ID |

### ⚙️ Administrator Commands
| Command | Permission | Description |
|---|---|---|
| `/send_exchange_panel` | Administrator | Post the interactive public C2C swap panel |
| `/exchange_stats` | Administrator | View total volume ($USD), total swaps, and revenue |
| `/wallet_balance` | Administrator | Check live on-chain balances of LTC & SOL hot wallets |
| `/set_fee [percentage]` | Administrator | Configure swap fee percentage (e.g. `1.5`) |
| `/set_min [usd_amount]` | Administrator | Set minimum exchange amount (e.g. `0.01`) |
| `/withdraw_hotwallet [coin] [amount] [address]` | Administrator | Safely transfer funds from hot wallet to cold storage |
| `/send_ticket` | Administrator | Post the support & exchange ticket panel |
| `/tixstaff [role]` | Administrator | Set the ticket staff role |
| `/tixcatogery [category]` | Administrator | Set ticket category channel |
| `/gstart [time] [winners] [item]` | Administrator | Launch an interactive giveaway |
| `/set prefix [prefix]` | Administrator | Change text command prefix |

### 🛡️ Moderation Commands
| Command | Permission | Description |
|---|---|---|
| `/kick [user] [reason]` | Kick Members | Kick a member from the server |
| `/ban [user] [reason]` | Ban Members | Ban a member from the server |
| `/unban [user]` | Ban Members | Unban a user |
| `/mute [user] [duration] [reason]` | Moderate Members | Timeout a member (e.g. `10m`, `1d`) |
| `/lock [channel]` | Manage Channels | Lock a channel |
| `/unlock [channel]` | Manage Channels | Unlock a channel |

---

## 🔒 Security & Reliability for 10k+ Users

1. **Collision-Free Deposit Addresses**:
   Every swap generates an ephemeral keypair dedicated strictly to that swap. No two users ever deposit to the same address, completely preventing race conditions or attribution bugs.
2. **Double-Spend & Confirmation Verification**:
   - Solana swaps require `confirmed` / `finalized` commitment.
   - Litecoin swaps require mempool verification and on-chain confirmation checks.
   - Every transaction hash is stored with a `UNIQUE` database constraint.
3. **Liquidity Protection**:
   If a hot wallet runs low on funds, the swap status changes to `PROCESSING_PAYOUT` with a note and alerts the admin, automatically executing the payout the moment the wallet is replenished.
