==========================================================
                    L E A K   X   H U B
==========================================================

This Tool By Vault x Hub
CREATOR: Frosty


----------------------------------------------------------
HOW TO RUN
----------------------------------------------------------

Easiest way:
  Just double click setup_and_run.bat

That's it. It will do everything:
  - check if python is installed
  - upgrade pip
  - install all requirements
  - launch main.py

If the bat file doesn't work for some reason, do it manually:

  1. open cmd in this folder
  2. pip install -r requirements.txt
  3. python main.py


----------------------------------------------------------
TOKENS SETUP
----------------------------------------------------------

Put your tokens in:

  Setup/tokens.txt

One token per line. Nothing else.

Format:

  MTA1NzI4...xyz
  MTIzNDU2...abc
  OTg3NjU0...def

That's the only file you need to touch for tokens.


----------------------------------------------------------
BOT CONFIG
----------------------------------------------------------

Open:

  Bot/config.yml

Fill these:

  bot_token       - your bot token
  client_id       - your app client id
  client_secret   - your app client secret
  redirect_uri    - http://localhost:8080

Save it. Done.

If you don't have config.yml, running main.py once will
make a config.json instead. Same fields, fill those.


----------------------------------------------------------
HOW TO GET NITRO TRIAL
----------------------------------------------------------

Follow this order exactly:

  1. Do 2FA ON
  2. Then do 2FA OFF
  3. Then run CHAT

That's the method. Simple.

In the menu:

  [1] = 2FA Enable
  [2] = 2FA Disable
  [3] = Join Server & Auto Chat

So:
  - pick [1] first
  - then pick [2]
  - then pick [3], give invite link + channel id
  - chat starts, nitro trial comes


----------------------------------------------------------
FILE FORMATS
----------------------------------------------------------

Setup/tokens.txt
  one token per line
  MTA1NzI4...xyz

input/2fa.txt
  one token per line
  made automatically after 2FA enable

input/final.txt
  one token per line
  made automatically after 2FA disable

input/trial.txt
  format: TOKEN | USERNAME | STATUS | TIMESTAMP
  MTA1NzI4...xyz | Frosty | vc_active | 2024-01-15 12:34:56

Leak X Hub/tokens.txt
  auto copied from Setup/tokens.txt every run
  don't edit this by hand, it gets overwritten


----------------------------------------------------------
MENU OPTIONS
----------------------------------------------------------

  [1]  2FA Enable
  [2]  2FA Disable
  [3]  Join Server & Auto Chat
  [0]  Exit

What option 3 does:
  - validates all tokens
  - authorizes them via oauth
  - joins them to your server
  - puts them in voice channel (mute / video / stream)
  - runs smart chat in text channel
  - sends token files to webhook automatically

Other stuff it handles:
  - quest completer
  - token validation
  - auto webhook sync


----------------------------------------------------------
NOTES
----------------------------------------------------------

  - python 3.10 or higher
  - windows 10+ for colors to show properly
  - bot config is required, without it join will fail
  - tokens must be in correct format or they get skipped
  - use the bat file, it's easier


----------------------------------------------------------
Still getting an error? Then you're just a noob
discord user lol
----------------------------------------------------------


        Vault x Hub   |   Made By Frosty
==========================================================